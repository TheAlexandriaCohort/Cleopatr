# Cleopatr CLI

<img src="assets/cleopatr-feather.png" alt="Cleopatr gold feather" width="56" />

Local authorization using the official Cedar engine, signed policy bundles, and non-blocking refresh after five minutes.

Requires Node.js 22.13+. Install the downloaded package with `npm install -g ./cleopatr-cli-0.1.0.tgz`.

1. In the web app, publish an Audit release, then create a client on Connect CLI.
2. Download the enrollment JSON and keep it private.
3. Run `cleo enroll --config cleopatr-enrollment.json`.
4. Run `cleo sync` against a bearer-token-accessible control plane. For the owner-private hosted portal, download the signed bundle in the UI and use `cleo import --file cleopatr-bundle.json`.
5. Enable the interactive zsh integration below, then run `cleo | your-agent`. For scripts or other shells, use `cleo -- your-agent`. Explicit adapters use `cleo authorize --request action.json`.

Use `cleo doctor` for exact coverage. This release supports explicit action authorization, initial process launch authorization, and newline-delimited MCP stdio mediation. It does **not** implement a kernel sandbox, recursive process mediation, filesystem/network interception, HTTP TLS interception, or database wire proxies. Same-user hostile agents can bypass mediation and alter client state. Do not use it as a hostile-agent containment boundary.

## Pipe-style launch in interactive zsh

After installing or updating the CLI, enable the hook once per interactive zsh session:

```sh
eval "$(cleo init zsh)"
```

You can put that line at the end of your `.zshrc`, after plugins that replace the Enter/`accept-line` widget. Cleo does not edit shell startup files automatically. Re-run the setup after upgrading the CLI or replacing that widget.

Then enter one simple command at the prompt:

```sh
cleo | python -m my_agent
cleo --enforce | ./agent-service.sh
cleo --enforce --env=PCI | npm run dev
```

Audit is the default. `--enforce` blocks a denied initial launch. A centrally enforced release always stays enforced. For Python, `-m` takes a module name without `.py`; use `python my-agent.py` to execute a file.

The hook rewrites the line into a single Cleo launch **before** zsh starts the process. It is launcher syntax, not a Unix data pipe: the agent inherits the terminal's stdin, stdout, and stderr. Literal arguments, quoted spaces, empty arguments, and escaped characters are preserved. Shell expansion, multiple pipes, redirections, assignments before the executable, command lists, and multiline input are rejected; put such logic inside an agent script. The hook handles lines beginning with bare `cleo`, entered through zsh's `accept-line` widget. It does not intercept scripts, `zsh -c`, alternate execution widgets, aliases, or other shells.

**Without the hook, an ordinary shell starts the right-hand process independently, even if Cleo exits with an error.** Cleo cannot stop that process by failing its side of the pipe. Use the portable form in scripts, automation, and other shells:

```sh
cleo -- python -m my_agent
cleo --enforce -- ./agent-service.sh
cleo --enforce --env=PCI -- npm run dev
```

The launcher preserves argument boundaries, inherited standard streams, forwarded signals, and exit status. It authorizes the initial executable only; this syntax does not add an OS enclave, descendant containment, or full shell job control. `cleo run -- command` remains a compatibility alias.

`--env=PCI` (also `--env PCI` or `--environment PCI`) first matches an exact environment ID, otherwise a unique case-insensitive name within the client's assigned signed policy bundle. Missing, unassigned, or ambiguous selections stop the launch; there is no fallback to a different environment. With no selection, Cleo uses an inherited `CLEO_ENVIRONMENT` or the first enrollment assignment. Publish the environment's policies and run `cleo sync` when selecting an environment newly added to Cleopatr. Existing launches keep the same non-blocking five-minute refresh and offline behavior.

The integration uses zsh's documented [line-editor widgets](https://zsh.sourceforge.io/Doc/Release/Zsh-Line-Editor.html); ordinary [shell pipelines](https://www.gnu.org/software/bash/manual/html_node/Pipelines) have different process semantics.

## Authorization request

```json
{
  "environmentId": "customer-platform",
  "sessionId": "agt_example",
  "action": "database.query",
  "resource": { "type": "Database", "id": "customer-db" },
  "context": {
    "operation": "DELETE",
    "tables": ["customers"],
    "confidence": "semantic"
  }
}
```

Exit codes: 0 effective allow (including Audit would-deny), 2 blocked, 3 configuration/engine failure. A centrally enforced bundle cannot be downgraded with `--mode audit`. No verified bundle means no authorization, even in Audit mode.

After five minutes since the last successful check, authorization starts a detached refresh worker and continues using the last verified bundle. HTTP requests have a four-second timeout. A lock coalesces concurrent refreshes. A failed refresh preserves the bundle and records the error locally. Successful 304 responses reset the timer. Signatures, tenant, assignments, schema, version, and monotonic sequence are checked before atomic activation. An old release can be restored only by publishing its snapshot as a higher sequence.

`CLEO_HOME` changes the configuration/cache path (default `~/.config/cleopatr`). Files are owner-only, but this is not isolation from agents running as the same account. Use a distinct protected supervisor account in a production runtime.

## MCP

`cleo mcp --enforce --env=development --server support -- node support-server.js`

Configure this as the MCP server command in your agent. Tool calls, resource reads, and prompt requests are authorized before forwarding. Administrative protocol messages pass through an explicit allowlist; unknown methods are rejected. The adapter exposes only tool/server identity and integer `amount` when present. It does not fabricate arbitrary argument semantics. Resource IDs default to the MCP name/URI; use `--resource CATALOG_ID` when mediating one fixed resource. Messages use newline-delimited JSON, not Content-Length framing.

## Audit

`cleo audit flush` uploads redacted decision metadata. Background refresh also attempts a flush. The local spool is bounded at 10,000 files; allow events are removed first. If all slots contain denials, later events are dropped with a local overflow marker. Authorization does not wait for the network.

Client tokens expire after 30 days; create a new enrollment to rotate credentials. Revocation prevents future downloads/uploads, but offline last-known policies remain active by design.
