// runtime/worker.ts
import { Buffer as Buffer5 } from "node:buffer";
import { createInterface } from "node:readline";

// cli/cache.ts
import {
  mkdir,
  readFile,
  writeFile,
  rename,
  stat,
  unlink,
  lstat,
  chmod
} from "node:fs/promises";
import { join, resolve } from "node:path";
import { homedir } from "node:os";
import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import * as cedar from "@cedar-policy/cedar-wasm/nodejs";

// core/model.ts
var VERSION = "0.6.0";
var SCHEMA_VERSION = "3.0";
var RESOURCE_TYPES = [
  "Database",
  "File",
  "Endpoint",
  "MCPTool",
  "Process",
  "Network"
];
var ACTIONS = {
  "process.execute": "Process",
  "process.signal": "Process",
  "process.privilege_attempt": "Process",
  "file.read": "File",
  "file.write": "File",
  "file.create": "File",
  "file.delete": "File",
  "file.rename": "File",
  "file.metadata": "File",
  "network.connect": "Network",
  "network.listen": "Network",
  "dns.query": "Network",
  "http.request": "Endpoint",
  "mcp.tool.invoke": "MCPTool",
  "mcp.resource.read": "MCPTool",
  "mcp.prompt.get": "MCPTool",
  "database.connect": "Database",
  "database.query": "Database",
  "database.transaction": "Database"
};
var CONTEXT_FIELDS = {
  operation: "String",
  method: "String",
  host: "String",
  path: "String",
  executable: "String",
  cwd: "String",
  protocol: "String",
  port: "Long",
  tool: "String",
  server: "String",
  amount: "Long",
  confidence: "String",
  tables: "Set",
  argv: "Set",
  resolvedPath: "String",
  encrypted: "Boolean",
  semanticAvailable: "Boolean",
  withinWorkspace: "Boolean"
};
function ancestors(environments, id) {
  const result = [];
  let cursor = id;
  while (cursor) {
    if (result.includes(cursor))
      throw new Error("Environment hierarchy contains a cycle");
    const e = environments.find((x) => x.id === cursor);
    if (!e) throw new Error(`Unknown environment: ${cursor}`);
    result.push(cursor);
    cursor = e.parentId;
  }
  return result;
}
function effectivePolicies(snapshot, id) {
  const lineage = ancestors(snapshot.environments, id).reverse();
  const applicable = /* @__PURE__ */ new Map();
  for (const envId of lineage) {
    const environment = snapshot.environments.find((e) => e.id === envId);
    for (const policy of snapshot.policies)
      if (policy.enabled && policy.environmentIds.includes(envId) && !applicable.has(policy.id))
        applicable.set(policy.id, {
          policy,
          sourceEnvironmentId: envId,
          mode: "AUDIT"
        });
    for (const entry of applicable.values()) {
      const requested = environment.mode === "CUSTOM" ? environment.policyModes?.[entry.policy.id] ?? entry.mode : environment.mode ?? "AUDIT";
      if (requested === "ENFORCE") entry.mode = "ENFORCE";
    }
  }
  return [...applicable.values()].map(
    ({ policy, sourceEnvironmentId, mode }) => ({
      ...policy,
      mode,
      sourceEnvironmentId
    })
  );
}
function policiesFor(snapshot, id) {
  return effectivePolicies(snapshot, id);
}
function buildSchema() {
  const shape = {
    type: "Record",
    attributes: {
      name: { type: "String" },
      environment: { type: "String" },
      locator: { type: "String" }
    }
  };
  const entityTypes = {
    AgentSession: {
      shape: {
        type: "Record",
        attributes: {
          environment: { type: "String" },
          workspace: { type: "String" },
          humanId: { type: "String" }
        }
      }
    }
  };
  for (const type of RESOURCE_TYPES) entityTypes[type] = { shape };
  const attributes = Object.fromEntries(
    Object.entries(CONTEXT_FIELDS).map(([k, type]) => [
      k,
      type === "Set" ? { type, element: { type: "String" }, required: false } : { type, required: false }
    ])
  );
  return {
    Cleopatr: {
      entityTypes,
      actions: Object.fromEntries(
        Object.entries(ACTIONS).map(([name, type]) => [
          name,
          {
            appliesTo: {
              principalTypes: ["AgentSession"],
              resourceTypes: [type],
              context: { type: "Record", attributes }
            }
          }
        ])
      )
    }
  };
}
var SCHEMA = buildSchema();

// core/crypto.ts
var enc = new TextEncoder();
function unbase64(value) {
  return Uint8Array.from(atob(value), (c) => c.charCodeAt(0));
}
async function digest(value) {
  return Array.from(
    new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(value)))
  ).map((x) => x.toString(16).padStart(2, "0")).join("");
}
async function verifyBundle(signed, publicKey, tenant, minSequence = 0) {
  if (signed.algorithm !== "Ed25519" || await digest(signed.payload) !== signed.digest || signed.keyId !== await digest(publicKey.x))
    throw new Error("Bundle digest or signing key mismatch");
  const key = await crypto.subtle.importKey(
    "jwk",
    publicKey,
    { name: "Ed25519" },
    false,
    ["verify"]
  );
  if (!await crypto.subtle.verify(
    "Ed25519",
    key,
    unbase64(signed.signature),
    enc.encode(signed.payload)
  ))
    throw new Error("Bundle signature verification failed");
  const bundle = JSON.parse(signed.payload);
  if (bundle.tenant !== tenant)
    throw new Error("Bundle belongs to a different tenant");
  if (!Number.isSafeInteger(bundle.sequence) || bundle.sequence < 1 || bundle.sequence < minSequence)
    throw new Error("Rejected policy rollback");
  const legacy = bundle;
  const isLegacy = bundle.schemaVersion === "1.0" && bundle.minimumClientVersion === "0.1.0";
  if (!isLegacy && !(bundle.schemaVersion === "2.0" && bundle.minimumClientVersion === "0.2.0") && (bundle.schemaVersion !== SCHEMA_VERSION || ![
    "0.3.0",
    "0.4.0",
    "0.4.1",
    "0.4.2",
    "0.4.3",
    "0.4.4",
    "0.5.0",
    "0.5.1",
    VERSION
  ].includes(bundle.minimumClientVersion)))
    throw new Error("Bundle requires a different Cleopatr version");
  if (!Array.isArray(bundle.environmentIds) || !bundle.environmentIds.length || !Array.isArray(bundle.policies) || !Array.isArray(bundle.resources) || !Array.isArray(bundle.environments))
    throw new Error("Invalid bundle manifest");
  if (isLegacy) {
    if (legacy.mode !== "AUDIT" && legacy.mode !== "ENFORCE")
      throw new Error("Invalid legacy bundle mode");
    bundle.environments = bundle.environments.map((e) => ({
      ...e,
      mode: legacy.mode
    }));
    bundle.policies = bundle.policies.map((p) => ({
      ...p,
      status: "PUBLISHED"
    }));
    bundle.bundleId = legacy.releaseId ?? `legacy_${bundle.sequence}`;
  }
  if (!bundle.bundleId || bundle.environments.some(
    (e) => !["AUDIT", "CUSTOM", "ENFORCE"].includes(e.mode ?? "AUDIT") || Object.values(e.policyModes ?? {}).some(
      (mode) => mode !== "AUDIT" && mode !== "ENFORCE"
    )
  ))
    throw new Error("Invalid environment policy modes");
  if (!isLegacy && bundle.policies.some((p) => p.status !== "PUBLISHED" || p.published))
    throw new Error("Bundle contains unpublished policy content");
  if (bundle.client && (typeof bundle.client.id !== "string" || !bundle.client.id || typeof bundle.client.name !== "string" || !bundle.client.name.trim() || bundle.client.name.length > 200))
    throw new Error("Invalid signed client identity");
  return bundle;
}

// core/assessment.ts
var MAX_ASSESSMENT_BYTES = 128 * 1024;
var MAX_AUDIT_EVENT_BYTES = 160 * 1024;
var MAX_AUDIT_BATCH_BYTES = 180 * 1024;
var jsonBytes = (value) => new TextEncoder().encode(JSON.stringify(value)).length;
function captureAssessment(payload) {
  const serialized = JSON.stringify(payload);
  const bytes = new TextEncoder().encode(serialized).length;
  if (bytes > MAX_ASSESSMENT_BYTES)
    return { version: 1, status: "unavailable", reason: "too_large", bytes };
  return {
    version: 1,
    status: "captured",
    schemaVersion: SCHEMA_VERSION,
    payload: JSON.parse(serialized)
  };
}

// core/engine.ts
function validatePolicies(engine, policies) {
  const answer = engine.validate({
    schema: SCHEMA,
    policies: {
      staticPolicies: Object.fromEntries(policies.map((p) => [p.id, p.cedar]))
    }
  });
  return answer.type === "failure" ? {
    valid: false,
    errors: answer.errors.map((e) => e.message),
    warnings: answer.warnings.map((e) => e.message)
  } : {
    valid: !answer.validationErrors.length,
    errors: answer.validationErrors.map(
      (e) => `${e.policyId}: ${e.error.message}`
    ),
    warnings: answer.validationWarnings.map(
      (e) => `${e.policyId}: ${e.error.message}`
    )
  };
}
function evaluateWithModes(engine, snapshot, request, forceEnforce = false, forceAudit = false) {
  if (forceEnforce && forceAudit)
    throw new Error("Conflicting execution modes");
  const start = performance.now();
  const policies = effectivePolicies(snapshot, request.environmentId);
  const environment = snapshot.environments.find(
    (e) => e.id === request.environmentId
  );
  const mode = forceAudit ? "AUDIT" : forceEnforce ? "ENFORCE" : environment.mode ?? "AUDIT";
  const full = evaluate(engine, snapshot, request);
  const enforced = forceAudit ? [] : policies.filter((p) => forceEnforce || p.mode === "ENFORCE");
  const mustEnforce = !forceAudit && (forceEnforce || mode === "ENFORCE" || enforced.length > 0);
  const blocking = mustEnforce ? evaluate(engine, { ...snapshot, policies: enforced }, request) : void 0;
  const effectiveResult = blocking?.errors.length ? "ERROR" : blocking?.decision === "DENY" ? "BLOCKED" : full.decision === "DENY" ? "ALLOWED_AUDIT" : "ALLOWED";
  const policyDecisions = [];
  for (const policy of policies) {
    const single = evaluate(
      engine,
      { ...snapshot, policies: [policy] },
      request
    );
    if (single.determiningPolicies.includes(policy.id) || single.errors.length)
      policyDecisions.push({
        policyId: policy.id,
        policyName: policy.name,
        policyVersion: policy.published?.version ?? policy.revision,
        decision: single.errors.length ? "ERROR" : single.decision,
        mode: forceAudit ? "AUDIT" : forceEnforce ? "ENFORCE" : policy.mode
      });
  }
  if (!policyDecisions.length || blocking?.decision === "DENY" && !blocking.determiningPolicies.length)
    policyDecisions.push({
      policyId: "",
      policyName: "Default deny (no permit matched)",
      policyVersion: 0,
      decision: "DENY",
      mode: mustEnforce ? "ENFORCE" : "AUDIT"
    });
  return {
    ...full,
    mode,
    policyDecisions,
    effectiveResult,
    allowed: effectiveResult === "ALLOWED" || effectiveResult === "ALLOWED_AUDIT",
    enforcementDecision: blocking?.decision,
    enforcementErrors: blocking?.errors ?? [],
    latencyUs: Math.round((performance.now() - start) * 1e3)
  };
}
function evaluate(engine, snapshot, request) {
  const start = performance.now();
  if (!ACTIONS[request.action] || ACTIONS[request.action] !== request.resource.type)
    throw new Error("Action and resource type do not match the schema");
  for (const [key, value] of Object.entries(request.context)) {
    const type = CONTEXT_FIELDS[key];
    if (!type) throw new Error(`Unsupported context field: ${key}`);
    if (type === "String" && typeof value !== "string" || type === "Long" && !Number.isSafeInteger(value) || type === "Boolean" && typeof value !== "boolean" || type === "Set" && (!Array.isArray(value) || !value.every((x) => typeof x === "string")))
      throw new Error(`Invalid value for context.${key}`);
  }
  const policies = policiesFor(snapshot, request.environmentId);
  const known = snapshot.resources.find((r) => r.id === request.resource.id);
  if (known && known.type !== request.resource.type)
    throw new Error("Resource type conflicts with the catalog");
  const principalName = request.principal ?? request.sessionId;
  if (typeof principalName !== "string" || !principalName.trim() || principalName.length > 200)
    throw new Error("A principal name of 1\u2013200 characters is required");
  const principal = { type: "Cleopatr::AgentSession", id: principalName };
  const resource = {
    type: `Cleopatr::${request.resource.type}`,
    id: request.resource.id
  };
  const parc = {
    principal,
    action: { type: "Cleopatr::Action", id: request.action },
    resource,
    context: request.context
  };
  const entities = [
    {
      uid: principal,
      attrs: {
        environment: request.environmentId,
        workspace: request.workspace ?? "",
        humanId: request.humanId ?? "local"
      },
      parents: []
    },
    {
      uid: resource,
      attrs: {
        name: known?.name ?? request.resource.id,
        environment: known?.environmentId ?? request.environmentId,
        locator: known?.locator ?? request.resource.id
      },
      parents: []
    }
  ];
  const payload = { ...parc, entities };
  const assessment = captureAssessment(payload);
  const answer = engine.isAuthorized({
    ...payload,
    context: request.context,
    entities,
    policies: {
      staticPolicies: Object.fromEntries(policies.map((p) => [p.id, p.cedar]))
    },
    schema: SCHEMA,
    validateRequest: true
  });
  if (answer.type === "failure")
    return {
      decision: "DENY",
      determiningPolicies: [],
      errors: answer.errors.map((e) => e.message),
      latencyUs: Math.round((performance.now() - start) * 1e3),
      parc,
      assessment,
      policyCount: policies.length
    };
  return {
    decision: answer.response.diagnostics.errors.length ? "DENY" : answer.response.decision.toUpperCase(),
    determiningPolicies: answer.response.diagnostics.reason,
    errors: answer.response.diagnostics.errors.map(
      (e) => `${e.policyId}: ${e.error.message}`
    ),
    latencyUs: Math.round((performance.now() - start) * 1e3),
    parc,
    assessment,
    policyCount: policies.length
  };
}

// cli/cache.ts
var REFRESH_INTERVAL_MS = 3e5;
function dataDir() {
  if (process.env.CLEO_HOME) return resolve(process.env.CLEO_HOME);
  const project = resolve(".cleo");
  const previous = join(homedir(), ".config", "cleopatr");
  return existsSync(join(project, "config")) || existsSync(join(project, "config.json")) || !existsSync(join(previous, "config.json")) ? project : previous;
}
async function atomicJson(path, value) {
  const temp = path + "." + crypto.randomUUID() + ".tmp";
  await writeFile(temp, JSON.stringify(value, null, 2), {
    mode: 384,
    flag: "wx"
  });
  try {
    await rename(temp, path);
  } catch (e) {
    await unlink(temp).catch(() => {
    });
    throw e;
  }
}
async function readConfig(dir = dataDir()) {
  const config = JSON.parse(
    await readFile(join(dir, "config"), "utf8").catch(
      (error) => {
        if (error.code !== "ENOENT") throw error;
        return readFile(join(dir, "config.json"), "utf8");
      }
    )
  );
  validateConfig(config);
  return config;
}
function validateConfig(config) {
  const url = new URL(config.server);
  if (url.username || url.password || !["http:", "https:"].includes(url.protocol) || url.protocol === "http:" && !["localhost", "127.0.0.1", "[::1]"].includes(url.hostname))
    throw new Error(
      "Control plane must use HTTPS (HTTP is allowed only on loopback)"
    );
  if (!config.tenant || !config.token || !config.clientId || config.clientName !== void 0 && (typeof config.clientName !== "string" || !config.clientName.trim() || config.clientName.length > 200) || !config.publicKey?.x || !Array.isArray(config.environmentIds) || !config.environmentIds.length || config.environmentIds.some((x) => typeof x !== "string") || config.environment !== void 0 && (typeof config.environment !== "string" || !config.environment.trim()))
    throw new Error("Invalid enrollment configuration");
}
async function readCache(dir = dataDir()) {
  try {
    return JSON.parse(await readFile(join(dir, "bundle.json"), "utf8"));
  } catch (e) {
    if (e.code === "ENOENT") return null;
    throw new Error(
      "Policy cache is unreadable; run cleo sync or import a verified bundle"
    );
  }
}
async function loadBundle(dir = dataDir()) {
  const config = await readConfig(dir);
  const cache = await readCache(dir);
  if (!cache)
    throw new Error(
      "No verified policy bundle. Run cleo sync or import a signed bundle before authorizing."
    );
  const bundle = await verifyBundle(
    cache.signed,
    config.publicKey,
    config.tenant,
    cache.highWater
  );
  verifyScope(bundle, config);
  const validation = validatePolicies(cedar, bundle.policies);
  if (!validation.valid)
    throw new Error(
      "Cached policy validation failed: " + validation.errors.join("; ")
    );
  return { config, cache, bundle };
}
function verifyScope(bundle, config) {
  if (bundle.client && bundle.client.id !== config.clientId)
    throw new Error("Signed client identity does not match this enrollment");
  if (JSON.stringify(bundle.schema) !== JSON.stringify(SCHEMA))
    throw new Error("Bundle schema does not match this client");
  const expected = bundle.environments.filter(
    (e) => ancestors(bundle.environments, e.id).some(
      (id) => config.environmentIds.includes(id)
    )
  ).map((e) => e.id).sort();
  if (JSON.stringify([...bundle.environmentIds].sort()) !== JSON.stringify(expected))
    throw new Error("Bundle assignment does not match this client enrollment");
}
async function withActivationLock(dir, work) {
  const lock = join(dir, "activation.lock");
  const started = Date.now();
  while (true) {
    try {
      await writeFile(lock, String(Date.now()), { flag: "wx", mode: 384 });
      break;
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
      try {
        if (Date.now() - (await stat(lock)).mtimeMs > 3e4) await unlink(lock);
      } catch {
      }
      if (Date.now() - started > 3e3)
        throw new Error("Policy activation is busy; retry");
      await new Promise((r) => setTimeout(r, 10));
    }
  }
  try {
    return await work();
  } finally {
    await unlink(lock).catch(() => {
    });
  }
}
async function activate(signed, dir = dataDir(), checkedAt = Date.now()) {
  return withActivationLock(
    dir,
    () => activateUnlocked(signed, dir, checkedAt)
  );
}
async function activateUnlocked(signed, dir, checkedAt) {
  const config = await readConfig(dir);
  const cache = await readCache(dir);
  const bundle = await verifyBundle(
    signed,
    config.publicKey,
    config.tenant,
    cache?.highWater ?? 0
  );
  verifyScope(bundle, config);
  const validation = validatePolicies(cedar, bundle.policies);
  if (!validation.valid)
    throw new Error(
      "Policy schema validation failed: " + validation.errors.join("; ")
    );
  if (cache) {
    const old = await verifyBundle(
      cache.signed,
      config.publicKey,
      config.tenant,
      cache.highWater
    );
    if (old.sequence === bundle.sequence && cache.signed.digest !== signed.digest)
      throw new Error("Policy bundle contents changed without a new sequence");
  }
  const next = {
    signed,
    checkedAt,
    activatedAt: Date.now(),
    highWater: Math.max(cache?.highWater ?? 0, bundle.sequence),
    etag: `"${signed.digest}"`
  };
  await atomicJson(join(dir, "bundle.json"), next);
  return bundle;
}
function needsRefresh(cache, at = Date.now()) {
  return !cache || at - cache.checkedAt >= REFRESH_INTERVAL_MS;
}
async function requestRefresh(dir = dataDir(), entry = process.argv[1]) {
  const cache = await readCache(dir);
  if (!needsRefresh(cache)) return false;
  const lock = join(dir, "refresh.lock");
  try {
    await writeFile(lock, String(Date.now()), { flag: "wx", mode: 384 });
  } catch (e) {
    if (e.code !== "EEXIST") throw e;
    const age = Date.now() - (await stat(lock)).mtimeMs;
    if (age > 6e4) {
      await unlink(lock).catch(() => {
      });
    }
    return false;
  }
  try {
    const args = entry.endsWith(".ts") ? ["--import", "tsx", entry, "__refresh"] : [entry, "__refresh"];
    const child = spawn(process.execPath, args, {
      detached: true,
      stdio: "ignore",
      env: { ...process.env, CLEO_HOME: dir }
    });
    child.on("error", () => {
      void unlink(lock).catch(() => {
      });
    });
    child.unref();
    return true;
  } catch (e) {
    await unlink(lock).catch(() => {
    });
    throw e;
  }
}
async function sync(dir = dataDir(), fetcher = fetch) {
  const config = await readConfig(dir);
  const cache = await readCache(dir);
  const response = await fetcher(new URL("/api/v1/bundles", config.server), {
    headers: {
      authorization: `Bearer ${config.token}`,
      ...cache ? { "if-none-match": cache.etag } : {}
    },
    signal: AbortSignal.timeout(4e3),
    redirect: "error"
  });
  if (response.status === 304) {
    if (!cache) throw new Error("Server returned 304 without a local bundle");
    await withActivationLock(dir, async () => {
      await loadBundle(dir);
      const current = await readCache(dir);
      if (current?.etag === cache.etag)
        await atomicJson(join(dir, "bundle.json"), {
          ...current,
          checkedAt: Date.now()
        });
    });
    return { changed: false, sequence: cache.highWater };
  }
  if (!response.ok)
    throw new Error(
      `Policy refresh failed (${response.status}); the previous verified bundle is retained`
    );
  const text = await response.text();
  if (text.length > 5e6) throw new Error("Policy bundle is too large");
  const bundle = await activate(JSON.parse(text), dir);
  return { changed: true, sequence: bundle.sequence };
}
async function refreshWorker(dir = dataDir()) {
  try {
    await sync(dir);
    await atomicJson(join(dir, "refresh-status.json"), {
      ok: true,
      time: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (e) {
    await atomicJson(join(dir, "refresh-status.json"), {
      ok: false,
      time: (/* @__PURE__ */ new Date()).toISOString(),
      error: e.message
    });
  } finally {
    await unlink(join(dir, "refresh.lock")).catch(() => {
    });
  }
}

// cli/options.ts
function resolveEnvironment(bundle, selector) {
  const byId = bundle.environments.find((e) => e.id === selector);
  if (byId) {
    if (!bundle.environmentIds.includes(byId.id))
      throw new Error(
        `This client is not assigned to environment: ${selector}`
      );
    return byId.id;
  }
  const matches = bundle.environments.filter(
    (e) => bundle.environmentIds.includes(e.id) && e.name.toLowerCase() === selector.toLowerCase()
  );
  if (matches.length > 1)
    throw new Error(
      `Environment name is ambiguous: ${selector}. Use an environment ID.`
    );
  if (!matches.length)
    throw new Error(
      `Environment not found in the assigned policy bundle: ${selector}. Run cleo sync to check for new environments.`
    );
  return matches[0].id;
}

// cli/audit.ts
import {
  appendFile,
  mkdir as mkdir2,
  readFile as readFile2,
  readdir,
  rename as rename2,
  unlink as unlink2,
  writeFile as writeFile2
} from "node:fs/promises";
import { join as join2, resolve as resolve2 } from "node:path";
async function spool(event, dir = dataDir()) {
  const spoolDir = join2(dir, "spool");
  await mkdir2(spoolDir, { recursive: true, mode: 448 });
  const files = await readdir(spoolDir);
  if (files.length >= 1e4) {
    const allows = files.filter((f) => f.endsWith(".allow.json")).sort();
    if (allows.length) await unlink2(join2(spoolDir, allows[0])).catch(() => {
    });
    else {
      await appendFile(
        join2(dir, "audit-overflow.log"),
        `${(/* @__PURE__ */ new Date()).toISOString()} spool full; ${event.decision} event not persisted
`,
        { mode: 384 }
      );
      throw new Error("Audit spool is full");
    }
  }
  const name = `${Date.now()}-${crypto.randomUUID()}.${event.decision === "ALLOW" ? "allow" : "deny"}.json`;
  const tmp = join2(spoolDir, name + ".tmp");
  await writeFile2(tmp, JSON.stringify(event), { mode: 384 });
  await rename2(tmp, join2(spoolDir, name));
}
async function savedStatus(dir) {
  return readFile2(join2(dir, "audit-status.json"), "utf8").then(JSON.parse).catch(() => ({}));
}
var activeUploads = /* @__PURE__ */ new Map();
function flushAudit(dir = dataDir(), options = {}) {
  dir = resolve2(dir);
  const active = activeUploads.get(dir);
  if (active) return active;
  const operation = upload(dir, options.maxBatches ?? 1).finally(
    () => activeUploads.delete(dir)
  );
  activeUploads.set(dir, operation);
  return operation;
}
async function upload(dir, maxBatches) {
  const path = join2(dir, "spool");
  const previous = await savedStatus(dir);
  const deadline = Date.now() + 4e3;
  let uploaded = 0;
  let attempted = false;
  try {
    for (let batch = 0; batch < maxBatches && Date.now() < deadline; batch++) {
      const files = (await readdir(path).catch(() => [])).filter((f) => f.endsWith(".json")).sort().slice(0, 100);
      if (!files.length) break;
      attempted = true;
      const events = [];
      const selected = [];
      let bytes = jsonBytes({ events: [] });
      for (const file of files) {
        let text;
        try {
          text = await readFile2(join2(path, file), "utf8");
        } catch (error) {
          if (error.code === "ENOENT") continue;
          throw error;
        }
        const event = JSON.parse(text);
        const size = jsonBytes(event) + (events.length ? 1 : 0);
        if (bytes + size > MAX_AUDIT_BATCH_BYTES) break;
        bytes += size;
        selected.push(file);
        events.push(event);
      }
      if (!events.length) {
        if (!selected.length && !(await readdir(path)).some((f) => files.includes(f)))
          continue;
        throw new Error("Audit record exceeds upload size limit");
      }
      const config = await readConfig(dir);
      const response = await fetch(new URL("/api/v1/audit", config.server), {
        method: "POST",
        headers: {
          authorization: `Bearer ${config.token}`,
          "content-type": "application/json"
        },
        body: JSON.stringify({ events }),
        signal: AbortSignal.timeout(Math.max(1, deadline - Date.now())),
        redirect: "error"
      });
      if (!response.ok)
        throw new Error(`Audit upload failed (${response.status})`);
      const receipt = await response.json();
      if (receipt.accepted !== events.length)
        throw new Error("Audit server did not acknowledge every event");
      for (const file of selected)
        await unlink2(join2(path, file)).catch(() => {
        });
      uploaded += selected.length;
    }
    if (attempted)
      await atomicJson(join2(dir, "audit-status.json"), {
        ...previous,
        lastAttempt: (/* @__PURE__ */ new Date()).toISOString(),
        ...uploaded ? { lastSuccess: (/* @__PURE__ */ new Date()).toISOString() } : {},
        lastError: null
      });
    return uploaded;
  } catch (error) {
    await atomicJson(join2(dir, "audit-status.json"), {
      ...previous,
      lastAttempt: (/* @__PURE__ */ new Date()).toISOString(),
      lastError: error.message
    }).catch(() => {
    });
    throw error;
  }
}

// cli/runtime.ts
import * as cedar2 from "@cedar-policy/cedar-wasm/nodejs";
function createPinnedAuthorizer(loaded, options) {
  return async (request, adapter = options.adapter) => {
    const cache = await readCache(options.dir ?? dataDir());
    if (!cache || cache.signed.payload !== loaded.cache.signed.payload || cache.signed.signature !== loaded.cache.signed.signature || cache.highWater !== loaded.cache.highWater)
      throw new Error(
        "Policy snapshot changed; restart the supervisor session"
      );
    return authorizeVerified(
      request,
      { ...loaded, cache },
      { ...options, adapter }
    );
  };
}
async function authorizeVerified(request, loaded, options) {
  const dir = options.dir ?? dataDir();
  const { bundle, cache, config } = loaded;
  if (options.expectedSequence !== void 0 && bundle.sequence !== options.expectedSequence)
    throw new Error(
      "Policy snapshot changed; this supervisor session must be restarted"
    );
  if (!bundle.environmentIds.includes(request.environmentId))
    throw new Error("This client is not assigned to the requested environment");
  if (options.refresh !== false)
    await requestRefresh(dir, options.entry).catch(() => {
    });
  const principal = bundle.client?.name ?? config.clientName;
  if (!principal)
    throw new Error(
      "Client name is missing from this older enrollment. Run cleo sync to receive your signed client identity, or use a new enrollment file for offline access."
    );
  request = { ...request, principal };
  let result;
  try {
    result = evaluateWithModes(
      cedar2,
      bundle,
      request,
      options.mode === "ENFORCE",
      options.mode === "AUDIT"
    );
  } catch (e) {
    const mode = options.mode === "AUDIT" ? "AUDIT" : options.mode === "ENFORCE" ? "ENFORCE" : bundle.environments.find((env) => env.id === request.environmentId)?.mode ?? "AUDIT";
    const enforce = options.mode !== "AUDIT" && (mode === "ENFORCE" || effectivePolicies(bundle, request.environmentId).some(
      (p) => p.mode === "ENFORCE"
    ));
    result = {
      decision: "DENY",
      determiningPolicies: [],
      errors: [e.message],
      latencyUs: 0,
      parc: {
        principal: { type: "Cleopatr::AgentSession", id: principal },
        action: { type: "Cleopatr::Action", id: request.action },
        resource: {
          type: `Cleopatr::${request.resource?.type ?? "Unknown"}`,
          id: request.resource?.id ?? ""
        },
        context: request.context
      },
      policyCount: 0,
      assessment: {
        version: 1,
        status: "unavailable",
        reason: "not_evaluated"
      },
      mode,
      effectiveResult: enforce ? "ERROR" : "ALLOWED_AUDIT",
      allowed: !enforce,
      policyDecisions: [
        {
          policyId: "",
          policyName: "Authorization error",
          policyVersion: 0,
          decision: "ERROR",
          mode: enforce ? "ENFORCE" : "AUDIT"
        }
      ]
    };
  }
  const decision = {
    ...result,
    bundleId: bundle.bundleId,
    sequence: bundle.sequence,
    stale: Date.now() - cache.checkedAt >= 3e5
  };
  await Promise.all(
    decision.policyDecisions.map(
      (policy) => spool(
        {
          id: "evt_" + crypto.randomUUID(),
          kind: "decision",
          time: (/* @__PURE__ */ new Date()).toISOString(),
          sessionId: request.sessionId,
          environmentId: request.environmentId,
          action: request.action,
          resource: request.resource?.id,
          assessment: decision.assessment,
          ...policy,
          effectiveResult: policy.decision === "ALLOW" ? "ALLOWED" : policy.mode === "AUDIT" ? "ALLOWED_AUDIT" : policy.decision === "ERROR" ? "ERROR" : "BLOCKED",
          bundleId: bundle.bundleId,
          sequence: bundle.sequence,
          determiningPolicies: policy.policyId ? [policy.policyId] : [],
          adapter: options.adapter ?? "explicit",
          confidence: request.context?.confidence ?? "configured"
        },
        dir
      ).catch(
        (e) => process.stderr.write(
          `cleo: audit spool error: ${e.message}
`
        )
      )
    )
  );
  return decision;
}

// runtime/profile.ts
import * as cedar3 from "@cedar-policy/cedar-wasm/nodejs";
import { posix } from "node:path";

// runtime/network.ts
function networkIdentity(value) {
  try {
    const url = new URL(value);
    return `${url.protocol}//${url.hostname.toLowerCase()}:${url.port || (url.protocol === "https:" ? 443 : url.protocol === "http:" ? 80 : "")}`;
  } catch {
    return value;
  }
}
function networkResource(resources2, locator) {
  const target = networkIdentity(locator);
  return resources2.find(
    (resource) => resource.type === "Network" && networkIdentity(resource.locator) === target
  );
}

// runtime/url.ts
function httpPath(url) {
  if (/%(?:2f|5c|25)/i.test(url.pathname))
    throw new Error("Encoded separators and double encoding are unsupported");
  const path = decodeURIComponent(url.pathname);
  let hasControl = false;
  for (let index = 0; index < path.length; index++) {
    const code = path.charCodeAt(index);
    if (code < 32 || code === 127) hasControl = true;
  }
  if (/[\\;]/.test(path) || path.includes("//") || hasControl)
    throw new Error("Ambiguous HTTP path");
  return path;
}

// runtime/adapters/wire.ts
var view = (bytes) => new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
var u16be = (bytes, offset = 0) => view(bytes).getUint16(offset, false);
var u16le = (bytes, offset = 0) => view(bytes).getUint16(offset, true);
var u32be = (bytes, offset = 0) => view(bytes).getUint32(offset, false);
var u32le = (bytes, offset = 0) => view(bytes).getUint32(offset, true);
var uintle = (bytes, offset, length) => {
  if (length < 1 || length > 4 || offset + length > bytes.length)
    throw new Error("Invalid wire integer");
  let value = 0;
  for (let i = 0; i < length; i++) value += bytes[offset + i] * 2 ** (i * 8);
  return value;
};

// runtime/adapters/database.ts
import { Buffer as Buffer2 } from "node:buffer";
import net from "node:net";
import tls from "node:tls";
import { once } from "node:events";

// runtime/adapters/sql.ts
import { Buffer } from "node:buffer";
function sqlOperation(sql, dialect) {
  if (!sql.trim() || Buffer.byteLength(sql) > 32768 || sql.includes("\0"))
    throw new Error("SQL size or encoding unsupported");
  let plain = "", i = 0, ended = false;
  while (i < sql.length) {
    const c = sql[i];
    if (/\s/.test(c)) {
      plain += " ";
      i++;
      continue;
    }
    if (sql.startsWith("--", i) && (dialect === "postgres" || /\s/.test(sql[i + 2] ?? " ")) || dialect === "mysql" && c === "#") {
      const end = sql.indexOf("\n", i);
      i = end < 0 ? sql.length : end + 1;
      plain += " ";
      continue;
    }
    if (sql.startsWith("/*", i)) {
      if (sql[i + 2] === "!" || sql[i + 2] === "+")
        throw new Error("Executable SQL comments unsupported");
      let depth = 1;
      i += 2;
      while (i < sql.length && depth) {
        if (sql.startsWith("/*", i)) {
          if (dialect === "mysql")
            throw new Error("Nested MySQL comments unsupported");
          depth++;
          i += 2;
        } else if (sql.startsWith("*/", i)) {
          depth--;
          i += 2;
        } else i++;
      }
      if (depth) throw new Error("Unterminated SQL comment");
      plain += " ";
      continue;
    }
    if (ended) throw new Error("Multiple statements unsupported");
    if (c === ";") {
      ended = true;
      i++;
      continue;
    }
    if (c === "'" || c === '"' || c === "`") {
      const quote = c;
      i++;
      let closed = false;
      while (i < sql.length) {
        if (sql[i] === "\\")
          throw new Error("Backslash SQL escapes unsupported");
        if (sql[i++] === quote) {
          if (sql[i] === quote) {
            i++;
            continue;
          }
          closed = true;
          break;
        }
      }
      if (!closed) throw new Error("Unterminated SQL literal");
      plain += " ? ";
      continue;
    }
    if (c === "$")
      throw new Error(
        "Dollar quoting and parameters require an unsupported prepared protocol"
      );
    plain += c;
    i++;
  }
  const normalized = plain.trim().replace(/\s+/g, " ").toUpperCase();
  const command = normalized.split(" ")[0];
  if (["BEGIN", "COMMIT", "ROLLBACK"].includes(command) && /^(BEGIN(?: WORK| TRANSACTION)?|COMMIT(?: WORK)?|ROLLBACK(?: WORK)?)$/.test(
    normalized
  ))
    return { action: "database.transaction", operation: command };
  if (normalized === "START TRANSACTION")
    return { action: "database.transaction", operation: "BEGIN" };
  if (!["SELECT", "INSERT", "UPDATE", "DELETE", "SHOW"].includes(command))
    throw new Error(`Unsupported SQL command: ${command}`);
  if (/\b(INTO\s+(OUTFILE|DUMPFILE)|LOAD_FILE|SLEEP|BENCHMARK)\b/.test(normalized))
    throw new Error("Unsupported SQL operation");
  return { action: "database.query", operation: command };
}

// runtime/adapters/database.ts
var MAX_FRAME = 65536;
function databaseTarget(resource) {
  const url = new URL(resource.locator);
  if (!["postgres:", "postgresql:", "mysql:"].includes(url.protocol) || url.username || url.password || url.hash || !/^\/[a-zA-Z0-9_.-]+$/.test(url.pathname) || [...url.searchParams.keys()].some((k) => k !== "tls") || url.searchParams.getAll("tls").length > 1)
    throw new Error(
      `Database ${resource.name}: use postgres://host:port/database or mysql://host:port/database without credentials`
    );
  const protocol = url.protocol === "mysql:" ? "mysql" : "postgres";
  const host = url.hostname.replace(/^\[|\]$/g, "").toLowerCase();
  const encrypted = url.searchParams.get("tls") !== "disable";
  if (!host || host.includes("*") || url.port === "0" || url.searchParams.has("tls") && !["require", "disable"].includes(url.searchParams.get("tls")))
    throw new Error("Invalid database transport");
  if (!encrypted && !["127.0.0.1", "::1", "localhost", "host.docker.internal"].includes(host))
    throw new Error(
      "Plaintext database upstream is limited to loopback/test host"
    );
  return {
    protocol,
    host,
    port: Number(url.port || (protocol === "mysql" ? 3306 : 5432)),
    database: url.pathname.slice(1),
    encrypted
  };
}
var Reader = class {
  constructor(socket) {
    this.socket = socket;
    this.buffer = Buffer2.alloc(0);
    this.data = (chunk) => {
      this.buffer = Buffer2.concat([this.buffer, chunk]);
      this.socket.pause();
      if (this.buffer.length > MAX_FRAME * 2)
        this.failure = new Error("Database frame buffer exceeded");
      this.wake?.();
    };
    this.end = () => {
      this.failure ??= new Error("Database connection ended");
      this.wake?.();
    };
    this.error = (error) => {
      this.failure = error;
      this.wake?.();
    };
    socket.on("data", this.data);
    socket.on("end", this.end);
    socket.on("error", this.error);
    socket.on("close", this.end);
    socket.pause();
  }
  async read(length) {
    if (length < 0 || length > MAX_FRAME)
      throw new Error("Database frame too large");
    while (this.buffer.length < length) {
      if (this.failure) throw this.failure;
      await new Promise((resolve3) => {
        this.wake = resolve3;
        this.socket.resume();
      });
      this.wake = void 0;
    }
    const out = this.buffer.subarray(0, length);
    this.buffer = this.buffer.subarray(length);
    return out;
  }
  detach() {
    if (this.buffer.length) throw new Error("Unexpected bytes before TLS");
    this.socket.removeListener("data", this.data);
    this.socket.removeListener("end", this.end);
    this.socket.removeListener("close", this.end);
    this.socket.removeListener("error", this.error);
  }
};
function pgFrame(type, body) {
  const header = Buffer2.alloc(5);
  header[0] = type.charCodeAt(0);
  header.writeUInt32BE(body.length + 4, 1);
  return Buffer2.concat([header, body]);
}
async function pgRead(reader) {
  const header = await reader.read(5);
  const size = u32be(header, 1);
  if (size < 4) throw new Error("Invalid PostgreSQL frame");
  const body = await reader.read(size - 4);
  return {
    type: String.fromCharCode(header[0]),
    body,
    wire: Buffer2.concat([header, body])
  };
}
function pgError(message) {
  return pgFrame("E", Buffer2.from(`SFATAL\0C42501\0M${message}\0\0`));
}
function mysqlFrame(body, sequence2) {
  const header = Buffer2.alloc(4);
  header.writeUIntLE(body.length, 0, 3);
  header[3] = sequence2 & 255;
  return Buffer2.concat([header, body]);
}
async function mysqlRead(reader) {
  const header = await reader.read(4);
  const body = await reader.read(uintle(header, 0, 3));
  return { body, sequence: header[3] };
}
function mysqlError(message, seq = 1) {
  const prefix = Buffer2.from([255, 118, 4, 35, 52, 50, 48, 48, 48]);
  return mysqlFrame(Buffer2.concat([prefix, Buffer2.from(message)]), seq);
}
function utf8(buffer) {
  return new TextDecoder("utf-8", { fatal: true }).decode(buffer);
}
async function send(socket, bytes) {
  if (!socket.write(bytes)) await once(socket, "drain");
}
async function startDatabaseProxy(resource, decide2, options = {}) {
  const target = databaseTarget(resource);
  const sockets = /* @__PURE__ */ new Set();
  const errorSequence = /* @__PURE__ */ new WeakMap();
  const track = (socket) => {
    sockets.add(socket);
    socket.on("close", () => sockets.delete(socket));
    socket.on("error", () => {
    });
    socket.setTimeout(
      3e4,
      () => socket.destroy(new Error("Database transport timeout"))
    );
    return socket;
  };
  const context = {
    host: target.host,
    port: target.port,
    protocol: target.protocol,
    server: target.database,
    encrypted: target.encrypted,
    confidence: "wire-observed",
    semanticAvailable: true
  };
  const check = (action, extra = {}) => decide2(
    action,
    { type: "Database", id: resource.id },
    { ...context, ...extra }
  );
  const query = async (sql) => {
    const operation = sqlOperation(sql, target.protocol);
    if (!await check(operation.action, {
      operation: operation.operation,
      argv: [sql]
    }))
      throw new Error("Blocked by Cleopatr policy");
  };
  const connect = async () => {
    if (!await check("database.connect", { operation: "CONNECT" }))
      throw new Error("Database connection blocked by Cleopatr policy");
    if (!await decide2(
      "network.connect",
      { type: "Network", id: `tcp://${target.host}:${target.port}` },
      { ...context, protocol: "tcp" }
    ))
      throw new Error("Database network connection blocked by Cleopatr policy");
    const socket = track(
      net.createConnection({ host: target.host, port: target.port })
    );
    await once(socket, "connect");
    return socket;
  };
  const secure = async (socket) => {
    const secured = track(
      tls.connect({
        socket,
        ca: options.ca,
        servername: net.isIP(target.host) ? void 0 : target.host,
        rejectUnauthorized: true,
        minVersion: "TLSv1.2",
        checkServerIdentity: (_host, cert) => tls.checkServerIdentity(target.host, cert)
      })
    );
    await once(secured, "secureConnect");
    return secured;
  };
  const server = net.createServer((socket) => {
    track(socket);
    void (target.protocol === "postgres" ? postgres(socket) : mysql(socket)).catch((error) => {
      if (!socket.destroyed)
        socket.end(
          target.protocol === "postgres" ? pgError(error.message) : mysqlError(
            error.message,
            errorSequence.get(socket) ?? 0
          )
        );
    });
  });
  server.maxConnections = 64;
  async function postgres(client) {
    const downstream = new Reader(client);
    let length = u32be(await downstream.read(4));
    let startup = await downstream.read(length - 4);
    if (length === 8 && u32be(startup, 0) === 80877103) {
      await send(client, Buffer2.from("N"));
      length = u32be(await downstream.read(4));
      startup = await downstream.read(length - 4);
    }
    if (startup.length < 5 || u32be(startup, 0) !== 196608 || startup.at(-1) !== 0)
      throw new Error("Only PostgreSQL protocol 3.0 startup is supported");
    const fields = utf8(startup.subarray(4)).split("\0");
    if (fields.at(-1) !== "" || fields.at(-2) !== "")
      throw new Error("Invalid PostgreSQL startup");
    const params = /* @__PURE__ */ new Map();
    for (let i = 0; i < fields.length - 2; i += 2) {
      if (!["user", "database", "application_name", "client_encoding"].includes(
        fields[i]
      ) || params.has(fields[i]))
        throw new Error("Unsupported PostgreSQL startup parameter");
      params.set(fields[i], fields[i + 1]);
    }
    if (params.get("database") !== target.database || !params.get("user") || params.has("client_encoding") && !/^UTF-?8$/i.test(params.get("client_encoding")))
      throw new Error("Database identity/encoding differs from catalog");
    let upstream = await connect();
    client.once("close", () => upstream.destroy());
    try {
      let reader = new Reader(upstream);
      if (target.encrypted) {
        await send(upstream, Buffer2.from([0, 0, 0, 8, 4, 210, 22, 47]));
        if ((await reader.read(1))[0] !== 83)
          throw new Error("PostgreSQL upstream TLS required");
        reader.detach();
        upstream = await secure(upstream);
        reader = new Reader(upstream);
      }
      const header = Buffer2.alloc(4);
      header.writeUInt32BE(length);
      await send(upstream, Buffer2.concat([header, startup]));
      for (; ; ) {
        const frame = await pgRead(reader);
        await send(client, frame.wire);
        if (frame.type === "E") return;
        if (frame.type === "Z") break;
        if (frame.type === "R") {
          const auth = u32be(frame.body, 0);
          if ([3, 5, 10, 11].includes(auth)) {
            const reply = await pgRead(downstream);
            if (reply.type !== "p")
              throw new Error("Expected PostgreSQL authentication");
            await send(upstream, reply.wire);
          } else if (![0, 12].includes(auth))
            throw new Error("Unsupported PostgreSQL authentication");
        } else if (!["S", "K", "N"].includes(frame.type))
          throw new Error("Unexpected PostgreSQL startup response");
      }
      for (; ; ) {
        const frame = await pgRead(downstream);
        if (frame.type === "X" && !frame.body.length) return;
        if (frame.type !== "Q" || frame.body.at(-1) !== 0 || frame.body.subarray(0, -1).includes(0))
          throw new Error(
            "Only PostgreSQL simple-query messages are supported; prepared/COPY/replication protocols are blocked"
          );
        await query(utf8(frame.body.subarray(0, -1)));
        await send(upstream, frame.wire);
        for (; ; ) {
          const reply = await pgRead(reader);
          if (!["T", "D", "C", "E", "N", "S", "I", "Z"].includes(reply.type))
            throw new Error("Unsupported PostgreSQL response");
          await send(client, reply.wire);
          if (reply.type === "Z") break;
        }
      }
    } finally {
      upstream.destroy();
    }
  }
  async function mysql(client) {
    let upstream = await connect();
    client.once("close", () => upstream.destroy());
    try {
      let reader = new Reader(upstream);
      const downstream = new Reader(client);
      const greeting = await mysqlRead(reader);
      if (greeting.sequence !== 0 || greeting.body[0] !== 10)
        throw new Error("Only MySQL protocol 10 is supported");
      const versionEnd = greeting.body.indexOf(0, 1), lowOffset = versionEnd + 14, highOffset = lowOffset + 5;
      if (versionEnd < 0 || greeting.body.length < highOffset + 2)
        throw new Error("Invalid MySQL greeting");
      const original = u16le(greeting.body, lowOffset) | u16le(greeting.body, highOffset) << 16;
      const forbidden = 2048 | 32 | 128 | 65536 | 131072 | 262144 | 16777216 | 67108864;
      const capabilities = original & ~forbidden;
      const body = Buffer2.from(greeting.body);
      body.writeUInt16LE(capabilities & 65535, lowOffset);
      body.writeUInt16LE(capabilities >>> 16 & 65535, highOffset);
      await send(client, mysqlFrame(body, 0));
      const login = await mysqlRead(downstream);
      errorSequence.set(client, 2);
      if (login.sequence !== 1 || login.body.length < 34)
        throw new Error("Invalid MySQL handshake");
      const clientFlags = u32le(login.body, 0);
      const flags = clientFlags & ~forbidden;
      if (clientFlags & (2048 | 32 | 16777216 | 67108864) || !(flags & 512) || !(flags & 8) || !(flags & 32768))
        throw new Error(
          "Unsupported MySQL capabilities; select a database and use text queries"
        );
      if (![33, 45, 46, 83, 224, 255].includes(login.body[8]))
        throw new Error("MySQL client must use UTF-8");
      let offset = login.body.indexOf(0, 32) + 1;
      if (offset <= 32) throw new Error("Invalid MySQL username");
      let authLength = login.body[offset++];
      if (flags & 2097152) {
        if (authLength === 252) {
          authLength = u16le(login.body, offset);
          offset += 2;
        } else if (authLength === 253) {
          authLength = uintle(login.body, offset, 3);
          offset += 3;
        } else if (authLength >= 251)
          throw new Error("Unsupported MySQL authentication length");
      }
      offset += authLength;
      if (offset >= login.body.length)
        throw new Error("Truncated MySQL authentication");
      const dbEnd = login.body.indexOf(0, offset);
      if (dbEnd < 0 || utf8(login.body.subarray(offset, dbEnd)) !== target.database)
        throw new Error("Database identity differs from catalog");
      let delta = 0;
      if (target.encrypted) {
        if (!(original & 2048)) throw new Error("MySQL upstream TLS required");
        const ssl = Buffer2.from(login.body.subarray(0, 32));
        ssl.writeUInt32LE(flags | 2048, 0);
        await send(upstream, mysqlFrame(ssl, 1));
        reader.detach();
        upstream = await secure(upstream);
        reader = new Reader(upstream);
        delta = 1;
      }
      const auth = Buffer2.from(login.body);
      auth.writeUInt32LE(flags | (delta ? 2048 : 0), 0);
      await send(upstream, mysqlFrame(auth, 1 + delta));
      for (let count = 0; ; count++) {
        if (count > 8)
          throw new Error("MySQL authentication exchange exceeded limit");
        const response = await mysqlRead(reader);
        await send(
          client,
          mysqlFrame(response.body, response.sequence - delta)
        );
        if (response.body[0] === 0) break;
        if (response.body[0] === 255) return;
        if (response.body[0] === 1 && response.body[1] === 3) continue;
        if (![1, 254].includes(response.body[0]))
          throw new Error("Unsupported MySQL authentication");
        const reply = await mysqlRead(downstream);
        await send(upstream, mysqlFrame(reply.body, reply.sequence + delta));
      }
      errorSequence.set(client, 1);
      for (; ; ) {
        const request = await mysqlRead(downstream);
        if (request.sequence !== 0 || !request.body.length)
          throw new Error("Invalid MySQL command");
        const command = request.body[0];
        if (command === 1 && request.body.length === 1) return;
        if (command !== 3)
          throw new Error(
            "Only MySQL COM_QUERY is supported; prepared statements, database switches and other commands are blocked"
          );
        await query(utf8(request.body.subarray(1)));
        await send(upstream, mysqlFrame(request.body, 0));
        let response = await mysqlRead(reader);
        if ([0, 255].includes(response.body[0])) {
          await send(client, mysqlFrame(response.body, response.sequence));
          continue;
        }
        const columns = response.body[0];
        if (columns < 1 || columns >= 251 || response.body.length !== 1)
          throw new Error("Unsupported MySQL result");
        await send(client, mysqlFrame(response.body, response.sequence));
        for (let i = 0; i < columns; i++) {
          response = await mysqlRead(reader);
          await send(client, mysqlFrame(response.body, response.sequence));
        }
        response = await mysqlRead(reader);
        if (response.body[0] !== 254 || response.body.length >= 9)
          throw new Error("Expected MySQL metadata EOF");
        await send(client, mysqlFrame(response.body, response.sequence));
        for (; ; ) {
          response = await mysqlRead(reader);
          if (response.body[0] === 254 && response.body.length < 9) {
            if (response.body.length < 5 || u16le(response.body, 3) & 8)
              throw new Error("Multiple MySQL results unsupported");
            await send(client, mysqlFrame(response.body, response.sequence));
            break;
          }
          await send(client, mysqlFrame(response.body, response.sequence));
          if (response.body[0] === 255) break;
        }
      }
    } finally {
      upstream.destroy();
    }
  }
  await new Promise((resolve3, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve3);
  });
  return {
    port: server.address().port,
    close: () => {
      for (const socket of sockets) socket.destroy();
      server.close();
    }
  };
}

// runtime/profile.ts
var rights = {
  execute: 1,
  write: 2,
  read: 4 | 8,
  delete: 16 | 32,
  create: 128 | 256 | 4096,
  rename: 8192,
  truncate: 16384
};
var semanticActions = /* @__PURE__ */ new Set([
  "process.signal",
  "process.privilege_attempt",
  "file.metadata",
  "network.listen",
  "http.request",
  "network.connect",
  "dns.query",
  "mcp.tool.invoke",
  "mcp.resource.read",
  "mcp.prompt.get",
  "database.connect",
  "database.query",
  "database.transaction"
]);
var supportedActions = /* @__PURE__ */ new Set([
  ...semanticActions,
  "process.execute",
  "file.read",
  "file.write",
  "file.create",
  "file.delete",
  "file.rename",
  "network.connect",
  "http.request",
  "mcp.tool.invoke",
  "mcp.resource.read",
  "mcp.prompt.get"
]);
function variable(node, name) {
  if (!node || typeof node !== "object") return false;
  if (!Array.isArray(node) && node.Var === name) return true;
  return Object.values(node).some((v) => variable(v, name));
}
function onlySemantic(scope) {
  const entity = scope.entity;
  const entities = scope.entities;
  const values = scope.op === "==" && entity ? [entity] : scope.op === "in" && entities ? entities : [];
  return values.length > 0 && values.every(
    (e) => e.type === "Cleopatr::Action" && semanticActions.has(e.id ?? "")
  );
}
function staticFileContext(ast) {
  const scope = ast.action;
  const selected = scope.entity ? [scope.entity] : Array.isArray(scope.entities) ? scope.entities : [];
  if (!selected.length || !selected.every(
    (e) => e && typeof e === "object" && !Array.isArray(e) && typeof e.id === "string" && e.id.startsWith("file.")
  ))
    return false;
  const walk = (node) => {
    if (!node || typeof node !== "object") return true;
    if (!Array.isArray(node)) {
      if (node.Var === "context") return false;
      for (const op of [".", "has"]) {
        const value = node[op];
        if (value && typeof value === "object" && !Array.isArray(value) && value.attr === "withinWorkspace" && value.left && typeof value.left === "object" && !Array.isArray(value.left) && value.left.Var === "context")
          return true;
      }
    }
    return Object.values(node).every(walk);
  };
  return walk(ast.conditions);
}
function compileProfile(bundle, environmentId, principal, enforce, audit = false) {
  if (enforce && audit) throw new Error("Conflicting execution modes");
  const lineage = new Set(ancestors(bundle.environments, environmentId));
  const resources2 = bundle.resources.filter(
    (r) => lineage.has(r.environmentId)
  );
  const policies = effectivePolicies(bundle, environmentId);
  const auditOnly = audit || !enforce && bundle.environments.find((e) => e.id === environmentId)?.mode !== "ENFORCE" && policies.every((policy) => policy.mode === "AUDIT");
  for (const policy of audit ? [] : policies) {
    const parsed = cedar3.policyToJson(policy.cedar);
    if (parsed.type !== "success")
      throw new Error(`Cannot parse policy ${policy.name}`);
    const ast = parsed.json;
    const checkReferences = (value) => {
      if (!value || typeof value !== "object") return;
      if (!Array.isArray(value) && typeof value.type === "string" && ["Cleopatr::File", "Cleopatr::Process"].includes(value.type) && !resources2.some(
        (r) => r.id === value.id && `Cleopatr::${r.type}` === value.type
      ))
        throw new Error(
          `Policy "${policy.name}" references an OS resource outside this environment's catalog`
        );
      Object.values(value).forEach(checkReferences);
    };
    checkReferences(ast);
    const scope = ast.action;
    const selected = scope.entity ? [scope.entity] : Array.isArray(scope.entities) ? scope.entities : [];
    if (selected.some(
      (entity) => entity && typeof entity === "object" && !Array.isArray(entity) && (typeof entity.id !== "string" || !supportedActions.has(entity.id))
    ))
      throw new Error(
        `Policy "${policy.name}" requires an action this Linux backend cannot mediate`
      );
    if (!onlySemantic(ast.action) && (variable(ast.conditions, "context") && !staticFileContext(ast) || variable(ast.conditions, "action")))
      throw new Error(
        `Policy "${policy.name}" needs per-operation OS context. This Landlock backend supports context-free OS policies only; no session was started.`
      );
  }
  if (resources2.filter((r) => r.type === "Database").length > 128)
    throw new Error("At most 128 Database endpoints are supported per enclave");
  const databaseEndpoints = /* @__PURE__ */ new Set();
  for (const resource of resources2.filter((r) => r.type === "Database")) {
    const target = databaseTarget(resource);
    const endpoint = `${target.host}:${target.port}`;
    if (databaseEndpoints.has(endpoint))
      throw new Error("Only one Database resource per host/port is supported");
    databaseEndpoints.add(endpoint);
  }
  for (const resource of resources2.filter((r) => r.type === "MCPTool")) {
    let url;
    try {
      url = new URL(resource.locator);
    } catch {
      throw new Error(
        `MCP resource ${resource.name} requires an HTTP transport URL for this backend`
      );
    }
    if (!["http:", "https:"].includes(url.protocol) || url.username || url.password)
      throw new Error(`Unsupported MCP transport for ${resource.name}`);
  }
  for (const resource of resources2.filter(
    (r) => r.type === "Endpoint" || r.type === "Network"
  )) {
    let url;
    try {
      url = new URL(resource.locator);
    } catch {
      throw new Error(
        `${resource.name} requires an absolute HTTP(S) URL in this backend`
      );
    }
    if (resource.type === "Network" && ["dns:", "tcp:", "udp:"].includes(url.protocol)) {
      if (url.username || url.password || url.search || url.hash || !url.hostname || url.hostname.includes("*") || !["", "/"].includes(url.pathname) || url.protocol === "dns:" && url.port)
        throw new Error(`Invalid Network locator: ${resource.name}`);
      continue;
    }
    if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.hash || url.hostname.includes("*") || resource.type === "Network" && url.pathname !== "/")
      throw new Error(
        `Unsupported ${resource.type} locator for ${resource.name}; use an origin${resource.type === "Endpoint" ? " and optional path" : ""}`
      );
    httpPath(url);
  }
  const grants = /* @__PURE__ */ new Map();
  const identities = /* @__PURE__ */ new Set();
  for (const resource of resources2.filter(
    (r) => ["Endpoint", "Network", "MCPTool"].includes(r.type)
  )) {
    const url = new URL(resource.locator);
    const key = JSON.stringify([
      resource.type,
      resource.type === "Network" ? networkIdentity(resource.locator) : url.origin,
      resource.type === "Network" ? "" : httpPath(url),
      resource.type === "MCPTool" ? url.search : "",
      resource.type === "MCPTool" ? decodeURIComponent(url.hash.slice(1)) : ""
    ]);
    if (identities.has(key))
      throw new Error(
        `Ambiguous duplicate protocol resource: ${resource.name}`
      );
    identities.add(key);
  }
  const add = (path, access) => grants.set(path, (grants.get(path) ?? 0) | access);
  const decide2 = (action, type, id) => {
    if (audit) return true;
    const request = {
      environmentId,
      sessionId: "profile",
      principal,
      action,
      resource: { type, id },
      workspace: "/workspace",
      context: type === "File" ? {
        withinWorkspace: resources2.some(
          (r) => r.id === id && (r.locator === "/workspace" || r.locator.startsWith("/workspace/"))
        )
      } : {}
    };
    const result = evaluateWithModes(cedar3, bundle, request, enforce);
    if (result.errors.length || result.enforcementErrors.length)
      throw new Error(
        `OS profile evaluation failed for ${id}: ${[...result.errors, ...result.enforcementErrors].join("; ")}`
      );
    return result.allowed;
  };
  const fileResources = resources2.filter((r) => r.type === "File");
  const pathFor = (value) => {
    if (!value.startsWith("/") || posix.normalize(value) !== value || value === "/" || value.includes("\0"))
      throw new Error(
        `Use a normalized, absolute, non-root sandbox resource path: ${value}`
      );
    if (![
      "/workspace",
      "/usr",
      "/bin",
      "/lib",
      "/lib64",
      "/etc",
      "/tmp",
      "/dev"
    ].some((p) => value === p || value.startsWith(p + "/")))
      throw new Error(
        `Resource path is outside the supported sandbox roots: ${value}`
      );
    return value;
  };
  for (const resource of fileResources) {
    const path = pathFor(resource.locator);
    if (fileResources.some(
      (other) => other.id !== resource.id && (other.locator === path || other.locator.startsWith(path + "/") || path.startsWith(other.locator + "/"))
    ))
      throw new Error(
        `Overlapping File resources cannot be safely compiled: ${path}`
      );
    let access = 0;
    const create = decide2("file.create", "File", resource.id);
    const remove = decide2("file.delete", "File", resource.id);
    const rename3 = decide2("file.rename", "File", resource.id);
    if ((create && remove) !== rename3)
      throw new Error(
        `Landlock cannot independently represent rename versus create/delete for ${path}; align these permissions or use another backend.`
      );
    if (decide2("file.read", "File", resource.id)) access |= rights.read;
    if (decide2("file.write", "File", resource.id))
      access |= rights.write | rights.truncate;
    if (create) access |= rights.create;
    if (remove) access |= rights.delete;
    if (rename3) access |= rights.rename;
    if (access) add(path, access);
  }
  for (const resource of resources2.filter((r) => r.type === "Process")) {
    if (decide2("process.execute", "Process", resource.id))
      add(pathFor(resource.locator), rights.execute);
  }
  return {
    principal,
    environmentId,
    auditOnly,
    boundaries: fileResources.map((r) => r.locator),
    grants: [...grants].map(([path, access]) => ({ path, access })),
    resources: resources2
  };
}
function requireExecutableGrant(profile) {
  const identity = `Cleopatr::AgentSession::${JSON.stringify(profile.principal)}`;
  if (!profile.resources.some((resource) => resource.type === "Process"))
    throw new Error(
      `No executable is permitted: Environment ${JSON.stringify(profile.environmentId)} has no Process resources in its catalog or parent Environments. The principal is ${identity}. Register the agent, interpreters/tools and ELF loader as Process resources; a process.execute permit alone cannot create the executable allowlist. Runtime directories also need File read permissions.`
    );
  if (!profile.grants.some((grant) => (grant.access & rights.execute) !== 0))
    throw new Error(
      `No executable is permitted for ${identity} in Environment ${JSON.stringify(profile.environmentId)}. No effective process.execute permit allows the registered Process resources, or a forbid blocks them. Check principal/resource scopes and Enforce modes. Runtime directories also need File read permissions. Network policies are evaluated only after the process can start.`
    );
}

// runtime/adapters/dns.ts
import { Buffer as Buffer3 } from "node:buffer";
import dgram from "node:dgram";
import net2 from "node:net";
import { getServers } from "node:dns";
function dnsQuestion(packet) {
  if (packet.length < 17 || packet.length > 4096 || u16be(packet, 2) & 63488 || u16be(packet, 4) !== 1 || u16be(packet, 6) || u16be(packet, 8))
    throw new Error("Unsupported DNS message");
  let offset = 12;
  const labels = [];
  while (packet[offset]) {
    const length = packet[offset++];
    if (length > 63 || offset + length >= packet.length)
      throw new Error("Invalid DNS name");
    const label = new TextDecoder("utf-8", { fatal: true }).decode(
      packet.subarray(offset, offset + length)
    );
    if (!/^[a-zA-Z0-9_-]+$/.test(label)) throw new Error("Invalid DNS label");
    labels.push(label.toLowerCase());
    offset += length;
  }
  offset++;
  if (!labels.length || labels.join(".").length > 253 || offset + 4 > packet.length || u16be(packet, offset + 2) !== 1)
    throw new Error("Invalid DNS question");
  const type = u16be(packet, offset);
  const end = offset + 4;
  const additional = u16be(packet, 10);
  if (additional === 0 ? end !== packet.length : additional !== 1 || packet.length !== end + 11 || packet[end] !== 0 || u16be(packet, end + 1) !== 41 || u32be(packet, end + 5) !== 0 || u16be(packet, end + 9) !== 0)
    throw new Error("Unsupported DNS additional records");
  return { host: labels.join("."), type, end };
}
function dnsReply(packet, code, address) {
  let end = 12;
  try {
    end = dnsQuestion(packet).end;
  } catch {
  }
  const out = Buffer3.alloc(end + (address ? 16 : 0));
  out.set(packet.subarray(0, end));
  out.writeUInt16BE(
    32896 | (packet.length >= 4 ? u16be(packet, 2) & 256 : 0) | code,
    2
  );
  out.writeUInt16BE(end > 12 ? 1 : 0, 4);
  out.writeUInt16BE(address ? 1 : 0, 6);
  out.writeUInt32BE(0, 8);
  if (address) {
    out.writeUInt16BE(49164, end);
    out.writeUInt16BE(1, end + 2);
    out.writeUInt16BE(1, end + 4);
    out.writeUInt32BE(5, end + 6);
    out.writeUInt16BE(4, end + 10);
    Buffer3.from(address.split(".").map(Number)).copy(out, end + 12);
  }
  return out;
}
function createDnsAdapter(resources2, decide2, aliases = /* @__PURE__ */ new Map(), resolver = getServers()[0]) {
  return async (packet) => {
    let question;
    try {
      question = dnsQuestion(packet);
    } catch {
      return dnsReply(packet, 1);
    }
    const { host, type } = question;
    const resource = networkResource(resources2, `dns://${host}`);
    if (!await decide2(
      "dns.query",
      { type: "Network", id: resource?.id ?? `dns://${host}` },
      {
        host,
        operation: String(type),
        protocol: "dns",
        semanticAvailable: true,
        confidence: "wire-observed"
      }
    ))
      return dnsReply(packet, 5);
    const alias = aliases.get(host);
    if (alias) return dnsReply(packet, 0, type === 1 ? alias : void 0);
    if (!resolver || !net2.isIP(resolver)) return dnsReply(packet, 2);
    return new Promise((resolve3) => {
      const socket = dgram.createSocket(
        net2.isIP(resolver) === 6 ? "udp6" : "udp4"
      );
      let done = false;
      const finish = (answer) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        socket.close();
        resolve3(answer);
      };
      const timer = setTimeout(() => finish(dnsReply(packet, 2)), 2e3);
      socket.on("error", () => finish(dnsReply(packet, 2)));
      socket.on("message", (answer) => {
        if (answer.length < 12 || answer.length > 4096 || u16be(answer, 0) !== u16be(packet, 0) || !(u16be(answer, 2) & 32768) || u16be(answer, 4) !== 1 || answer.length < question.end || !answer.subarray(12, question.end).every((v, i) => v === packet[12 + i]))
          return;
        finish(answer);
      });
      socket.connect(53, resolver, () => socket.send(packet));
    });
  };
}
async function startDnsTcp(answer) {
  const sockets = /* @__PURE__ */ new Set();
  const server = net2.createServer((socket) => {
    sockets.add(socket);
    socket.on("close", () => sockets.delete(socket));
    socket.on("error", () => socket.destroy());
    socket.setTimeout(1e4, () => socket.destroy());
    let buffer = Buffer3.alloc(0), busy = false;
    socket.on("data", (chunk) => {
      buffer = Buffer3.concat([buffer, chunk]);
      if (buffer.length > 8192) return void socket.destroy();
      void pump();
    });
    async function pump() {
      if (busy) return;
      busy = true;
      try {
        while (buffer.length >= 2) {
          const length = u16be(buffer, 0);
          if (length < 12 || length > 4096) throw new Error("DNS frame limit");
          if (buffer.length < length + 2) break;
          const packet = buffer.subarray(2, length + 2);
          buffer = buffer.subarray(length + 2);
          const response = await answer(packet);
          const header = Buffer3.alloc(2);
          header.writeUInt16BE(response.length);
          socket.write(Buffer3.concat([header, response]));
        }
      } catch {
        socket.destroy();
      } finally {
        busy = false;
      }
    }
  });
  server.maxConnections = 64;
  await new Promise((resolve3, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve3);
  });
  return {
    port: server.address().port,
    close: () => {
      for (const socket of sockets) socket.destroy();
      server.close();
    }
  };
}

// runtime/worker.ts
import { isIP } from "node:net";

// runtime/adapters/http.ts
import http from "node:http";
import { Buffer as Buffer4 } from "node:buffer";
import https from "node:https";
import net3 from "node:net";

// runtime/adapters/mcp-http.ts
var calls = {
  "tools/call": "mcp.tool.invoke",
  "resources/read": "mcp.resource.read",
  "prompts/get": "mcp.prompt.get"
};
var administration = /* @__PURE__ */ new Set([
  "initialize",
  "ping",
  "tools/list",
  "resources/list",
  "resources/templates/list",
  "prompts/list",
  "notifications/initialized",
  "notifications/cancelled",
  "notifications/progress"
]);
function mcpResources(resources2, target) {
  return resources2.filter((resource) => {
    if (resource.type !== "MCPTool") return false;
    try {
      const url = new URL(resource.locator);
      return url.origin === target.origin && url.pathname === target.pathname && url.search === target.search;
    } catch {
      return false;
    }
  });
}
async function authorizeMcpBody(body, target, resources2, decide2) {
  const message = JSON.parse(
    new TextDecoder("utf-8", { fatal: true }).decode(body)
  );
  if (!message || typeof message !== "object" || Array.isArray(message))
    return false;
  const msg = message;
  if (msg.jsonrpc !== "2.0" || typeof msg.method !== "string") return false;
  if (administration.has(msg.method)) return true;
  const action = calls[msg.method];
  if (!action || !msg.params || typeof msg.params !== "object" || Array.isArray(msg.params))
    return false;
  const params = msg.params;
  const name = msg.method === "resources/read" ? params.uri : params.name;
  if (typeof name !== "string" || !name || name.length > 2048) return false;
  const resource = resources2.find(
    (r) => decodeURIComponent(new URL(r.locator).hash.slice(1)) === name
  ) ?? resources2.find((r) => !new URL(r.locator).hash);
  if (!resource) return false;
  const args = params.arguments;
  const amount = args && typeof args === "object" && !Array.isArray(args) ? args.amount : void 0;
  if (amount !== void 0 && !Number.isSafeInteger(amount)) return false;
  return decide2(
    action,
    { type: "MCPTool", id: resource.id },
    {
      tool: name,
      server: target.origin,
      operation: msg.method,
      protocol: "mcp-http",
      semanticAvailable: true,
      confidence: "proxy-observed",
      ...amount === void 0 ? {} : { amount }
    }
  );
}

// runtime/adapters/http.ts
var hop = /* @__PURE__ */ new Set([
  "connection",
  "proxy-connection",
  "keep-alive",
  "proxy-authenticate",
  "proxy-authorization",
  "te",
  "trailer",
  "transfer-encoding",
  "upgrade"
]);
function headers(message) {
  const exclude = /* @__PURE__ */ new Set([
    ...hop,
    ...(message.headers.connection ?? "").toLowerCase().split(",").map((v) => v.trim())
  ]);
  return Object.fromEntries(
    Object.entries(message.headers).filter(([key]) => !exclude.has(key))
  );
}
function match(resources2, url) {
  const path = httpPath(url);
  return resources2.filter((r) => r.type === "Endpoint").map((resource) => {
    try {
      const url2 = new URL(resource.locator);
      return { resource, url: url2, path: httpPath(url2) };
    } catch {
      return void 0;
    }
  }).filter(
    (r) => !!r && r.url.origin === url.origin && (r.path === "/" || path === r.path || path.startsWith(r.path.replace(/\/$/, "") + "/"))
  ).sort((a, b) => b.path.length - a.path.length)[0]?.resource;
}
async function startHttpProxy(resources2, decide2, options = {}) {
  const sockets = /* @__PURE__ */ new Set();
  const server = http.createServer(
    { maxHeaderSize: 16384, requestTimeout: 3e4, headersTimeout: 1e4 },
    (req, res) => {
      void forward(req, res).catch(() => {
        if (!res.headersSent) res.writeHead(502);
        res.end("Cleopatr adapter failed closed");
      });
    }
  );
  server.on("connection", (socket) => {
    sockets.add(socket);
    socket.on("close", () => sockets.delete(socket));
    socket.on("error", () => socket.destroy());
    socket.setTimeout(3e4, () => socket.destroy());
  });
  server.maxConnections = 128;
  server.maxRequestsPerSocket = 128;
  server.keepAliveTimeout = 5e3;
  server.on("connect", (req, socket, head) => {
    socket.pause();
    const refuse = (status, reason, message) => {
      options.onDiagnostic?.(message);
      if (socket.destroyed || socket.writableEnded) return;
      const body = message + "\n";
      socket.end(
        `HTTP/1.1 ${status} ${http.STATUS_CODES[status]}\r
Connection: close\r
X-Cleopatr-Reason: ${reason}\r
Content-Type: text/plain\r
Content-Length: ${Buffer4.byteLength(body)}\r
\r
${body}`,
        () => socket.destroy()
      );
    };
    void (async () => {
      const authority = req.url ?? "";
      if (!/^(?:\[[0-9a-fA-F:]+\]|[a-zA-Z0-9.-]+):[0-9]{1,5}$/.test(authority)) {
        refuse(400, "invalid-connect", "Invalid CONNECT authority");
        return;
      }
      let url;
      try {
        url = new URL(`https://${authority}`);
      } catch {
        refuse(400, "invalid-connect", "Invalid CONNECT authority");
        return;
      }
      const port = Number(url.port || 443);
      if (port < 1 || port > 65535) {
        refuse(400, "invalid-connect", "Invalid CONNECT port");
        return;
      }
      const endpoint = match(resources2, url);
      if (!await decide2(
        "http.request",
        { type: "Endpoint", id: endpoint?.id ?? url.origin },
        {
          method: "CONNECT",
          host: url.hostname,
          port,
          protocol: "https",
          encrypted: true,
          semanticAvailable: false,
          confidence: "proxy-observed"
        }
      )) {
        refuse(403, "policy-deny", "CONNECT blocked by Cleopatr policy");
        return;
      }
      const network = resources2.find((r) => {
        try {
          return r.type === "Network" && new URL(r.locator).origin === url.origin;
        } catch {
          return false;
        }
      });
      if (!await decide2(
        "network.connect",
        { type: "Network", id: network?.id ?? url.origin },
        {
          host: url.hostname,
          port,
          protocol: "tcp",
          semanticAvailable: false,
          confidence: "proxy-observed"
        }
      )) {
        refuse(
          403,
          "policy-deny",
          "CONNECT network connection blocked by Cleopatr policy"
        );
        return;
      }
      if (!options.auditOnly) {
        refuse(
          501,
          "https-inspection-required",
          "HTTPS inspection is not implemented for sessions containing Enforce policies; the tunnel was not opened"
        );
        return;
      }
      if (socket.destroyed) return;
      const upstream = net3.createConnection({
        host: url.hostname.replace(/^\[|\]$/g, ""),
        port
      });
      sockets.add(upstream);
      let connected = false;
      const deadline = setTimeout(
        () => upstream.destroy(new Error("connect timeout")),
        1e4
      );
      deadline.unref();
      upstream.on("close", () => {
        clearTimeout(deadline);
        sockets.delete(upstream);
        if (connected && !upstream.readableEnded) socket.destroy();
      });
      socket.once("close", () => upstream.destroy());
      socket.once("error", () => upstream.destroy());
      upstream.on("error", () => {
        if (connected) socket.destroy();
        else
          refuse(
            502,
            "upstream-unavailable",
            "CONNECT destination unavailable"
          );
      });
      upstream.once("connect", () => {
        clearTimeout(deadline);
        if (socket.destroyed) {
          upstream.destroy();
          return;
        }
        connected = true;
        upstream.setTimeout(3e4, () => upstream.destroy());
        socket.write("HTTP/1.1 200 Connection Established\r\n\r\n");
        options.onDiagnostic?.(
          `audit tunnel opened to ${url.host}; encrypted requests are not inspected`
        );
        if (head.length) upstream.write(head);
        upstream.pipe(socket);
        socket.pipe(upstream);
        socket.resume();
      });
    })().catch(
      () => refuse(
        503,
        "authorization-unavailable",
        "CONNECT authorization unavailable"
      )
    );
  });
  server.on("upgrade", (_req, socket) => socket.destroy());
  server.on("clientError", (_error, socket) => socket.destroy());
  async function forward(req, res) {
    const url = new URL(req.url ?? "");
    if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.hash)
      throw new Error("Invalid proxy target");
    const resource = match(resources2, url);
    const context = {
      method: req.method ?? "",
      host: url.hostname,
      path: httpPath(url),
      port: Number(url.port || (url.protocol === "https:" ? 443 : 80)),
      protocol: url.protocol.slice(0, -1),
      encrypted: url.protocol === "https:",
      semanticAvailable: true,
      confidence: "proxy-observed"
    };
    if (!await decide2(
      "http.request",
      { type: "Endpoint", id: resource?.id ?? url.origin },
      context
    )) {
      res.writeHead(403).end("Blocked by Cleopatr policy");
      return;
    }
    if (!resource) {
      res.writeHead(403).end("Destination is not in the signed resource catalog");
      return;
    }
    const network = resources2.find((r) => {
      if (r.type !== "Network") return false;
      try {
        return new URL(r.locator).origin === url.origin;
      } catch {
        return false;
      }
    });
    if (!await decide2(
      "network.connect",
      { type: "Network", id: network?.id ?? url.origin },
      {
        host: context.host,
        port: context.port,
        protocol: "tcp",
        confidence: "proxy-observed",
        semanticAvailable: true
      }
    )) {
      res.writeHead(403).end("Connection blocked by Cleopatr policy");
      return;
    }
    const outgoing = { ...headers(req), host: url.host };
    let body;
    const mcp = mcpResources(resources2, url);
    const mcpOrigin = resources2.some((r) => {
      if (r.type !== "MCPTool") return false;
      try {
        return new URL(r.locator).origin === url.origin;
      } catch {
        return false;
      }
    });
    if (mcpOrigin && !mcp.length) {
      res.writeHead(403).end("MCP origin requires an exact registered transport endpoint");
      return;
    }
    if (mcp.length) {
      if (req.method === "POST") {
        const chunks = [];
        let length = 0;
        for await (const chunk of req) {
          length += chunk.length;
          if (length > 1024 * 1024) throw new Error("MCP body exceeds one MiB");
          chunks.push(Buffer4.from(chunk));
        }
        const complete = Buffer4.concat(chunks);
        body = complete;
        if (!await authorizeMcpBody(complete, url, mcp, decide2)) {
          res.writeHead(403).end("MCP operation blocked by Cleopatr");
          return;
        }
      } else if (!["GET", "DELETE"].includes(req.method ?? "")) {
        res.writeHead(405).end();
        return;
      }
    }
    const upstream = (url.protocol === "https:" ? https : http).request(
      url,
      {
        method: req.method,
        headers: outgoing,
        timeout: 1e4,
        agent: false
        // Node validates upstream TLS hostname/certificate; no redirect following or tunnel fallback.
      },
      (response) => {
        res.writeHead(response.statusCode ?? 502, headers(response));
        response.pipe(res);
      }
    );
    upstream.on(
      "timeout",
      () => upstream.destroy(new Error("upstream timeout"))
    );
    upstream.on("error", () => {
      if (!res.headersSent) res.writeHead(502);
      res.end("Upstream unavailable");
    });
    res.on("close", () => upstream.destroy());
    if (body) upstream.end(body);
    else req.pipe(upstream);
  }
  await new Promise((resolve3, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve3);
  });
  return {
    port: server.address().port,
    close: () => {
      for (const socket of sockets) socket.destroy();
      server.close();
    }
  };
}

// runtime/worker.ts
if (process.getuid?.() !== 0 || process.env.CLEO_SUPERVISOR !== "1")
  throw new Error("Policy worker must be started by the privileged supervisor");
if (process.argv[2] === "__refresh") {
  await refreshWorker();
  await flushAudit().catch(() => {
  });
  process.exit(0);
}
var lines = createInterface({ input: process.stdin, crlfDelay: Infinity });
var output = (value) => process.stdout.write(JSON.stringify(value) + "\n");
var closers = [];
var decide;
var dns;
var resources = [];
var sequence;
try {
  for await (const line of lines) {
    if (line.length > 65536) throw new Error("Supervisor message too large");
    const message = JSON.parse(line);
    if (message.op === "start" && sequence === void 0) {
      const loaded = await loadBundle(dataDir());
      const { bundle, config } = loaded;
      const environmentId = resolveEnvironment(
        bundle,
        message.request.environment ?? config.environment ?? config.environmentIds[0]
      );
      const principal = bundle.client?.name ?? config.clientName;
      if (!principal) throw new Error("Signed client identity is required");
      const sessionId = "agt_" + crypto.randomUUID();
      if (message.request.audit && message.request.enforce)
        throw new Error("Conflicting execution modes");
      const mode = message.request.audit === true ? "AUDIT" : message.request.enforce === true ? "ENFORCE" : void 0;
      const profile = compileProfile(
        bundle,
        environmentId,
        principal,
        message.request.enforce === true,
        message.request.audit === true
      );
      requireExecutableGrant(profile);
      resources = profile.resources;
      const pinned = createPinnedAuthorizer(loaded, {
        mode,
        entry: process.argv[1],
        adapter: "enclave",
        expectedSequence: bundle.sequence
      });
      decide = async (action, resource, context) => {
        if (action === "network.connect") {
          const catalog = networkResource(resources, resource.id);
          if (catalog) resource = { type: "Network", id: catalog.id };
          if (typeof context.host === "string" && !isIP(context.host.replace(/^\[|\]$/g, ""))) {
            const dnsResource = networkResource(
              resources,
              `dns://${context.host}`
            );
            if (!await decide(
              "dns.query",
              {
                type: "Network",
                id: dnsResource?.id ?? `dns://${context.host}`
              },
              {
                host: context.host,
                operation: "LOOKUP",
                protocol: "dns",
                confidence: "adapter-observed",
                semanticAvailable: true
              }
            ))
              return false;
          }
        }
        const result = await pinned(
          {
            environmentId,
            sessionId,
            action,
            resource,
            context,
            workspace: "/workspace"
          },
          action.startsWith("mcp.") ? "mcp-http" : action.startsWith("database.") ? "database-wire" : action === "dns.query" ? "dns-wire" : ["http.request", "network.connect"].includes(action) ? "http-proxy" : "seccomp"
        );
        const names = result.determiningPolicies.map(
          (id) => JSON.stringify(
            bundle.policies.find((policy) => policy.id === id)?.name ?? id
          )
        );
        process.stderr.write(
          `cleo: ${result.mode} \xB7 ${action} \xB7 ${result.effectiveResult} \xB7 ${names.join(", ") || "default deny"}
`
        );
        return result.allowed;
      };
      const proxy = await startHttpProxy(profile.resources, decide, {
        auditOnly: profile.auditOnly,
        onDiagnostic: (message2) => process.stderr.write(`cleo: ${message2}
`)
      });
      closers.push(proxy.close);
      const routes = [];
      const aliases = /* @__PURE__ */ new Map();
      for (const resource of profile.resources.filter(
        (r) => r.type === "Database"
      )) {
        const target = databaseTarget(resource);
        const address = isIP(target.host) ? target.host : aliases.get(target.host) ?? `198.18.${Math.floor(aliases.size / 250)}.${aliases.size % 250 + 1}`;
        if (!isIP(target.host)) aliases.set(target.host, address);
        if (routes.some(
          (route) => route.host === address && route.port === target.port
        ))
          throw new Error(
            "Database route collides with a reserved DNS alias; use distinct endpoint addresses"
          );
        const adapter = await startDatabaseProxy(resource, decide);
        closers.push(adapter.close);
        routes.push({
          host: address,
          port: target.port,
          proxyPort: adapter.port
        });
      }
      dns = createDnsAdapter(resources, decide, aliases);
      const dnsTcp = await startDnsTcp(dns);
      closers.push(dnsTcp.close);
      sequence = bundle.sequence;
      output({
        sessionId,
        sequence,
        environmentId,
        grants: profile.grants,
        boundaries: profile.boundaries,
        proxyPort: proxy.port,
        dnsPort: dnsTcp.port,
        routes
      });
    } else if (message.op === "authorize" && sequence !== void 0) {
      const { action, locator, context } = message;
      const type = action.startsWith(
        "process."
      ) ? "Process" : action === "file.metadata" ? "File" : "Network";
      if (![
        "process.signal",
        "process.privilege_attempt",
        "file.metadata",
        "network.listen",
        "network.connect"
      ].includes(action) || typeof locator !== "string")
        throw new Error("Invalid kernel action");
      const resource = type === "Network" ? networkResource(resources, locator) : resources.find(
        (r) => r.type === type && (r.locator === locator || type === "File" && locator.startsWith(r.locator + "/"))
      );
      output({
        allowed: await decide(
          action,
          { type, id: resource?.id ?? locator },
          context
        )
      });
    } else if (message.op === "dns" && sequence !== void 0) {
      if (typeof message.packet !== "string" || message.packet.length > 8192 || !/^[0-9a-f]+$/.test(message.packet) || message.packet.length % 2)
        throw new Error("Invalid DNS packet");
      output({
        packet: Buffer5.from(
          await dns(Buffer5.from(message.packet, "hex"))
        ).toString("hex")
      });
    } else if (message.op === "check" && sequence !== void 0) {
      await requestRefresh(dataDir()).catch(() => {
      });
      output({
        current: (await loadBundle(dataDir())).bundle.sequence === sequence
      });
    } else throw new Error("Invalid supervisor request");
  }
} catch (error) {
  process.stderr.write(`cleo policy worker: ${error.message}
`);
  process.exitCode = 1;
} finally {
  for (const close of closers) close();
  lines.close();
  process.stdin.destroy();
}
