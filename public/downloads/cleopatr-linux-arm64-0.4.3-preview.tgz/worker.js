// runtime/worker.ts
import { createInterface } from "node:readline";

// cli/cache.ts
import {
  mkdir,
  readFile,
  writeFile,
  rename,
  stat,
  unlink,
  lstat,
  chmod
} from "node:fs/promises";
import { join, resolve } from "node:path";
import { homedir } from "node:os";
import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import * as cedar from "@cedar-policy/cedar-wasm/nodejs";

// core/model.ts
var VERSION = "0.4.3";
var SCHEMA_VERSION = "3.0";
var RESOURCE_TYPES = [
  "Database",
  "File",
  "Endpoint",
  "MCPTool",
  "Process",
  "Network"
];
var ACTIONS = {
  "process.execute": "Process",
  "process.signal": "Process",
  "process.privilege_attempt": "Process",
  "file.read": "File",
  "file.write": "File",
  "file.create": "File",
  "file.delete": "File",
  "file.rename": "File",
  "file.metadata": "File",
  "network.connect": "Network",
  "network.listen": "Network",
  "dns.query": "Network",
  "http.request": "Endpoint",
  "mcp.tool.invoke": "MCPTool",
  "mcp.resource.read": "MCPTool",
  "mcp.prompt.get": "MCPTool",
  "database.connect": "Database",
  "database.query": "Database",
  "database.transaction": "Database"
};
var CONTEXT_FIELDS = {
  operation: "String",
  method: "String",
  host: "String",
  path: "String",
  executable: "String",
  cwd: "String",
  protocol: "String",
  port: "Long",
  tool: "String",
  server: "String",
  amount: "Long",
  confidence: "String",
  tables: "Set",
  argv: "Set",
  resolvedPath: "String",
  encrypted: "Boolean",
  semanticAvailable: "Boolean",
  withinWorkspace: "Boolean"
};
function ancestors(environments, id) {
  const result = [];
  let cursor = id;
  while (cursor) {
    if (result.includes(cursor))
      throw new Error("Environment hierarchy contains a cycle");
    const e = environments.find((x) => x.id === cursor);
    if (!e) throw new Error(`Unknown environment: ${cursor}`);
    result.push(cursor);
    cursor = e.parentId;
  }
  return result;
}
function effectivePolicies(snapshot, id) {
  const lineage = ancestors(snapshot.environments, id).reverse();
  const applicable = /* @__PURE__ */ new Map();
  for (const envId of lineage) {
    const environment = snapshot.environments.find((e) => e.id === envId);
    for (const policy of snapshot.policies)
      if (policy.enabled && policy.environmentIds.includes(envId) && !applicable.has(policy.id))
        applicable.set(policy.id, {
          policy,
          sourceEnvironmentId: envId,
          mode: "AUDIT"
        });
    for (const entry of applicable.values()) {
      const requested = environment.mode === "CUSTOM" ? environment.policyModes?.[entry.policy.id] ?? entry.mode : environment.mode ?? "AUDIT";
      if (requested === "ENFORCE") entry.mode = "ENFORCE";
    }
  }
  return [...applicable.values()].map(
    ({ policy, sourceEnvironmentId, mode }) => ({
      ...policy,
      mode,
      sourceEnvironmentId
    })
  );
}
function policiesFor(snapshot, id) {
  return effectivePolicies(snapshot, id);
}
function buildSchema() {
  const shape = {
    type: "Record",
    attributes: {
      name: { type: "String" },
      environment: { type: "String" },
      locator: { type: "String" }
    }
  };
  const entityTypes = {
    AgentSession: {
      shape: {
        type: "Record",
        attributes: {
          environment: { type: "String" },
          workspace: { type: "String" },
          humanId: { type: "String" }
        }
      }
    }
  };
  for (const type of RESOURCE_TYPES) entityTypes[type] = { shape };
  const attributes = Object.fromEntries(
    Object.entries(CONTEXT_FIELDS).map(([k, type]) => [
      k,
      type === "Set" ? { type, element: { type: "String" }, required: false } : { type, required: false }
    ])
  );
  return {
    Cleopatr: {
      entityTypes,
      actions: Object.fromEntries(
        Object.entries(ACTIONS).map(([name, type]) => [
          name,
          {
            appliesTo: {
              principalTypes: ["AgentSession"],
              resourceTypes: [type],
              context: { type: "Record", attributes }
            }
          }
        ])
      )
    }
  };
}
var SCHEMA = buildSchema();

// core/crypto.ts
var enc = new TextEncoder();
function unbase64(value) {
  return Uint8Array.from(atob(value), (c) => c.charCodeAt(0));
}
async function digest(value) {
  return Array.from(
    new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(value)))
  ).map((x) => x.toString(16).padStart(2, "0")).join("");
}
async function verifyBundle(signed, publicKey, tenant, minSequence = 0) {
  if (signed.algorithm !== "Ed25519" || await digest(signed.payload) !== signed.digest || signed.keyId !== await digest(publicKey.x))
    throw new Error("Bundle digest or signing key mismatch");
  const key = await crypto.subtle.importKey(
    "jwk",
    publicKey,
    { name: "Ed25519" },
    false,
    ["verify"]
  );
  if (!await crypto.subtle.verify(
    "Ed25519",
    key,
    unbase64(signed.signature),
    enc.encode(signed.payload)
  ))
    throw new Error("Bundle signature verification failed");
  const bundle = JSON.parse(signed.payload);
  if (bundle.tenant !== tenant)
    throw new Error("Bundle belongs to a different tenant");
  if (!Number.isSafeInteger(bundle.sequence) || bundle.sequence < 1 || bundle.sequence < minSequence)
    throw new Error("Rejected policy rollback");
  const legacy = bundle;
  const isLegacy = bundle.schemaVersion === "1.0" && bundle.minimumClientVersion === "0.1.0";
  if (!isLegacy && !(bundle.schemaVersion === "2.0" && bundle.minimumClientVersion === "0.2.0") && (bundle.schemaVersion !== SCHEMA_VERSION || !["0.3.0", "0.4.0", "0.4.1", "0.4.2", VERSION].includes(
    bundle.minimumClientVersion
  )))
    throw new Error("Bundle requires a different Cleopatr version");
  if (!Array.isArray(bundle.environmentIds) || !bundle.environmentIds.length || !Array.isArray(bundle.policies) || !Array.isArray(bundle.resources) || !Array.isArray(bundle.environments))
    throw new Error("Invalid bundle manifest");
  if (isLegacy) {
    if (legacy.mode !== "AUDIT" && legacy.mode !== "ENFORCE")
      throw new Error("Invalid legacy bundle mode");
    bundle.environments = bundle.environments.map((e) => ({
      ...e,
      mode: legacy.mode
    }));
    bundle.policies = bundle.policies.map((p) => ({
      ...p,
      status: "PUBLISHED"
    }));
    bundle.bundleId = legacy.releaseId ?? `legacy_${bundle.sequence}`;
  }
  if (!bundle.bundleId || bundle.environments.some(
    (e) => !["AUDIT", "CUSTOM", "ENFORCE"].includes(e.mode ?? "AUDIT") || Object.values(e.policyModes ?? {}).some(
      (mode) => mode !== "AUDIT" && mode !== "ENFORCE"
    )
  ))
    throw new Error("Invalid environment policy modes");
  if (!isLegacy && bundle.policies.some((p) => p.status !== "PUBLISHED" || p.published))
    throw new Error("Bundle contains unpublished policy content");
  if (bundle.client && (typeof bundle.client.id !== "string" || !bundle.client.id || typeof bundle.client.name !== "string" || !bundle.client.name.trim() || bundle.client.name.length > 200))
    throw new Error("Invalid signed client identity");
  return bundle;
}

// core/assessment.ts
var MAX_ASSESSMENT_BYTES = 128 * 1024;
var MAX_AUDIT_EVENT_BYTES = 160 * 1024;
var MAX_AUDIT_BATCH_BYTES = 180 * 1024;
var jsonBytes = (value) => new TextEncoder().encode(JSON.stringify(value)).length;
function captureAssessment(payload) {
  const serialized = JSON.stringify(payload);
  const bytes = new TextEncoder().encode(serialized).length;
  if (bytes > MAX_ASSESSMENT_BYTES)
    return { version: 1, status: "unavailable", reason: "too_large", bytes };
  return {
    version: 1,
    status: "captured",
    schemaVersion: SCHEMA_VERSION,
    payload: JSON.parse(serialized)
  };
}

// core/engine.ts
function validatePolicies(engine, policies) {
  const answer = engine.validate({
    schema: SCHEMA,
    policies: {
      staticPolicies: Object.fromEntries(policies.map((p) => [p.id, p.cedar]))
    }
  });
  return answer.type === "failure" ? {
    valid: false,
    errors: answer.errors.map((e) => e.message),
    warnings: answer.warnings.map((e) => e.message)
  } : {
    valid: !answer.validationErrors.length,
    errors: answer.validationErrors.map(
      (e) => `${e.policyId}: ${e.error.message}`
    ),
    warnings: answer.validationWarnings.map(
      (e) => `${e.policyId}: ${e.error.message}`
    )
  };
}
function evaluateWithModes(engine, snapshot, request, forceEnforce = false) {
  const start = performance.now();
  const policies = effectivePolicies(snapshot, request.environmentId);
  const environment = snapshot.environments.find(
    (e) => e.id === request.environmentId
  );
  const mode = forceEnforce ? "ENFORCE" : environment.mode ?? "AUDIT";
  const full = evaluate(engine, snapshot, request);
  const enforced = policies.filter((p) => forceEnforce || p.mode === "ENFORCE");
  const mustEnforce = forceEnforce || mode === "ENFORCE" || enforced.length > 0;
  const blocking = mustEnforce ? evaluate(engine, { ...snapshot, policies: enforced }, request) : void 0;
  const effectiveResult = blocking?.errors.length ? "ERROR" : blocking?.decision === "DENY" ? "BLOCKED" : full.decision === "DENY" ? "ALLOWED_AUDIT" : "ALLOWED";
  const policyDecisions = [];
  for (const policy of policies) {
    const single = evaluate(
      engine,
      { ...snapshot, policies: [policy] },
      request
    );
    if (single.determiningPolicies.includes(policy.id) || single.errors.length)
      policyDecisions.push({
        policyId: policy.id,
        policyName: policy.name,
        policyVersion: policy.published?.version ?? policy.revision,
        decision: single.errors.length ? "ERROR" : single.decision,
        mode: forceEnforce ? "ENFORCE" : policy.mode
      });
  }
  if (!policyDecisions.length || blocking?.decision === "DENY" && !blocking.determiningPolicies.length)
    policyDecisions.push({
      policyId: "",
      policyName: "Default deny (no permit matched)",
      policyVersion: 0,
      decision: "DENY",
      mode: mustEnforce ? "ENFORCE" : "AUDIT"
    });
  return {
    ...full,
    mode,
    policyDecisions,
    effectiveResult,
    allowed: effectiveResult === "ALLOWED" || effectiveResult === "ALLOWED_AUDIT",
    enforcementDecision: blocking?.decision,
    enforcementErrors: blocking?.errors ?? [],
    latencyUs: Math.round((performance.now() - start) * 1e3)
  };
}
function evaluate(engine, snapshot, request) {
  const start = performance.now();
  if (!ACTIONS[request.action] || ACTIONS[request.action] !== request.resource.type)
    throw new Error("Action and resource type do not match the schema");
  for (const [key, value] of Object.entries(request.context)) {
    const type = CONTEXT_FIELDS[key];
    if (!type) throw new Error(`Unsupported context field: ${key}`);
    if (type === "String" && typeof value !== "string" || type === "Long" && !Number.isSafeInteger(value) || type === "Boolean" && typeof value !== "boolean" || type === "Set" && (!Array.isArray(value) || !value.every((x) => typeof x === "string")))
      throw new Error(`Invalid value for context.${key}`);
  }
  const policies = policiesFor(snapshot, request.environmentId);
  const known = snapshot.resources.find((r) => r.id === request.resource.id);
  if (known && known.type !== request.resource.type)
    throw new Error("Resource type conflicts with the catalog");
  const principalName = request.principal ?? request.sessionId;
  if (typeof principalName !== "string" || !principalName.trim() || principalName.length > 200)
    throw new Error("A principal name of 1\u2013200 characters is required");
  const principal = { type: "Cleopatr::AgentSession", id: principalName };
  const resource = {
    type: `Cleopatr::${request.resource.type}`,
    id: request.resource.id
  };
  const parc = {
    principal,
    action: { type: "Cleopatr::Action", id: request.action },
    resource,
    context: request.context
  };
  const entities = [
    {
      uid: principal,
      attrs: {
        environment: request.environmentId,
        workspace: request.workspace ?? "",
        humanId: request.humanId ?? "local"
      },
      parents: []
    },
    {
      uid: resource,
      attrs: {
        name: known?.name ?? request.resource.id,
        environment: known?.environmentId ?? request.environmentId,
        locator: known?.locator ?? request.resource.id
      },
      parents: []
    }
  ];
  const payload = { ...parc, entities };
  const assessment = captureAssessment(payload);
  const answer = engine.isAuthorized({
    ...payload,
    context: request.context,
    entities,
    policies: {
      staticPolicies: Object.fromEntries(policies.map((p) => [p.id, p.cedar]))
    },
    schema: SCHEMA,
    validateRequest: true
  });
  if (answer.type === "failure")
    return {
      decision: "DENY",
      determiningPolicies: [],
      errors: answer.errors.map((e) => e.message),
      latencyUs: Math.round((performance.now() - start) * 1e3),
      parc,
      assessment,
      policyCount: policies.length
    };
  return {
    decision: answer.response.diagnostics.errors.length ? "DENY" : answer.response.decision.toUpperCase(),
    determiningPolicies: answer.response.diagnostics.reason,
    errors: answer.response.diagnostics.errors.map(
      (e) => `${e.policyId}: ${e.error.message}`
    ),
    latencyUs: Math.round((performance.now() - start) * 1e3),
    parc,
    assessment,
    policyCount: policies.length
  };
}

// cli/cache.ts
var REFRESH_INTERVAL_MS = 3e5;
function dataDir() {
  if (process.env.CLEO_HOME) return resolve(process.env.CLEO_HOME);
  const project = resolve(".cleo");
  const previous = join(homedir(), ".config", "cleopatr");
  return existsSync(join(project, "config")) || existsSync(join(project, "config.json")) || !existsSync(join(previous, "config.json")) ? project : previous;
}
async function atomicJson(path, value) {
  const temp = path + "." + crypto.randomUUID() + ".tmp";
  await writeFile(temp, JSON.stringify(value, null, 2), {
    mode: 384,
    flag: "wx"
  });
  try {
    await rename(temp, path);
  } catch (e) {
    await unlink(temp).catch(() => {
    });
    throw e;
  }
}
async function readConfig(dir = dataDir()) {
  const config = JSON.parse(
    await readFile(join(dir, "config"), "utf8").catch(
      (error) => {
        if (error.code !== "ENOENT") throw error;
        return readFile(join(dir, "config.json"), "utf8");
      }
    )
  );
  validateConfig(config);
  return config;
}
function validateConfig(config) {
  const url = new URL(config.server);
  if (url.username || url.password || !["http:", "https:"].includes(url.protocol) || url.protocol === "http:" && !["localhost", "127.0.0.1", "[::1]"].includes(url.hostname))
    throw new Error(
      "Control plane must use HTTPS (HTTP is allowed only on loopback)"
    );
  if (!config.tenant || !config.token || !config.clientId || config.clientName !== void 0 && (typeof config.clientName !== "string" || !config.clientName.trim() || config.clientName.length > 200) || !config.publicKey?.x || !Array.isArray(config.environmentIds) || !config.environmentIds.length || config.environmentIds.some((x) => typeof x !== "string") || config.environment !== void 0 && (typeof config.environment !== "string" || !config.environment.trim()))
    throw new Error("Invalid enrollment configuration");
}
async function readCache(dir = dataDir()) {
  try {
    return JSON.parse(await readFile(join(dir, "bundle.json"), "utf8"));
  } catch (e) {
    if (e.code === "ENOENT") return null;
    throw new Error(
      "Policy cache is unreadable; run cleo sync or import a verified bundle"
    );
  }
}
async function loadBundle(dir = dataDir()) {
  const config = await readConfig(dir);
  const cache = await readCache(dir);
  if (!cache)
    throw new Error(
      "No verified policy bundle. Run cleo sync or import a signed bundle before authorizing."
    );
  const bundle = await verifyBundle(
    cache.signed,
    config.publicKey,
    config.tenant,
    cache.highWater
  );
  verifyScope(bundle, config);
  const validation = validatePolicies(cedar, bundle.policies);
  if (!validation.valid)
    throw new Error(
      "Cached policy validation failed: " + validation.errors.join("; ")
    );
  return { config, cache, bundle };
}
function verifyScope(bundle, config) {
  if (bundle.client && bundle.client.id !== config.clientId)
    throw new Error("Signed client identity does not match this enrollment");
  if (JSON.stringify(bundle.schema) !== JSON.stringify(SCHEMA))
    throw new Error("Bundle schema does not match this client");
  const expected = bundle.environments.filter(
    (e) => ancestors(bundle.environments, e.id).some(
      (id) => config.environmentIds.includes(id)
    )
  ).map((e) => e.id).sort();
  if (JSON.stringify([...bundle.environmentIds].sort()) !== JSON.stringify(expected))
    throw new Error("Bundle assignment does not match this client enrollment");
}
async function withActivationLock(dir, work) {
  const lock = join(dir, "activation.lock");
  const started = Date.now();
  while (true) {
    try {
      await writeFile(lock, String(Date.now()), { flag: "wx", mode: 384 });
      break;
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
      try {
        if (Date.now() - (await stat(lock)).mtimeMs > 3e4) await unlink(lock);
      } catch {
      }
      if (Date.now() - started > 3e3)
        throw new Error("Policy activation is busy; retry");
      await new Promise((r) => setTimeout(r, 10));
    }
  }
  try {
    return await work();
  } finally {
    await unlink(lock).catch(() => {
    });
  }
}
async function activate(signed, dir = dataDir(), checkedAt = Date.now()) {
  return withActivationLock(
    dir,
    () => activateUnlocked(signed, dir, checkedAt)
  );
}
async function activateUnlocked(signed, dir, checkedAt) {
  const config = await readConfig(dir);
  const cache = await readCache(dir);
  const bundle = await verifyBundle(
    signed,
    config.publicKey,
    config.tenant,
    cache?.highWater ?? 0
  );
  verifyScope(bundle, config);
  const validation = validatePolicies(cedar, bundle.policies);
  if (!validation.valid)
    throw new Error(
      "Policy schema validation failed: " + validation.errors.join("; ")
    );
  if (cache) {
    const old = await verifyBundle(
      cache.signed,
      config.publicKey,
      config.tenant,
      cache.highWater
    );
    if (old.sequence === bundle.sequence && cache.signed.digest !== signed.digest)
      throw new Error("Policy bundle contents changed without a new sequence");
  }
  const next = {
    signed,
    checkedAt,
    activatedAt: Date.now(),
    highWater: Math.max(cache?.highWater ?? 0, bundle.sequence),
    etag: `"${signed.digest}"`
  };
  await atomicJson(join(dir, "bundle.json"), next);
  return bundle;
}
function needsRefresh(cache, at = Date.now()) {
  return !cache || at - cache.checkedAt >= REFRESH_INTERVAL_MS;
}
async function requestRefresh(dir = dataDir(), entry = process.argv[1]) {
  const cache = await readCache(dir);
  if (!needsRefresh(cache)) return false;
  const lock = join(dir, "refresh.lock");
  try {
    await writeFile(lock, String(Date.now()), { flag: "wx", mode: 384 });
  } catch (e) {
    if (e.code !== "EEXIST") throw e;
    const age = Date.now() - (await stat(lock)).mtimeMs;
    if (age > 6e4) {
      await unlink(lock).catch(() => {
      });
    }
    return false;
  }
  try {
    const args = entry.endsWith(".ts") ? ["--import", "tsx", entry, "__refresh"] : [entry, "__refresh"];
    const child = spawn(process.execPath, args, {
      detached: true,
      stdio: "ignore",
      env: { ...process.env, CLEO_HOME: dir }
    });
    child.on("error", () => {
      void unlink(lock).catch(() => {
      });
    });
    child.unref();
    return true;
  } catch (e) {
    await unlink(lock).catch(() => {
    });
    throw e;
  }
}
async function sync(dir = dataDir(), fetcher = fetch) {
  const config = await readConfig(dir);
  const cache = await readCache(dir);
  const response = await fetcher(new URL("/api/v1/bundles", config.server), {
    headers: {
      authorization: `Bearer ${config.token}`,
      ...cache ? { "if-none-match": cache.etag } : {}
    },
    signal: AbortSignal.timeout(4e3),
    redirect: "error"
  });
  if (response.status === 304) {
    if (!cache) throw new Error("Server returned 304 without a local bundle");
    await withActivationLock(dir, async () => {
      await loadBundle(dir);
      const current = await readCache(dir);
      if (current?.etag === cache.etag)
        await atomicJson(join(dir, "bundle.json"), {
          ...current,
          checkedAt: Date.now()
        });
    });
    return { changed: false, sequence: cache.highWater };
  }
  if (!response.ok)
    throw new Error(
      `Policy refresh failed (${response.status}); the previous verified bundle is retained`
    );
  const text = await response.text();
  if (text.length > 5e6) throw new Error("Policy bundle is too large");
  const bundle = await activate(JSON.parse(text), dir);
  return { changed: true, sequence: bundle.sequence };
}
async function refreshWorker(dir = dataDir()) {
  try {
    await sync(dir);
    await atomicJson(join(dir, "refresh-status.json"), {
      ok: true,
      time: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (e) {
    await atomicJson(join(dir, "refresh-status.json"), {
      ok: false,
      time: (/* @__PURE__ */ new Date()).toISOString(),
      error: e.message
    });
  } finally {
    await unlink(join(dir, "refresh.lock")).catch(() => {
    });
  }
}

// cli/options.ts
function resolveEnvironment(bundle, selector) {
  const byId = bundle.environments.find((e) => e.id === selector);
  if (byId) {
    if (!bundle.environmentIds.includes(byId.id))
      throw new Error(
        `This client is not assigned to environment: ${selector}`
      );
    return byId.id;
  }
  const matches = bundle.environments.filter(
    (e) => bundle.environmentIds.includes(e.id) && e.name.toLowerCase() === selector.toLowerCase()
  );
  if (matches.length > 1)
    throw new Error(
      `Environment name is ambiguous: ${selector}. Use an environment ID.`
    );
  if (!matches.length)
    throw new Error(
      `Environment not found in the assigned policy bundle: ${selector}. Run cleo sync to check for new environments.`
    );
  return matches[0].id;
}

// cli/runtime.ts
import {
  readFile as readFile2,
  writeFile as writeFile2,
  appendFile,
  mkdir as mkdir2,
  readdir,
  unlink as unlink2,
  rename as rename2
} from "node:fs/promises";
import { join as join2 } from "node:path";
import * as cedar2 from "@cedar-policy/cedar-wasm/nodejs";
async function authorize(request, options = {}) {
  const dir = options.dir ?? dataDir();
  const { bundle, cache, config } = await loadBundle(dir);
  if (options.expectedSequence !== void 0 && bundle.sequence !== options.expectedSequence)
    throw new Error(
      "Policy snapshot changed; this supervisor session must be restarted"
    );
  if (!bundle.environmentIds.includes(request.environmentId))
    throw new Error("This client is not assigned to the requested environment");
  if (options.refresh !== false)
    await requestRefresh(dir, options.entry).catch(() => {
    });
  const principal = bundle.client?.name ?? config.clientName;
  if (!principal)
    throw new Error(
      "Client name is missing from this older enrollment. Run cleo sync to receive your signed client identity, or use a new enrollment file for offline access."
    );
  request = { ...request, principal };
  let result;
  try {
    result = evaluateWithModes(
      cedar2,
      bundle,
      request,
      options.mode === "ENFORCE"
    );
  } catch (e) {
    const mode = options.mode === "ENFORCE" ? "ENFORCE" : bundle.environments.find((env) => env.id === request.environmentId)?.mode ?? "AUDIT";
    const enforce = mode === "ENFORCE" || effectivePolicies(bundle, request.environmentId).some(
      (p) => p.mode === "ENFORCE"
    );
    result = {
      decision: "DENY",
      determiningPolicies: [],
      errors: [e.message],
      latencyUs: 0,
      parc: {
        principal: { type: "Cleopatr::AgentSession", id: principal },
        action: { type: "Cleopatr::Action", id: request.action },
        resource: {
          type: `Cleopatr::${request.resource?.type ?? "Unknown"}`,
          id: request.resource?.id ?? ""
        },
        context: request.context
      },
      policyCount: 0,
      assessment: {
        version: 1,
        status: "unavailable",
        reason: "not_evaluated"
      },
      mode,
      effectiveResult: enforce ? "ERROR" : "ALLOWED_AUDIT",
      allowed: !enforce,
      policyDecisions: [
        {
          policyId: "",
          policyName: "Authorization error",
          policyVersion: 0,
          decision: "ERROR",
          mode: enforce ? "ENFORCE" : "AUDIT"
        }
      ]
    };
  }
  const decision = {
    ...result,
    bundleId: bundle.bundleId,
    sequence: bundle.sequence,
    stale: Date.now() - cache.checkedAt >= 3e5
  };
  await Promise.all(
    decision.policyDecisions.map(
      (policy) => spool(
        {
          id: "evt_" + crypto.randomUUID(),
          kind: "decision",
          time: (/* @__PURE__ */ new Date()).toISOString(),
          sessionId: request.sessionId,
          environmentId: request.environmentId,
          action: request.action,
          resource: request.resource?.id,
          assessment: decision.assessment,
          ...policy,
          effectiveResult: policy.decision === "ALLOW" ? "ALLOWED" : policy.mode === "AUDIT" ? "ALLOWED_AUDIT" : policy.decision === "ERROR" ? "ERROR" : "BLOCKED",
          bundleId: bundle.bundleId,
          sequence: bundle.sequence,
          determiningPolicies: policy.policyId ? [policy.policyId] : [],
          adapter: options.adapter ?? "explicit",
          confidence: request.context?.confidence ?? "configured"
        },
        dir
      ).catch(
        (e) => process.stderr.write(
          `cleo: audit spool error: ${e.message}
`
        )
      )
    )
  );
  return decision;
}
async function spool(event, dir = dataDir()) {
  const spoolDir = join2(dir, "spool");
  await mkdir2(spoolDir, { recursive: true, mode: 448 });
  const files = await readdir(spoolDir);
  if (files.length >= 1e4) {
    const allows = files.filter((f) => f.endsWith(".allow.json")).sort();
    if (allows.length) await unlink2(join2(spoolDir, allows[0])).catch(() => {
    });
    else {
      await appendFile(
        join2(dir, "audit-overflow.log"),
        `${(/* @__PURE__ */ new Date()).toISOString()} spool full; ${event.decision} event not persisted
`,
        { mode: 384 }
      );
      return;
    }
  }
  const name = `${Date.now()}-${crypto.randomUUID()}.${event.decision === "ALLOW" ? "allow" : "deny"}.json`;
  const tmp = join2(spoolDir, name + ".tmp");
  await writeFile2(tmp, JSON.stringify(event), { mode: 384 });
  await rename2(tmp, join2(spoolDir, name));
}
async function flushAudit(dir = dataDir()) {
  const config = await readConfig(dir);
  const path = join2(dir, "spool");
  const files = (await readdir(path).catch(() => [])).filter((f) => f.endsWith(".json")).sort().slice(0, 100);
  if (!files.length) return 0;
  const events = [];
  const selected = [];
  let bytes = jsonBytes({ events: [] });
  for (const file of files) {
    const event = JSON.parse(
      await readFile2(join2(path, file), "utf8")
    );
    const size = jsonBytes(event) + (events.length ? 1 : 0);
    if (bytes + size > MAX_AUDIT_BATCH_BYTES) break;
    bytes += size;
    selected.push(file);
    events.push(event);
  }
  if (!events.length) throw new Error("Audit record exceeds upload size limit");
  const response = await fetch(new URL("/api/v1/audit", config.server), {
    method: "POST",
    headers: {
      authorization: `Bearer ${config.token}`,
      "content-type": "application/json"
    },
    body: JSON.stringify({ events }),
    signal: AbortSignal.timeout(4e3),
    redirect: "error"
  });
  if (!response.ok) throw new Error(`Audit upload failed (${response.status})`);
  for (const file of selected) await unlink2(join2(path, file)).catch(() => {
  });
  return selected.length;
}

// runtime/profile.ts
import * as cedar3 from "@cedar-policy/cedar-wasm/nodejs";
import { posix } from "node:path";

// runtime/url.ts
function httpPath(url) {
  if (/%(?:2f|5c|25)/i.test(url.pathname))
    throw new Error("Encoded separators and double encoding are unsupported");
  const path = decodeURIComponent(url.pathname);
  let hasControl = false;
  for (let index = 0; index < path.length; index++) {
    const code = path.charCodeAt(index);
    if (code < 32 || code === 127) hasControl = true;
  }
  if (/[\\;]/.test(path) || path.includes("//") || hasControl)
    throw new Error("Ambiguous HTTP path");
  return path;
}

// runtime/profile.ts
var rights = {
  execute: 1,
  write: 2,
  read: 4 | 8,
  delete: 16 | 32,
  create: 128 | 256 | 4096,
  rename: 8192,
  truncate: 16384
};
var semanticActions = /* @__PURE__ */ new Set([
  "http.request",
  "network.connect",
  "dns.query",
  "mcp.tool.invoke",
  "mcp.resource.read",
  "mcp.prompt.get",
  "database.connect",
  "database.query",
  "database.transaction"
]);
var supportedActions = /* @__PURE__ */ new Set([
  "process.execute",
  "file.read",
  "file.write",
  "file.create",
  "file.delete",
  "file.rename",
  "network.connect",
  "http.request",
  "mcp.tool.invoke",
  "mcp.resource.read",
  "mcp.prompt.get"
]);
function variable(node, name) {
  if (!node || typeof node !== "object") return false;
  if (!Array.isArray(node) && node.Var === name) return true;
  return Object.values(node).some((v) => variable(v, name));
}
function onlySemantic(scope) {
  const entity = scope.entity;
  const entities = scope.entities;
  const values = scope.op === "==" && entity ? [entity] : scope.op === "in" && entities ? entities : [];
  return values.length > 0 && values.every(
    (e) => e.type === "Cleopatr::Action" && semanticActions.has(e.id ?? "")
  );
}
function staticFileContext(ast) {
  const scope = ast.action;
  const selected = scope.entity ? [scope.entity] : Array.isArray(scope.entities) ? scope.entities : [];
  if (!selected.length || !selected.every(
    (e) => e && typeof e === "object" && !Array.isArray(e) && typeof e.id === "string" && e.id.startsWith("file.")
  ))
    return false;
  const walk = (node) => {
    if (!node || typeof node !== "object") return true;
    if (!Array.isArray(node)) {
      if (node.Var === "context") return false;
      for (const op of [".", "has"]) {
        const value = node[op];
        if (value && typeof value === "object" && !Array.isArray(value) && value.attr === "withinWorkspace" && value.left && typeof value.left === "object" && !Array.isArray(value.left) && value.left.Var === "context")
          return true;
      }
    }
    return Object.values(node).every(walk);
  };
  return walk(ast.conditions);
}
function compileProfile(bundle, environmentId, principal, enforce) {
  const lineage = new Set(ancestors(bundle.environments, environmentId));
  const resources = bundle.resources.filter(
    (r) => lineage.has(r.environmentId)
  );
  const policies = effectivePolicies(bundle, environmentId);
  for (const policy of policies) {
    const parsed = cedar3.policyToJson(policy.cedar);
    if (parsed.type !== "success")
      throw new Error(`Cannot parse policy ${policy.name}`);
    const ast = parsed.json;
    const checkReferences = (value) => {
      if (!value || typeof value !== "object") return;
      if (!Array.isArray(value) && typeof value.type === "string" && ["Cleopatr::File", "Cleopatr::Process"].includes(value.type) && !resources.some(
        (r) => r.id === value.id && `Cleopatr::${r.type}` === value.type
      ))
        throw new Error(
          `Policy "${policy.name}" references an OS resource outside this environment's catalog`
        );
      Object.values(value).forEach(checkReferences);
    };
    checkReferences(ast);
    const scope = ast.action;
    const selected = scope.entity ? [scope.entity] : Array.isArray(scope.entities) ? scope.entities : [];
    if (selected.some(
      (entity) => entity && typeof entity === "object" && !Array.isArray(entity) && (typeof entity.id !== "string" || !supportedActions.has(entity.id))
    ))
      throw new Error(
        `Policy "${policy.name}" requires an action this Linux backend cannot mediate`
      );
    if (!onlySemantic(ast.action) && (variable(ast.conditions, "context") && !staticFileContext(ast) || variable(ast.conditions, "action")))
      throw new Error(
        `Policy "${policy.name}" needs per-operation OS context. This Landlock backend supports context-free OS policies only; no session was started.`
      );
  }
  for (const resource of resources.filter((r) => r.type === "MCPTool")) {
    let url;
    try {
      url = new URL(resource.locator);
    } catch {
      throw new Error(
        `MCP resource ${resource.name} requires an HTTP transport URL for this backend`
      );
    }
    if (!["http:", "https:"].includes(url.protocol) || url.username || url.password)
      throw new Error(`Unsupported MCP transport for ${resource.name}`);
  }
  for (const resource of resources.filter(
    (r) => r.type === "Endpoint" || r.type === "Network"
  )) {
    let url;
    try {
      url = new URL(resource.locator);
    } catch {
      throw new Error(
        `${resource.name} requires an absolute HTTP(S) URL in this backend`
      );
    }
    if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.search || url.hash || url.hostname.includes("*") || resource.type === "Network" && url.pathname !== "/")
      throw new Error(
        `Unsupported ${resource.type} locator for ${resource.name}; use an origin${resource.type === "Endpoint" ? " and optional path" : ""}`
      );
    httpPath(url);
  }
  const grants = /* @__PURE__ */ new Map();
  const identities = /* @__PURE__ */ new Set();
  for (const resource of resources.filter(
    (r) => ["Endpoint", "Network", "MCPTool"].includes(r.type)
  )) {
    const url = new URL(resource.locator);
    const key = JSON.stringify([
      resource.type,
      url.origin,
      resource.type === "Network" ? "" : httpPath(url),
      resource.type === "MCPTool" ? url.search : "",
      resource.type === "MCPTool" ? decodeURIComponent(url.hash.slice(1)) : ""
    ]);
    if (identities.has(key))
      throw new Error(
        `Ambiguous duplicate protocol resource: ${resource.name}`
      );
    identities.add(key);
  }
  const add = (path, access) => grants.set(path, (grants.get(path) ?? 0) | access);
  const decide = (action, type, id) => {
    const request = {
      environmentId,
      sessionId: "profile",
      principal,
      action,
      resource: { type, id },
      workspace: "/workspace",
      context: type === "File" ? {
        withinWorkspace: resources.some(
          (r) => r.id === id && (r.locator === "/workspace" || r.locator.startsWith("/workspace/"))
        )
      } : {}
    };
    const result = evaluateWithModes(cedar3, bundle, request, enforce);
    if (result.errors.length || result.enforcementErrors.length)
      throw new Error(
        `OS profile evaluation failed for ${id}: ${[...result.errors, ...result.enforcementErrors].join("; ")}`
      );
    return result.allowed;
  };
  const fileResources = resources.filter((r) => r.type === "File");
  const pathFor = (value) => {
    if (!value.startsWith("/") || posix.normalize(value) !== value || value === "/" || value.includes("\0"))
      throw new Error(
        `Use a normalized, absolute, non-root sandbox resource path: ${value}`
      );
    if (![
      "/workspace",
      "/usr",
      "/bin",
      "/lib",
      "/lib64",
      "/etc",
      "/tmp",
      "/dev"
    ].some((p) => value === p || value.startsWith(p + "/")))
      throw new Error(
        `Resource path is outside the supported sandbox roots: ${value}`
      );
    return value;
  };
  for (const resource of fileResources) {
    const path = pathFor(resource.locator);
    if (fileResources.some(
      (other) => other.id !== resource.id && (other.locator === path || other.locator.startsWith(path + "/") || path.startsWith(other.locator + "/"))
    ))
      throw new Error(
        `Overlapping File resources cannot be safely compiled: ${path}`
      );
    let access = 0;
    const create = decide("file.create", "File", resource.id);
    const remove = decide("file.delete", "File", resource.id);
    const rename3 = decide("file.rename", "File", resource.id);
    if ((create && remove) !== rename3)
      throw new Error(
        `Landlock cannot independently represent rename versus create/delete for ${path}; align these permissions or use another backend.`
      );
    if (decide("file.read", "File", resource.id)) access |= rights.read;
    if (decide("file.write", "File", resource.id))
      access |= rights.write | rights.truncate;
    if (create) access |= rights.create;
    if (remove) access |= rights.delete;
    if (rename3) access |= rights.rename;
    if (access) add(path, access);
  }
  for (const resource of resources.filter((r) => r.type === "Process")) {
    if (decide("process.execute", "Process", resource.id))
      add(pathFor(resource.locator), rights.execute);
  }
  return {
    principal,
    environmentId,
    boundaries: fileResources.map((r) => r.locator),
    grants: [...grants].map(([path, access]) => ({ path, access })),
    resources
  };
}
function requireExecutableGrant(profile) {
  const identity = `Cleopatr::AgentSession::${JSON.stringify(profile.principal)}`;
  if (!profile.resources.some((resource) => resource.type === "Process"))
    throw new Error(
      `No executable is permitted: Environment ${JSON.stringify(profile.environmentId)} has no Process resources in its catalog or parent Environments. The principal is ${identity}. Register the agent, interpreters/tools and ELF loader as Process resources; a process.execute permit alone cannot create the executable allowlist. Runtime directories also need File read permissions.`
    );
  if (!profile.grants.some((grant) => (grant.access & rights.execute) !== 0))
    throw new Error(
      `No executable is permitted for ${identity} in Environment ${JSON.stringify(profile.environmentId)}. No effective process.execute permit allows the registered Process resources, or a forbid blocks them. Check principal/resource scopes and Enforce modes. Runtime directories also need File read permissions. Network policies are evaluated only after the process can start.`
    );
}

// runtime/adapters/http.ts
import http from "node:http";
import { Buffer } from "node:buffer";
import https from "node:https";

// runtime/adapters/mcp-http.ts
var calls = {
  "tools/call": "mcp.tool.invoke",
  "resources/read": "mcp.resource.read",
  "prompts/get": "mcp.prompt.get"
};
var administration = /* @__PURE__ */ new Set([
  "initialize",
  "ping",
  "tools/list",
  "resources/list",
  "resources/templates/list",
  "prompts/list",
  "notifications/initialized",
  "notifications/cancelled",
  "notifications/progress"
]);
function mcpResources(resources, target) {
  return resources.filter((resource) => {
    if (resource.type !== "MCPTool") return false;
    try {
      const url = new URL(resource.locator);
      return url.origin === target.origin && url.pathname === target.pathname && url.search === target.search;
    } catch {
      return false;
    }
  });
}
async function authorizeMcpBody(body, target, resources, decide) {
  const message = JSON.parse(
    new TextDecoder("utf-8", { fatal: true }).decode(body)
  );
  if (!message || typeof message !== "object" || Array.isArray(message))
    return false;
  const msg = message;
  if (msg.jsonrpc !== "2.0" || typeof msg.method !== "string") return false;
  if (administration.has(msg.method)) return true;
  const action = calls[msg.method];
  if (!action || !msg.params || typeof msg.params !== "object" || Array.isArray(msg.params))
    return false;
  const params = msg.params;
  const name = msg.method === "resources/read" ? params.uri : params.name;
  if (typeof name !== "string" || !name || name.length > 2048) return false;
  const resource = resources.find(
    (r) => decodeURIComponent(new URL(r.locator).hash.slice(1)) === name
  ) ?? resources.find((r) => !new URL(r.locator).hash);
  if (!resource) return false;
  const args = params.arguments;
  const amount = args && typeof args === "object" && !Array.isArray(args) ? args.amount : void 0;
  if (amount !== void 0 && !Number.isSafeInteger(amount)) return false;
  return decide(
    action,
    { type: "MCPTool", id: resource.id },
    {
      tool: name,
      server: target.origin,
      operation: msg.method,
      protocol: "mcp-http",
      semanticAvailable: true,
      confidence: "proxy-observed",
      ...amount === void 0 ? {} : { amount }
    }
  );
}

// runtime/adapters/http.ts
var hop = /* @__PURE__ */ new Set([
  "connection",
  "proxy-connection",
  "keep-alive",
  "proxy-authenticate",
  "proxy-authorization",
  "te",
  "trailer",
  "transfer-encoding",
  "upgrade"
]);
function headers(message) {
  const exclude = /* @__PURE__ */ new Set([
    ...hop,
    ...(message.headers.connection ?? "").toLowerCase().split(",").map((v) => v.trim())
  ]);
  return Object.fromEntries(
    Object.entries(message.headers).filter(([key]) => !exclude.has(key))
  );
}
function match(resources, url) {
  const path = httpPath(url);
  return resources.filter((r) => r.type === "Endpoint").map((resource) => {
    try {
      const url2 = new URL(resource.locator);
      return { resource, url: url2, path: httpPath(url2) };
    } catch {
      return void 0;
    }
  }).filter(
    (r) => !!r && r.url.origin === url.origin && (r.path === "/" || path === r.path || path.startsWith(r.path.replace(/\/$/, "") + "/"))
  ).sort((a, b) => b.path.length - a.path.length)[0]?.resource;
}
async function startHttpProxy(resources, decide) {
  const sockets = /* @__PURE__ */ new Set();
  const server = http.createServer(
    { maxHeaderSize: 16384, requestTimeout: 3e4, headersTimeout: 1e4 },
    (req, res) => {
      void forward(req, res).catch(() => {
        if (!res.headersSent) res.writeHead(502);
        res.end("Cleopatr adapter failed closed");
      });
    }
  );
  server.on("connection", (socket) => {
    sockets.add(socket);
    socket.on("close", () => sockets.delete(socket));
    socket.setTimeout(3e4, () => socket.destroy());
  });
  server.maxConnections = 128;
  server.maxRequestsPerSocket = 128;
  server.keepAliveTimeout = 5e3;
  server.on("connect", (req, socket) => {
    void (async () => {
      const authority = req.url ?? "";
      if (!/^(?:\[[0-9a-fA-F:]+\]|[a-zA-Z0-9.-]+):[0-9]{1,5}$/.test(authority))
        throw new Error("Invalid CONNECT authority");
      const url = new URL(`https://${authority}`);
      const port = Number(url.port || 443);
      if (port < 1 || port > 65535) throw new Error("Invalid CONNECT port");
      const endpoint = match(resources, url);
      const allowed = await decide(
        "http.request",
        { type: "Endpoint", id: endpoint?.id ?? url.origin },
        {
          method: "CONNECT",
          host: url.hostname,
          port,
          protocol: "https",
          encrypted: true,
          semanticAvailable: false,
          confidence: "proxy-observed"
        }
      );
      if (allowed) {
        const network = resources.find((r) => {
          try {
            return r.type === "Network" && new URL(r.locator).origin === url.origin;
          } catch {
            return false;
          }
        });
        await decide(
          "network.connect",
          { type: "Network", id: network?.id ?? url.origin },
          {
            host: url.hostname,
            port,
            protocol: "tcp",
            semanticAvailable: false,
            confidence: "proxy-observed"
          }
        );
      }
    })().catch(() => {
    }).finally(() => {
      socket.end(
        "HTTP/1.1 403 Forbidden\r\nConnection: close\r\nContent-Length: 0\r\n\r\n"
      );
    });
  });
  server.on("upgrade", (_req, socket) => socket.destroy());
  server.on("clientError", (_error, socket) => socket.destroy());
  async function forward(req, res) {
    const url = new URL(req.url ?? "");
    if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.hash)
      throw new Error("Invalid proxy target");
    const resource = match(resources, url);
    const context = {
      method: req.method ?? "",
      host: url.hostname,
      path: httpPath(url),
      port: Number(url.port || (url.protocol === "https:" ? 443 : 80)),
      protocol: url.protocol.slice(0, -1),
      encrypted: url.protocol === "https:",
      semanticAvailable: true,
      confidence: "proxy-observed"
    };
    if (!await decide(
      "http.request",
      { type: "Endpoint", id: resource?.id ?? url.origin },
      context
    )) {
      res.writeHead(403).end("Blocked by Cleopatr policy");
      return;
    }
    if (!resource) {
      res.writeHead(403).end("Destination is not in the signed resource catalog");
      return;
    }
    const network = resources.find((r) => {
      if (r.type !== "Network") return false;
      try {
        return new URL(r.locator).origin === url.origin;
      } catch {
        return false;
      }
    });
    if (!await decide(
      "network.connect",
      { type: "Network", id: network?.id ?? url.origin },
      {
        host: context.host,
        port: context.port,
        protocol: "tcp",
        confidence: "proxy-observed",
        semanticAvailable: true
      }
    )) {
      res.writeHead(403).end("Connection blocked by Cleopatr policy");
      return;
    }
    const outgoing = { ...headers(req), host: url.host };
    let body;
    const mcp = mcpResources(resources, url);
    const mcpOrigin = resources.some((r) => {
      if (r.type !== "MCPTool") return false;
      try {
        return new URL(r.locator).origin === url.origin;
      } catch {
        return false;
      }
    });
    if (mcpOrigin && !mcp.length) {
      res.writeHead(403).end("MCP origin requires an exact registered transport endpoint");
      return;
    }
    if (mcp.length) {
      if (req.method === "POST") {
        const chunks = [];
        let length = 0;
        for await (const chunk of req) {
          length += chunk.length;
          if (length > 1024 * 1024) throw new Error("MCP body exceeds one MiB");
          chunks.push(Buffer.from(chunk));
        }
        const complete = Buffer.concat(chunks);
        body = complete;
        if (!await authorizeMcpBody(complete, url, mcp, decide)) {
          res.writeHead(403).end("MCP operation blocked by Cleopatr");
          return;
        }
      } else if (!["GET", "DELETE"].includes(req.method ?? "")) {
        res.writeHead(405).end();
        return;
      }
    }
    const upstream = (url.protocol === "https:" ? https : http).request(
      url,
      {
        method: req.method,
        headers: outgoing,
        timeout: 1e4,
        agent: false
        // Node validates upstream TLS hostname/certificate; no redirect following or tunnel fallback.
      },
      (response) => {
        res.writeHead(response.statusCode ?? 502, headers(response));
        response.pipe(res);
      }
    );
    upstream.on(
      "timeout",
      () => upstream.destroy(new Error("upstream timeout"))
    );
    upstream.on("error", () => {
      if (!res.headersSent) res.writeHead(502);
      res.end("Upstream unavailable");
    });
    res.on("close", () => upstream.destroy());
    if (body) upstream.end(body);
    else req.pipe(upstream);
  }
  await new Promise((resolve2, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve2);
  });
  return {
    port: server.address().port,
    close: () => {
      for (const socket of sockets) socket.destroy();
      server.close();
    }
  };
}

// runtime/worker.ts
if (process.getuid?.() !== 0 || process.env.CLEO_SUPERVISOR !== "1")
  throw new Error("Policy worker must be started by the privileged supervisor");
if (process.argv[2] === "__refresh") {
  await refreshWorker();
  await flushAudit().catch(() => {
  });
  process.exit(0);
}
var lines = createInterface({ input: process.stdin, crlfDelay: Infinity });
var output = (value) => process.stdout.write(JSON.stringify(value) + "\n");
var close;
var sequence;
try {
  for await (const line of lines) {
    if (line.length > 65536) throw new Error("Supervisor message too large");
    const message = JSON.parse(line);
    if (message.op === "start" && sequence === void 0) {
      const { bundle, config } = await loadBundle(dataDir());
      const environmentId = resolveEnvironment(
        bundle,
        message.request.environment ?? config.environment ?? config.environmentIds[0]
      );
      const principal = bundle.client?.name ?? config.clientName;
      if (!principal) throw new Error("Signed client identity is required");
      const sessionId = "agt_" + crypto.randomUUID();
      const profile = compileProfile(
        bundle,
        environmentId,
        principal,
        message.request.enforce === true
      );
      requireExecutableGrant(profile);
      const proxy = await startHttpProxy(
        profile.resources,
        async (action, resource, context) => {
          const current = await loadBundle(dataDir());
          if (current.bundle.sequence !== bundle.sequence) return false;
          const result = await authorize(
            {
              environmentId,
              sessionId,
              action,
              resource,
              context,
              workspace: "/workspace"
            },
            {
              mode: message.request.enforce ? "ENFORCE" : "AUDIT",
              entry: process.argv[1],
              adapter: action.startsWith("mcp.") ? "mcp-http" : "http-proxy",
              expectedSequence: bundle.sequence
            }
          );
          const names = result.determiningPolicies.map(
            (id) => JSON.stringify(
              bundle.policies.find((policy) => policy.id === id)?.name ?? id
            )
          );
          process.stderr.write(
            `cleo: ${result.mode} \xB7 ${action} \xB7 ${result.effectiveResult} \xB7 ${names.join(", ") || "default deny"}
`
          );
          return result.allowed;
        }
      );
      close = proxy.close;
      sequence = bundle.sequence;
      output({
        sessionId,
        sequence,
        environmentId,
        grants: profile.grants,
        boundaries: profile.boundaries,
        proxyPort: proxy.port
      });
    } else if (message.op === "check" && sequence !== void 0) {
      await requestRefresh(dataDir()).catch(() => {
      });
      output({
        current: (await loadBundle(dataDir())).bundle.sequence === sequence
      });
    } else throw new Error("Invalid supervisor request");
  }
} catch (error) {
  process.stderr.write(`cleo policy worker: ${error.message}
`);
  process.exitCode = 1;
} finally {
  close?.();
  lines.close();
  process.stdin.destroy();
}
