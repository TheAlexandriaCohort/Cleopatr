// runtime/vm/guest.ts
import { spawn } from "node:child_process";
import {
  mkdir as mkdir2,
  readFile as readFile2,
  writeFile as writeFile2,
  cp,
  chmod as chmod2,
  chown,
  readdir,
  unlink as unlink2,
  stat as stat2,
  rename as rename2
} from "node:fs/promises";
import { join as join2 } from "node:path";
import { setTimeout as delay } from "node:timers/promises";

// cli/cache.ts
import {
  mkdir,
  readFile,
  writeFile,
  rename,
  stat,
  unlink,
  lstat,
  chmod
} from "node:fs/promises";
import { join, resolve } from "node:path";
import { homedir } from "node:os";
import { existsSync } from "node:fs";
import * as cedar from "@cedar-policy/cedar-wasm/nodejs";

// core/model.ts
var VERSION = "0.5.1";
var SCHEMA_VERSION = "3.0";
var RESOURCE_TYPES = [
  "Database",
  "File",
  "Endpoint",
  "MCPTool",
  "Process",
  "Network"
];
var ACTIONS = {
  "process.execute": "Process",
  "process.signal": "Process",
  "process.privilege_attempt": "Process",
  "file.read": "File",
  "file.write": "File",
  "file.create": "File",
  "file.delete": "File",
  "file.rename": "File",
  "file.metadata": "File",
  "network.connect": "Network",
  "network.listen": "Network",
  "dns.query": "Network",
  "http.request": "Endpoint",
  "mcp.tool.invoke": "MCPTool",
  "mcp.resource.read": "MCPTool",
  "mcp.prompt.get": "MCPTool",
  "database.connect": "Database",
  "database.query": "Database",
  "database.transaction": "Database"
};
var CONTEXT_FIELDS = {
  operation: "String",
  method: "String",
  host: "String",
  path: "String",
  executable: "String",
  cwd: "String",
  protocol: "String",
  port: "Long",
  tool: "String",
  server: "String",
  amount: "Long",
  confidence: "String",
  tables: "Set",
  argv: "Set",
  resolvedPath: "String",
  encrypted: "Boolean",
  semanticAvailable: "Boolean",
  withinWorkspace: "Boolean"
};
function ancestors(environments, id) {
  const result = [];
  let cursor = id;
  while (cursor) {
    if (result.includes(cursor))
      throw new Error("Environment hierarchy contains a cycle");
    const e = environments.find((x) => x.id === cursor);
    if (!e) throw new Error(`Unknown environment: ${cursor}`);
    result.push(cursor);
    cursor = e.parentId;
  }
  return result;
}
function buildSchema() {
  const shape = {
    type: "Record",
    attributes: {
      name: { type: "String" },
      environment: { type: "String" },
      locator: { type: "String" }
    }
  };
  const entityTypes = {
    AgentSession: {
      shape: {
        type: "Record",
        attributes: {
          environment: { type: "String" },
          workspace: { type: "String" },
          humanId: { type: "String" }
        }
      }
    }
  };
  for (const type of RESOURCE_TYPES) entityTypes[type] = { shape };
  const attributes = Object.fromEntries(
    Object.entries(CONTEXT_FIELDS).map(([k, type]) => [
      k,
      type === "Set" ? { type, element: { type: "String" }, required: false } : { type, required: false }
    ])
  );
  return {
    Cleopatr: {
      entityTypes,
      actions: Object.fromEntries(
        Object.entries(ACTIONS).map(([name, type]) => [
          name,
          {
            appliesTo: {
              principalTypes: ["AgentSession"],
              resourceTypes: [type],
              context: { type: "Record", attributes }
            }
          }
        ])
      )
    }
  };
}
var SCHEMA = buildSchema();

// core/crypto.ts
var enc = new TextEncoder();
function unbase64(value) {
  return Uint8Array.from(atob(value), (c) => c.charCodeAt(0));
}
async function digest(value) {
  return Array.from(
    new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(value)))
  ).map((x) => x.toString(16).padStart(2, "0")).join("");
}
async function verifyBundle(signed, publicKey, tenant, minSequence = 0) {
  if (signed.algorithm !== "Ed25519" || await digest(signed.payload) !== signed.digest || signed.keyId !== await digest(publicKey.x))
    throw new Error("Bundle digest or signing key mismatch");
  const key = await crypto.subtle.importKey(
    "jwk",
    publicKey,
    { name: "Ed25519" },
    false,
    ["verify"]
  );
  if (!await crypto.subtle.verify(
    "Ed25519",
    key,
    unbase64(signed.signature),
    enc.encode(signed.payload)
  ))
    throw new Error("Bundle signature verification failed");
  const bundle = JSON.parse(signed.payload);
  if (bundle.tenant !== tenant)
    throw new Error("Bundle belongs to a different tenant");
  if (!Number.isSafeInteger(bundle.sequence) || bundle.sequence < 1 || bundle.sequence < minSequence)
    throw new Error("Rejected policy rollback");
  const legacy = bundle;
  const isLegacy = bundle.schemaVersion === "1.0" && bundle.minimumClientVersion === "0.1.0";
  if (!isLegacy && !(bundle.schemaVersion === "2.0" && bundle.minimumClientVersion === "0.2.0") && (bundle.schemaVersion !== SCHEMA_VERSION || ![
    "0.3.0",
    "0.4.0",
    "0.4.1",
    "0.4.2",
    "0.4.3",
    "0.4.4",
    "0.5.0",
    VERSION
  ].includes(bundle.minimumClientVersion)))
    throw new Error("Bundle requires a different Cleopatr version");
  if (!Array.isArray(bundle.environmentIds) || !bundle.environmentIds.length || !Array.isArray(bundle.policies) || !Array.isArray(bundle.resources) || !Array.isArray(bundle.environments))
    throw new Error("Invalid bundle manifest");
  if (isLegacy) {
    if (legacy.mode !== "AUDIT" && legacy.mode !== "ENFORCE")
      throw new Error("Invalid legacy bundle mode");
    bundle.environments = bundle.environments.map((e) => ({
      ...e,
      mode: legacy.mode
    }));
    bundle.policies = bundle.policies.map((p) => ({
      ...p,
      status: "PUBLISHED"
    }));
    bundle.bundleId = legacy.releaseId ?? `legacy_${bundle.sequence}`;
  }
  if (!bundle.bundleId || bundle.environments.some(
    (e) => !["AUDIT", "CUSTOM", "ENFORCE"].includes(e.mode ?? "AUDIT") || Object.values(e.policyModes ?? {}).some(
      (mode) => mode !== "AUDIT" && mode !== "ENFORCE"
    )
  ))
    throw new Error("Invalid environment policy modes");
  if (!isLegacy && bundle.policies.some((p) => p.status !== "PUBLISHED" || p.published))
    throw new Error("Bundle contains unpublished policy content");
  if (bundle.client && (typeof bundle.client.id !== "string" || !bundle.client.id || typeof bundle.client.name !== "string" || !bundle.client.name.trim() || bundle.client.name.length > 200))
    throw new Error("Invalid signed client identity");
  return bundle;
}

// core/assessment.ts
var MAX_ASSESSMENT_BYTES = 128 * 1024;
var MAX_AUDIT_EVENT_BYTES = 160 * 1024;
var MAX_AUDIT_BATCH_BYTES = 180 * 1024;

// core/engine.ts
function validatePolicies(engine, policies) {
  const answer = engine.validate({
    schema: SCHEMA,
    policies: {
      staticPolicies: Object.fromEntries(policies.map((p) => [p.id, p.cedar]))
    }
  });
  return answer.type === "failure" ? {
    valid: false,
    errors: answer.errors.map((e) => e.message),
    warnings: answer.warnings.map((e) => e.message)
  } : {
    valid: !answer.validationErrors.length,
    errors: answer.validationErrors.map(
      (e) => `${e.policyId}: ${e.error.message}`
    ),
    warnings: answer.validationWarnings.map(
      (e) => `${e.policyId}: ${e.error.message}`
    )
  };
}

// cli/cache.ts
function dataDir() {
  if (process.env.CLEO_HOME) return resolve(process.env.CLEO_HOME);
  const project = resolve(".cleo");
  const previous = join(homedir(), ".config", "cleopatr");
  return existsSync(join(project, "config")) || existsSync(join(project, "config.json")) || !existsSync(join(previous, "config.json")) ? project : previous;
}
async function atomicJson(path, value) {
  const temp = path + "." + crypto.randomUUID() + ".tmp";
  await writeFile(temp, JSON.stringify(value, null, 2), {
    mode: 384,
    flag: "wx"
  });
  try {
    await rename(temp, path);
  } catch (e) {
    await unlink(temp).catch(() => {
    });
    throw e;
  }
}
async function readConfig(dir = dataDir()) {
  const config = JSON.parse(
    await readFile(join(dir, "config"), "utf8").catch(
      (error) => {
        if (error.code !== "ENOENT") throw error;
        return readFile(join(dir, "config.json"), "utf8");
      }
    )
  );
  validateConfig(config);
  return config;
}
function validateConfig(config) {
  const url = new URL(config.server);
  if (url.username || url.password || !["http:", "https:"].includes(url.protocol) || url.protocol === "http:" && !["localhost", "127.0.0.1", "[::1]"].includes(url.hostname))
    throw new Error(
      "Control plane must use HTTPS (HTTP is allowed only on loopback)"
    );
  if (!config.tenant || !config.token || !config.clientId || config.clientName !== void 0 && (typeof config.clientName !== "string" || !config.clientName.trim() || config.clientName.length > 200) || !config.publicKey?.x || !Array.isArray(config.environmentIds) || !config.environmentIds.length || config.environmentIds.some((x) => typeof x !== "string") || config.environment !== void 0 && (typeof config.environment !== "string" || !config.environment.trim()))
    throw new Error("Invalid enrollment configuration");
}
async function readCache(dir = dataDir()) {
  try {
    return JSON.parse(await readFile(join(dir, "bundle.json"), "utf8"));
  } catch (e) {
    if (e.code === "ENOENT") return null;
    throw new Error(
      "Policy cache is unreadable; run cleo sync or import a verified bundle"
    );
  }
}
async function loadBundle(dir = dataDir()) {
  const config = await readConfig(dir);
  const cache = await readCache(dir);
  if (!cache)
    throw new Error(
      "No verified policy bundle. Run cleo sync or import a signed bundle before authorizing."
    );
  const bundle = await verifyBundle(
    cache.signed,
    config.publicKey,
    config.tenant,
    cache.highWater
  );
  verifyScope(bundle, config);
  const validation = validatePolicies(cedar, bundle.policies);
  if (!validation.valid)
    throw new Error(
      "Cached policy validation failed: " + validation.errors.join("; ")
    );
  return { config, cache, bundle };
}
function verifyScope(bundle, config) {
  if (bundle.client && bundle.client.id !== config.clientId)
    throw new Error("Signed client identity does not match this enrollment");
  if (JSON.stringify(bundle.schema) !== JSON.stringify(SCHEMA))
    throw new Error("Bundle schema does not match this client");
  const expected = bundle.environments.filter(
    (e) => ancestors(bundle.environments, e.id).some(
      (id) => config.environmentIds.includes(id)
    )
  ).map((e) => e.id).sort();
  if (JSON.stringify([...bundle.environmentIds].sort()) !== JSON.stringify(expected))
    throw new Error("Bundle assignment does not match this client enrollment");
}
async function withActivationLock(dir, work) {
  const lock = join(dir, "activation.lock");
  const started = Date.now();
  while (true) {
    try {
      await writeFile(lock, String(Date.now()), { flag: "wx", mode: 384 });
      break;
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
      try {
        if (Date.now() - (await stat(lock)).mtimeMs > 3e4) await unlink(lock);
      } catch {
      }
      if (Date.now() - started > 3e3)
        throw new Error("Policy activation is busy; retry");
      await new Promise((r) => setTimeout(r, 10));
    }
  }
  try {
    return await work();
  } finally {
    await unlink(lock).catch(() => {
    });
  }
}
async function activate(signed, dir = dataDir(), checkedAt = Date.now()) {
  return withActivationLock(
    dir,
    () => activateUnlocked(signed, dir, checkedAt)
  );
}
async function activateUnlocked(signed, dir, checkedAt) {
  const config = await readConfig(dir);
  const cache = await readCache(dir);
  const bundle = await verifyBundle(
    signed,
    config.publicKey,
    config.tenant,
    cache?.highWater ?? 0
  );
  verifyScope(bundle, config);
  const validation = validatePolicies(cedar, bundle.policies);
  if (!validation.valid)
    throw new Error(
      "Policy schema validation failed: " + validation.errors.join("; ")
    );
  if (cache) {
    const old = await verifyBundle(
      cache.signed,
      config.publicKey,
      config.tenant,
      cache.highWater
    );
    if (old.sequence === bundle.sequence && cache.signed.digest !== signed.digest)
      throw new Error("Policy bundle contents changed without a new sequence");
  }
  const next = {
    signed,
    checkedAt,
    activatedAt: Date.now(),
    highWater: Math.max(cache?.highWater ?? 0, bundle.sequence),
    etag: `"${signed.digest}"`
  };
  await atomicJson(join(dir, "bundle.json"), next);
  return bundle;
}

// runtime/vm/guest.ts
var shared = "/session-live";
var state = "/var/lib/cleopatr";
var request = JSON.parse(
  await readFile2(join2(shared, "request.json"), "utf8")
);
if (!Number.isSafeInteger(request.uid) || request.uid < 1 || !Number.isSafeInteger(request.gid) || request.gid < 0)
  throw new Error("Invalid VM workload identity");
var daemon;
var timer;
var running = false;
var code = 125;
async function exportEvents(limit = 100) {
  const files = (await readdir(join2(state, "spool")).catch(() => [])).filter((file) => file.endsWith(".json")).slice(0, limit);
  for (const file of files) {
    const output = join2(shared, "events", file);
    await writeFile2(
      output + ".tmp",
      await readFile2(join2(state, "spool", file)),
      { mode: 384 }
    );
    await chown(output + ".tmp", request.uid, request.gid);
    const { rename: rename3 } = await import("node:fs/promises");
    await rename3(output + ".tmp", output);
    await unlink2(join2(state, "spool", file));
  }
}
async function update() {
  if (running) return;
  running = true;
  try {
    const incoming = JSON.parse(
      await readFile2(join2(shared, "bundle.json"), "utf8")
    );
    const current = await loadBundle(state);
    if (JSON.parse(incoming.signed.payload).sequence > current.bundle.sequence)
      await activate(incoming.signed, state);
    await exportEvents();
  } catch (error) {
    process.stderr.write(`cleo VM sync: ${error.message}
`);
  } finally {
    running = false;
  }
}
try {
  await mkdir2(state, { recursive: true, mode: 448 });
  await chmod2(state, 448);
  const config = JSON.parse(
    await readFile2(join2(shared, "config.json"), "utf8")
  );
  await atomicJson(join2(state, "config"), config);
  const incoming = JSON.parse(
    await readFile2(join2(shared, "bundle.json"), "utf8")
  );
  await atomicJson(join2(state, "bundle.json"), incoming);
  await loadBundle(state);
  await cp("/opt/cleopatr-rootfs", "/var/lib/cleopatr-rootfs", {
    recursive: true
  });
  await mkdir2("/etc/cleopatr", { recursive: true });
  await atomicJson("/etc/cleopatr/supervisor.json", {
    allowedUids: [request.uid],
    node: "/usr/local/bin/node",
    worker: "/usr/lib/cleopatr/worker.js",
    state,
    rootfs: "/var/lib/cleopatr-rootfs",
    workspace: "/srv/workspace",
    workspaceMasks: request.masks,
    cgroupRoot: "/sys/fs/cgroup/cleopatr",
    memoryMax: 1073741824,
    pidsMax: 256
  });
  daemon = spawn("/usr/lib/cleopatr/cleo-supervisor", ["serve"], {
    stdio: ["ignore", "ignore", "inherit"]
  });
  daemon.on(
    "error",
    (error) => process.stderr.write(`cleo supervisor: ${error.message}
`)
  );
  let ready = false;
  for (let attempt = 0; attempt < 100; attempt++) {
    if (await stat2("/run/cleopatr/supervisor.sock").then((s) => s.isSocket()).catch(() => false)) {
      ready = true;
      break;
    }
    if (daemon.exitCode !== null) break;
    await delay(100);
  }
  if (!ready) throw new Error("Linux supervisor did not become ready");
  const readyFile = join2(shared, "ready.json");
  await atomicJson(readyFile + ".pending", { sessionId: request.sessionId });
  await chown(readyFile + ".pending", request.uid, request.gid);
  await rename2(readyFile + ".pending", readyFile);
  timer = setInterval(() => void update(), 1e3);
  const args = [
    "/usr/lib/cleopatr/cleo.js",
    "--backend",
    "linux",
    "--env",
    request.environment
  ];
  if (request.enforce) args.push("--enforce");
  if (request.audit) args.push("--audit");
  args.push("--", ...request.argv);
  const child = spawn("/usr/local/bin/node", args, {
    uid: request.uid,
    gid: request.gid,
    stdio: "inherit",
    env: {
      PATH: "/usr/local/bin:/usr/bin:/bin",
      HOME: "/tmp",
      NODE_ENV: "production"
    }
  });
  code = await new Promise((resolve2, reject) => {
    child.once("error", reject);
    child.once(
      "close",
      (status, signal) => resolve2(status ?? (signal === "SIGINT" ? 130 : 143))
    );
  });
} catch (error) {
  process.stderr.write(`cleo VM: ${error.message}
`);
} finally {
  if (timer) clearInterval(timer);
  while (running) await delay(10);
  await exportEvents(Number.MAX_SAFE_INTEGER).catch(
    (error) => process.stderr.write(`cleo VM audit export: ${error.message}
`)
  );
  daemon?.kill("SIGTERM");
  const output = join2(shared, "exit.json");
  await atomicJson(output, { code });
  await chown(output, request.uid, request.gid);
}
