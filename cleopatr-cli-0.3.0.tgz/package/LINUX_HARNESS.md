# Linux harness implementation

The new native runtime is an **experimental, opt-in backend**, not a production containment certification. It introduces real kernel enforcement alongside the existing cooperative CLI. The full V1 objective remains unfinished: the coverage limits below are functional requirements still to implement, not simply documentation or testing tasks.

## Components and trust boundary

`cleo --backend linux -- command` invokes the non-setuid `/usr/lib/cleopatr/cleo-supervisor launch` client. The client passes its three standard streams and a bounded launch request to a root-owned Unix socket. The service authenticates the kernel-provided `SO_PEERCRED` UID against a root-owned enrollment configuration. A caller cannot supply a worker executable, rootfs, cache path, UID, mount list or upstream proxy port.

The root supervisor:

1. Starts a protected policy worker using a fixed Node executable, cleared environment, bounded IPC and heap size. The worker verifies the signed bundle using the same Cedar implementation as the application.
2. Resolves the requested Environment against the enrollment's assigned scope, including inherited published policies and policy modes. The principal remains the enrolled client name; the session ID is separate provenance.
3. Creates a cgroup v2 session with memory and process limits. A gate keeps the child stopped until cgroup membership is established.
4. Creates private mount, PID, network, IPC and UTS namespaces. The rootfs is read-only, the explicitly configured workspace is mounted at `/workspace`, and `/tmp` is private. The host policy store and control socket are not mounted into the workload.
5. Drops supplementary groups, UID/GID and bounding capabilities, sets `no_new_privs`, and installs Landlock and a syscall allowlist before the first agent exec. A trusted namespace init reaps children. Descendants inherit the cgroup and restrictions.
6. Handles TCP connect notifications using copied socket-address facts and `SECCOMP_IOCTL_NOTIF_ADDFD`. It does **not** inspect a mutable pointer and then use `SECCOMP_USER_NOTIF_FLAG_CONTINUE`. Only the session's semantic HTTP proxy is reachable. Raw sockets, UDP, host Unix sockets, namespace escapes, ptrace, BPF and io_uring are outside the supported syscall boundary.
7. Kills the whole cgroup when the initial command exits, the launcher disconnects, the policy worker fails, or a newer signed policy snapshot is activated. Updated OS grants require a new launch; they are not silently applied to an already-running Landlock domain.

The root configuration, enrollment, cached bundle and rollback high-water mark, and audit spool live outside the agent's filesystem. Root ownership and non-writable ancestry are checked. This is a different trust boundary from the same-user `.cleo` cooperative cache. A malicious host administrator, a compromised kernel, and a malicious enrolled human outside the agent's namespace are outside this backend's threat model.

The launcher deliberately inherits stdin/stdout/stderr. These are explicitly delegated file capabilities; Landlock does not retroactively mediate an already-open output file. Socket and directory descriptors are rejected as standard streams. Other inherited descriptors are closed on exec.

## Enforced and supported coverage

| Boundary | Current behavior | Limit |
| --- | --- | --- |
| Process | Kernel pre-exec Landlock grants for individual executable files; inherited by descendants | No per-exec argv predicates or per-exec decision event stream |
| Filesystem | Kernel read/write/create/delete/rename/truncate restrictions on disjoint directory resources | Context-free Cedar only; no per-file deletion rules, overlapping exceptions, or per-operation audit stream |
| Network | Private network namespace plus seccomp-mediated connections to the session proxy; direct connections fail closed | No general DNS/UDP/IPv6 route support or `network.listen` adapter |
| HTTP | HTTP/1.1 forward proxy, catalog destination matching, HTTP and network Cedar checks before forwarding, redacted policy events | No opaque CONNECT, WebSocket upgrade or HTTP/2 support |
| HTTPS | An absolute `https://` request sent to the local HTTP proxy uses validated TLS upstream | Standard HTTPS clients generally use CONNECT, which is rejected; TLS interception and scoped trust are not implemented |
| MCP HTTP | Recognized catalog endpoints, JSON-RPC tools/resources/prompts, bounded immutable request body, typed integer `amount`, explicit administrative method allowlist | No JSON-RPC batches, arbitrary typed argument schemas, server-initiated response correlation, or discovery cache |
| MCP stdio | Existing cooperative adapter remains available | It is not yet integrated into the protected supervisor's process/pipe orchestration |
| PostgreSQL/MySQL | Direct network bypass is blocked | Wire-protocol mediation, SQL parsing, prepared statements and TLS are not implemented |
| Audit | HTTP/MCP policy decisions use the protected spool | Kernel filesystem/process denials are not yet individually converted to Cedar activity events |

Landlock grants combine by union. A broad parent directory grant cannot represent a denied child exception. The compiler therefore rejects overlapping File resources, and the supervisor also resolves paths inside the namespace and rejects aliases/overlaps before exec. File resources for this backend must identify directories; Process resources must identify individual files.

Landlock's rename semantics also share create/remove rights. The compiler rejects combinations that cannot preserve Cedar's decisions. It rejects OS policies using dynamic `context` rather than evaluating them with invented facts. HTTP and MCP policies can use their adapters' observed context. Resource locators use **sandbox paths**, such as `/workspace/project`, not host paths.

Admission also rejects explicitly scoped actions with no adapter and OS entity references outside the Environment's resource catalog. MCP resources must identify HTTP transport URLs. MCP origins are dedicated: requests to changed paths or queries are rejected instead of falling back to generic HTTP handling, which would bypass tool policies.

Endpoint resources use absolute HTTP(S) origins with optional paths; Network resources use HTTP(S) origins. Wildcards, CIDRs and query-scoped endpoint identities are not supported by this backend and are rejected. Catalog matching and Cedar use the same decoded URI path. Ambiguous encoded separators, double encoding and repeated separators are rejected. This supplies HTTP facts, not application-specific routing or business-operation semantics.

Audit policies do not produce policy-based blocking, but the isolation floor and declared capability requirements apply in both modes. Uncatalogued filesystem paths, unmediated network traffic and unsupported syscalls remain unavailable. Audit mode is not an unrestricted host process with comprehensive syscall observation.

## Requirements and building

Linux with Landlock ABI 5 or newer (Linux 6.10+ with Landlock enabled), cgroup v2 delegation with memory/pids controllers and `cgroup.kill`, seccomp user notification and FD injection, mount/PID/network namespaces, root for the service, and Node 22.13+ for the protected Cedar worker are required. The service refuses startup if required protection is absent. The unprivileged client never retries through the cooperative backend after a protected launch failure.

```sh
npm run build:runtime
cargo build --locked --release --manifest-path runtime/native/Cargo.toml
```

The JS worker and launcher are written to `dist-runtime`. The native binary is written to `runtime/native/target/release/cleo-supervisor`. Build the native program on the target Linux architecture; compiling it on macOS only produces a refusal stub, not a Linux sandbox.

For the Apple Silicon development environment, the reproducible test runner builds Linux ARM64 artifacts in Docker and places the native binary in `dist-runtime/cleo-supervisor`:

```sh
npm run test:runtime:linux
```

This boots a disposable Debian kernel in QEMU inside Docker. It does not change Docker Desktop's kernel or install a Mac kernel extension. Test logs are retained in `dist-runtime/vm`. The VM recipe currently targets ARM64; the syscall code also includes x86-64, which still needs its own end-to-end validation.

After the Linux build/tests, `npm run package:runtime` produces an architecture-labeled preview archive and SHA-256 checksum in `public/downloads`. It includes the native supervisor, JS worker/launcher, pinned Cedar WASM dependency, configuration example, service file and this guide. It does not include enrollment credentials or a workload rootfs. Node 22.13+ is still required on the Linux host.

## Installation on a test Linux host

No privileged service has been installed on the development Mac. Installation is a Linux administrator operation:

1. Install the native binary, `worker.js`, `cleo.js`, `package.json` and bundled `node_modules` under root-owned `/usr/lib/cleopatr`. Keep every code/dependency directory root-owned and not group/world writable.
2. Create root-owned `/var/lib/cleopatr` with mode `0700`. Enroll and sync using `CLEO_HOME=/var/lib/cleopatr` and the installed CLI as root. Enrollment credentials and trust configuration must not be stored in the workload workspace.
3. Provision a dedicated, root-owned rootfs containing the required interpreters, binaries, libraries and certificates. It must contain `/workspace`, `/tmp` and `/proc` mount points with mode `0755`. Its files and directories must not be group/world writable. Do not use the host's `/` as the rootfs.
4. Create a dedicated workspace under a protected parent directory, such as `/srv/cleopatr-workspace`, and assign its content to the enrolled UID. Define sandbox directory and executable Resources and compatible policies in Cleopatr.
5. Review `runtime/supervisor.example.json`, install it as `/etc/cleopatr/supervisor.json`, and set the enrolled UID, trusted Node/worker paths, rootfs, workspace and delegated cgroup path. The service uses a fixed configuration path; agent requests cannot override it.
6. Review and install `runtime/systemd/cleopatr-supervisor.service`. Run the native `doctor` as root before starting the service. Use a disposable host until the remaining release gates have passed.

```sh
cleo --backend linux --env PCI -- /usr/bin/python3 /workspace/agent.py

# With the existing interactive zsh integration enabled:
cleo --backend linux --enforce --env PCI | python3 /workspace/agent.py
```

The root enrollment configuration supplies the default Environment. The CLI can also forward the Environment selector from `.cleo/config` (or legacy `config.json`); it does not forward that file's credentials or trust configuration. `--env` selects an assigned ID or unique name and takes precedence. `--enforce` can strengthen policy modes; it cannot weaken centrally enforced policies. Proxy variables are set inside the workload. Other host environment variables and secrets are not inherited.

Policy refresh remains a five-minute, non-blocking background operation. A failed refresh preserves the last verified bundle. A successful new snapshot causes existing sessions to terminate and require relaunch, because Landlock permissions cannot be relaxed or replaced in place. Revocation push and immediate offline invalidation are not implemented.

## Production release gates still open

- Support or explicitly model per-operation OS policies and audit events, including argv, filesystem metadata and independent rename semantics.
- Implement session-scoped HTTPS inspection/trust, certificate pinning behavior, HTTP/2 and robust TLS failure reporting.
- Implement PostgreSQL and MySQL wire protocols, parsers, prepared statements, transaction/error state and validated TLS, with real client compatibility suites.
- Integrate protected MCP stdio and complete MCP HTTP discovery/argument/response handling.
- Add DNS provenance, broader network compatibility, full terminal/job control and multi-workspace provisioning.
- Add adversarial concurrency/path replacement tests, protocol fuzzing, denial-of-service and supervisor-crash tests, x86-64 validation, performance measurements, packaging and independent privilege-boundary review.

These limits must remain visible in product claims. Passing the current kernel tests does not establish the full implementation document's definition of V1 done.

Design references: [Landlock userspace API](https://docs.kernel.org/userspace-api/landlock.html), [seccomp and userspace notifications](https://docs.kernel.org/userspace-api/seccomp_filter.html), and [cgroup v2](https://docs.kernel.org/admin-guide/cgroup-v2.html).
