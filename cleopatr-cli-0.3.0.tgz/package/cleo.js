#!/usr/bin/env node

// cli/main.ts
import { readFile as readFile3, realpath, access, stat as stat2 } from "node:fs/promises";
import { constants } from "node:fs";
import { join as join3, resolve as resolve2, delimiter, basename } from "node:path";
import { spawn as spawn2 } from "node:child_process";
import { createInterface } from "node:readline";
import { platform, release } from "node:os";

// cli/cache.ts
import {
  mkdir,
  readFile,
  writeFile,
  rename,
  stat,
  unlink,
  lstat,
  chmod
} from "node:fs/promises";
import { join, resolve } from "node:path";
import { homedir } from "node:os";
import { spawn } from "node:child_process";
import { existsSync } from "node:fs";
import * as cedar from "@cedar-policy/cedar-wasm/nodejs";

// core/model.ts
var VERSION = "0.3.0";
var SCHEMA_VERSION = "3.0";
var RESOURCE_TYPES = [
  "Database",
  "File",
  "Endpoint",
  "MCPTool",
  "Process",
  "Network"
];
var ACTIONS = {
  "process.execute": "Process",
  "process.signal": "Process",
  "process.privilege_attempt": "Process",
  "file.read": "File",
  "file.write": "File",
  "file.create": "File",
  "file.delete": "File",
  "file.rename": "File",
  "file.metadata": "File",
  "network.connect": "Network",
  "network.listen": "Network",
  "dns.query": "Network",
  "http.request": "Endpoint",
  "mcp.tool.invoke": "MCPTool",
  "mcp.resource.read": "MCPTool",
  "mcp.prompt.get": "MCPTool",
  "database.connect": "Database",
  "database.query": "Database",
  "database.transaction": "Database"
};
var CONTEXT_FIELDS = {
  operation: "String",
  method: "String",
  host: "String",
  path: "String",
  executable: "String",
  cwd: "String",
  protocol: "String",
  port: "Long",
  tool: "String",
  server: "String",
  amount: "Long",
  confidence: "String",
  tables: "Set",
  argv: "Set",
  resolvedPath: "String",
  encrypted: "Boolean",
  semanticAvailable: "Boolean",
  withinWorkspace: "Boolean"
};
function ancestors(environments, id) {
  const result = [];
  let cursor = id;
  while (cursor) {
    if (result.includes(cursor))
      throw new Error("Environment hierarchy contains a cycle");
    const e = environments.find((x) => x.id === cursor);
    if (!e) throw new Error(`Unknown environment: ${cursor}`);
    result.push(cursor);
    cursor = e.parentId;
  }
  return result;
}
function effectivePolicies(snapshot, id) {
  const lineage = ancestors(snapshot.environments, id).reverse();
  const applicable = /* @__PURE__ */ new Map();
  for (const envId of lineage) {
    const environment2 = snapshot.environments.find((e) => e.id === envId);
    for (const policy of snapshot.policies)
      if (policy.enabled && policy.environmentIds.includes(envId))
        applicable.set(policy.id, { policy, sourceEnvironmentId: envId });
    for (const policyId of environment2.excludedPolicyIds ?? [])
      applicable.delete(policyId);
  }
  const target = snapshot.environments.find((e) => e.id === id);
  return [...applicable.values()].map(({ policy, sourceEnvironmentId }) => {
    let mode2 = "AUDIT";
    if (target.mode && target.mode !== "CUSTOM") mode2 = target.mode;
    else if (target.mode === "CUSTOM") {
      for (const envId of lineage.slice(lineage.indexOf(sourceEnvironmentId)).reverse()) {
        const env = snapshot.environments.find((e) => e.id === envId);
        if (env.policyModes?.[policy.id]) {
          mode2 = env.policyModes[policy.id];
          break;
        }
        if (env.mode && env.mode !== "CUSTOM") {
          mode2 = env.mode;
          break;
        }
      }
    }
    return { ...policy, mode: mode2, sourceEnvironmentId };
  });
}
function policiesFor(snapshot, id) {
  return effectivePolicies(snapshot, id);
}
function buildSchema() {
  const shape = {
    type: "Record",
    attributes: {
      name: { type: "String" },
      environment: { type: "String" },
      locator: { type: "String" }
    }
  };
  const entityTypes = {
    AgentSession: {
      shape: {
        type: "Record",
        attributes: {
          environment: { type: "String" },
          workspace: { type: "String" },
          humanId: { type: "String" }
        }
      }
    }
  };
  for (const type of RESOURCE_TYPES) entityTypes[type] = { shape };
  const attributes = Object.fromEntries(
    Object.entries(CONTEXT_FIELDS).map(([k, type]) => [
      k,
      type === "Set" ? { type, element: { type: "String" }, required: false } : { type, required: false }
    ])
  );
  return {
    Cleopatr: {
      entityTypes,
      actions: Object.fromEntries(
        Object.entries(ACTIONS).map(([name, type]) => [
          name,
          {
            appliesTo: {
              principalTypes: ["AgentSession"],
              resourceTypes: [type],
              context: { type: "Record", attributes }
            }
          }
        ])
      )
    }
  };
}
var SCHEMA = buildSchema();

// core/crypto.ts
var enc = new TextEncoder();
function unbase64(value2) {
  return Uint8Array.from(atob(value2), (c) => c.charCodeAt(0));
}
async function digest(value2) {
  return Array.from(
    new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(value2)))
  ).map((x) => x.toString(16).padStart(2, "0")).join("");
}
async function verifyBundle(signed, publicKey, tenant, minSequence = 0) {
  if (signed.algorithm !== "Ed25519" || await digest(signed.payload) !== signed.digest || signed.keyId !== await digest(publicKey.x))
    throw new Error("Bundle digest or signing key mismatch");
  const key = await crypto.subtle.importKey(
    "jwk",
    publicKey,
    { name: "Ed25519" },
    false,
    ["verify"]
  );
  if (!await crypto.subtle.verify(
    "Ed25519",
    key,
    unbase64(signed.signature),
    enc.encode(signed.payload)
  ))
    throw new Error("Bundle signature verification failed");
  const bundle = JSON.parse(signed.payload);
  if (bundle.tenant !== tenant)
    throw new Error("Bundle belongs to a different tenant");
  if (!Number.isSafeInteger(bundle.sequence) || bundle.sequence < 1 || bundle.sequence < minSequence)
    throw new Error("Rejected policy rollback");
  const legacy = bundle;
  const isLegacy = bundle.schemaVersion === "1.0" && bundle.minimumClientVersion === "0.1.0";
  if (!isLegacy && !(bundle.schemaVersion === "2.0" && bundle.minimumClientVersion === "0.2.0") && (bundle.schemaVersion !== SCHEMA_VERSION || bundle.minimumClientVersion !== VERSION))
    throw new Error("Bundle requires a different Cleopatr version");
  if (!Array.isArray(bundle.environmentIds) || !bundle.environmentIds.length || !Array.isArray(bundle.policies) || !Array.isArray(bundle.resources) || !Array.isArray(bundle.environments))
    throw new Error("Invalid bundle manifest");
  if (isLegacy) {
    if (legacy.mode !== "AUDIT" && legacy.mode !== "ENFORCE")
      throw new Error("Invalid legacy bundle mode");
    bundle.environments = bundle.environments.map((e) => ({
      ...e,
      mode: legacy.mode
    }));
    bundle.policies = bundle.policies.map((p) => ({
      ...p,
      status: "PUBLISHED"
    }));
    bundle.bundleId = legacy.releaseId ?? `legacy_${bundle.sequence}`;
  }
  if (!bundle.bundleId || bundle.environments.some(
    (e) => !["AUDIT", "CUSTOM", "ENFORCE"].includes(e.mode ?? "AUDIT") || Object.values(e.policyModes ?? {}).some(
      (mode2) => mode2 !== "AUDIT" && mode2 !== "ENFORCE"
    )
  ))
    throw new Error("Invalid environment policy modes");
  if (!isLegacy && bundle.policies.some((p) => p.status !== "PUBLISHED" || p.published))
    throw new Error("Bundle contains unpublished policy content");
  if (bundle.client && (typeof bundle.client.id !== "string" || !bundle.client.id || typeof bundle.client.name !== "string" || !bundle.client.name.trim() || bundle.client.name.length > 200))
    throw new Error("Invalid signed client identity");
  return bundle;
}

// core/engine.ts
function validatePolicies(engine, policies) {
  const answer = engine.validate({
    schema: SCHEMA,
    policies: {
      staticPolicies: Object.fromEntries(policies.map((p) => [p.id, p.cedar]))
    }
  });
  return answer.type === "failure" ? {
    valid: false,
    errors: answer.errors.map((e) => e.message),
    warnings: answer.warnings.map((e) => e.message)
  } : {
    valid: !answer.validationErrors.length,
    errors: answer.validationErrors.map(
      (e) => `${e.policyId}: ${e.error.message}`
    ),
    warnings: answer.validationWarnings.map(
      (e) => `${e.policyId}: ${e.error.message}`
    )
  };
}
function evaluateWithModes(engine, snapshot, request, forceEnforce = false) {
  const start = performance.now();
  const policies = effectivePolicies(snapshot, request.environmentId);
  const environment2 = snapshot.environments.find(
    (e) => e.id === request.environmentId
  );
  const mode2 = forceEnforce ? "ENFORCE" : environment2.mode ?? "AUDIT";
  const full = evaluate(engine, snapshot, request);
  const enforced = policies.filter((p) => forceEnforce || p.mode === "ENFORCE");
  const mustEnforce = forceEnforce || mode2 === "ENFORCE" || enforced.length > 0;
  const blocking = mustEnforce ? evaluate(engine, { ...snapshot, policies: enforced }, request) : void 0;
  const effectiveResult = blocking?.errors.length ? "ERROR" : blocking?.decision === "DENY" ? "BLOCKED" : full.decision === "DENY" ? "ALLOWED_AUDIT" : "ALLOWED";
  const policyDecisions = [];
  for (const policy of policies) {
    const single = evaluate(
      engine,
      { ...snapshot, policies: [policy] },
      request
    );
    if (single.determiningPolicies.includes(policy.id) || single.errors.length)
      policyDecisions.push({
        policyId: policy.id,
        policyName: policy.name,
        policyVersion: policy.published?.version ?? policy.revision,
        decision: single.errors.length ? "ERROR" : single.decision,
        mode: forceEnforce ? "ENFORCE" : policy.mode
      });
  }
  if (!policyDecisions.length || blocking?.decision === "DENY" && !blocking.determiningPolicies.length)
    policyDecisions.push({
      policyId: "",
      policyName: "Default deny (no permit matched)",
      policyVersion: 0,
      decision: "DENY",
      mode: mustEnforce ? "ENFORCE" : "AUDIT"
    });
  return {
    ...full,
    mode: mode2,
    policyDecisions,
    effectiveResult,
    allowed: effectiveResult === "ALLOWED" || effectiveResult === "ALLOWED_AUDIT",
    enforcementDecision: blocking?.decision,
    enforcementErrors: blocking?.errors ?? [],
    latencyUs: Math.round((performance.now() - start) * 1e3)
  };
}
function evaluate(engine, snapshot, request) {
  const start = performance.now();
  if (!ACTIONS[request.action] || ACTIONS[request.action] !== request.resource.type)
    throw new Error("Action and resource type do not match the schema");
  for (const [key, value2] of Object.entries(request.context)) {
    const type = CONTEXT_FIELDS[key];
    if (!type) throw new Error(`Unsupported context field: ${key}`);
    if (type === "String" && typeof value2 !== "string" || type === "Long" && !Number.isSafeInteger(value2) || type === "Boolean" && typeof value2 !== "boolean" || type === "Set" && (!Array.isArray(value2) || !value2.every((x) => typeof x === "string")))
      throw new Error(`Invalid value for context.${key}`);
  }
  const policies = policiesFor(snapshot, request.environmentId);
  const known = snapshot.resources.find((r) => r.id === request.resource.id);
  if (known && known.type !== request.resource.type)
    throw new Error("Resource type conflicts with the catalog");
  const principalName = request.principal ?? request.sessionId;
  if (typeof principalName !== "string" || !principalName.trim() || principalName.length > 200)
    throw new Error("A principal name of 1\u2013200 characters is required");
  const principal = { type: "Cleopatr::AgentSession", id: principalName };
  const resource = {
    type: `Cleopatr::${request.resource.type}`,
    id: request.resource.id
  };
  const parc = {
    principal,
    action: { type: "Cleopatr::Action", id: request.action },
    resource,
    context: request.context
  };
  const entities = [
    {
      uid: principal,
      attrs: {
        environment: request.environmentId,
        workspace: request.workspace ?? "",
        humanId: request.humanId ?? "local"
      },
      parents: []
    },
    {
      uid: resource,
      attrs: {
        name: known?.name ?? request.resource.id,
        environment: known?.environmentId ?? request.environmentId,
        locator: known?.locator ?? request.resource.id
      },
      parents: []
    }
  ];
  const answer = engine.isAuthorized({
    ...parc,
    context: request.context,
    entities,
    policies: {
      staticPolicies: Object.fromEntries(policies.map((p) => [p.id, p.cedar]))
    },
    schema: SCHEMA,
    validateRequest: true
  });
  if (answer.type === "failure")
    return {
      decision: "DENY",
      determiningPolicies: [],
      errors: answer.errors.map((e) => e.message),
      latencyUs: Math.round((performance.now() - start) * 1e3),
      parc,
      policyCount: policies.length
    };
  return {
    decision: answer.response.diagnostics.errors.length ? "DENY" : answer.response.decision.toUpperCase(),
    determiningPolicies: answer.response.diagnostics.reason,
    errors: answer.response.diagnostics.errors.map(
      (e) => `${e.policyId}: ${e.error.message}`
    ),
    latencyUs: Math.round((performance.now() - start) * 1e3),
    parc,
    policyCount: policies.length
  };
}

// cli/cache.ts
var REFRESH_INTERVAL_MS = 3e5;
function dataDir() {
  if (process.env.CLEO_HOME) return resolve(process.env.CLEO_HOME);
  const project = resolve(".cleo");
  const previous = join(homedir(), ".config", "cleopatr");
  return existsSync(join(project, "config")) || existsSync(join(project, "config.json")) || !existsSync(join(previous, "config.json")) ? project : previous;
}
async function ensureDir(dir) {
  await mkdir(dir, { recursive: true, mode: 448 });
  if ((await lstat(dir)).isSymbolicLink())
    throw new Error("Refusing a symbolic-link Cleopatr directory");
  await chmod(dir, 448);
}
async function atomicJson(path, value2) {
  const temp = path + "." + crypto.randomUUID() + ".tmp";
  await writeFile(temp, JSON.stringify(value2, null, 2), {
    mode: 384,
    flag: "wx"
  });
  try {
    await rename(temp, path);
  } catch (e) {
    await unlink(temp).catch(() => {
    });
    throw e;
  }
}
async function readConfig(dir = dataDir()) {
  const config = JSON.parse(
    await readFile(join(dir, "config"), "utf8").catch(
      (error) => {
        if (error.code !== "ENOENT") throw error;
        return readFile(join(dir, "config.json"), "utf8");
      }
    )
  );
  validateConfig(config);
  return config;
}
function validateConfig(config) {
  const url = new URL(config.server);
  if (url.username || url.password || !["http:", "https:"].includes(url.protocol) || url.protocol === "http:" && !["localhost", "127.0.0.1", "[::1]"].includes(url.hostname))
    throw new Error(
      "Control plane must use HTTPS (HTTP is allowed only on loopback)"
    );
  if (!config.tenant || !config.token || !config.clientId || config.clientName !== void 0 && (typeof config.clientName !== "string" || !config.clientName.trim() || config.clientName.length > 200) || !config.publicKey?.x || !Array.isArray(config.environmentIds) || !config.environmentIds.length || config.environmentIds.some((x) => typeof x !== "string") || config.environment !== void 0 && (typeof config.environment !== "string" || !config.environment.trim()))
    throw new Error("Invalid enrollment configuration");
}
async function readCache(dir = dataDir()) {
  try {
    return JSON.parse(await readFile(join(dir, "bundle.json"), "utf8"));
  } catch (e) {
    if (e.code === "ENOENT") return null;
    throw new Error(
      "Policy cache is unreadable; run cleo sync or import a verified bundle"
    );
  }
}
async function loadBundle(dir = dataDir()) {
  const config = await readConfig(dir);
  const cache = await readCache(dir);
  if (!cache)
    throw new Error(
      "No verified policy bundle. Run cleo sync or import a signed bundle before authorizing."
    );
  const bundle = await verifyBundle(
    cache.signed,
    config.publicKey,
    config.tenant,
    cache.highWater
  );
  verifyScope(bundle, config);
  const validation = validatePolicies(cedar, bundle.policies);
  if (!validation.valid)
    throw new Error(
      "Cached policy validation failed: " + validation.errors.join("; ")
    );
  return { config, cache, bundle };
}
function verifyScope(bundle, config) {
  if (bundle.client && bundle.client.id !== config.clientId)
    throw new Error("Signed client identity does not match this enrollment");
  if (JSON.stringify(bundle.schema) !== JSON.stringify(SCHEMA))
    throw new Error("Bundle schema does not match this client");
  const expected = bundle.environments.filter(
    (e) => ancestors(bundle.environments, e.id).some(
      (id) => config.environmentIds.includes(id)
    )
  ).map((e) => e.id).sort();
  if (JSON.stringify([...bundle.environmentIds].sort()) !== JSON.stringify(expected))
    throw new Error("Bundle assignment does not match this client enrollment");
}
async function withActivationLock(dir, work) {
  const lock = join(dir, "activation.lock");
  const started = Date.now();
  while (true) {
    try {
      await writeFile(lock, String(Date.now()), { flag: "wx", mode: 384 });
      break;
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
      try {
        if (Date.now() - (await stat(lock)).mtimeMs > 3e4) await unlink(lock);
      } catch {
      }
      if (Date.now() - started > 3e3)
        throw new Error("Policy activation is busy; retry");
      await new Promise((r) => setTimeout(r, 10));
    }
  }
  try {
    return await work();
  } finally {
    await unlink(lock).catch(() => {
    });
  }
}
async function activate(signed, dir = dataDir(), checkedAt = Date.now()) {
  return withActivationLock(
    dir,
    () => activateUnlocked(signed, dir, checkedAt)
  );
}
async function activateUnlocked(signed, dir, checkedAt) {
  const config = await readConfig(dir);
  const cache = await readCache(dir);
  const bundle = await verifyBundle(
    signed,
    config.publicKey,
    config.tenant,
    cache?.highWater ?? 0
  );
  verifyScope(bundle, config);
  const validation = validatePolicies(cedar, bundle.policies);
  if (!validation.valid)
    throw new Error(
      "Policy schema validation failed: " + validation.errors.join("; ")
    );
  if (cache) {
    const old = await verifyBundle(
      cache.signed,
      config.publicKey,
      config.tenant,
      cache.highWater
    );
    if (old.sequence === bundle.sequence && cache.signed.digest !== signed.digest)
      throw new Error("Policy bundle contents changed without a new sequence");
  }
  const next = {
    signed,
    checkedAt,
    activatedAt: Date.now(),
    highWater: Math.max(cache?.highWater ?? 0, bundle.sequence),
    etag: `"${signed.digest}"`
  };
  await atomicJson(join(dir, "bundle.json"), next);
  return bundle;
}
function needsRefresh(cache, at = Date.now()) {
  return !cache || at - cache.checkedAt >= REFRESH_INTERVAL_MS;
}
async function requestRefresh(dir = dataDir(), entry = process.argv[1]) {
  const cache = await readCache(dir);
  if (!needsRefresh(cache)) return false;
  const lock = join(dir, "refresh.lock");
  try {
    await writeFile(lock, String(Date.now()), { flag: "wx", mode: 384 });
  } catch (e) {
    if (e.code !== "EEXIST") throw e;
    const age = Date.now() - (await stat(lock)).mtimeMs;
    if (age > 6e4) {
      await unlink(lock).catch(() => {
      });
    }
    return false;
  }
  try {
    const args = entry.endsWith(".ts") ? ["--import", "tsx", entry, "__refresh"] : [entry, "__refresh"];
    const child = spawn(process.execPath, args, {
      detached: true,
      stdio: "ignore",
      env: { ...process.env, CLEO_HOME: dir }
    });
    child.on("error", () => {
      void unlink(lock).catch(() => {
      });
    });
    child.unref();
    return true;
  } catch (e) {
    await unlink(lock).catch(() => {
    });
    throw e;
  }
}
async function sync(dir = dataDir(), fetcher = fetch) {
  const config = await readConfig(dir);
  const cache = await readCache(dir);
  const response = await fetcher(new URL("/api/v1/bundles", config.server), {
    headers: {
      authorization: `Bearer ${config.token}`,
      ...cache ? { "if-none-match": cache.etag } : {}
    },
    signal: AbortSignal.timeout(4e3),
    redirect: "error"
  });
  if (response.status === 304) {
    if (!cache) throw new Error("Server returned 304 without a local bundle");
    await withActivationLock(dir, async () => {
      await loadBundle(dir);
      const current = await readCache(dir);
      if (current?.etag === cache.etag)
        await atomicJson(join(dir, "bundle.json"), {
          ...current,
          checkedAt: Date.now()
        });
    });
    return { changed: false, sequence: cache.highWater };
  }
  if (!response.ok)
    throw new Error(
      `Policy refresh failed (${response.status}); the previous verified bundle is retained`
    );
  const text = await response.text();
  if (text.length > 5e6) throw new Error("Policy bundle is too large");
  const bundle = await activate(JSON.parse(text), dir);
  return { changed: true, sequence: bundle.sequence };
}
async function refreshWorker(dir = dataDir()) {
  try {
    await sync(dir);
    await atomicJson(join(dir, "refresh-status.json"), {
      ok: true,
      time: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (e) {
    await atomicJson(join(dir, "refresh-status.json"), {
      ok: false,
      time: (/* @__PURE__ */ new Date()).toISOString(),
      error: e.message
    });
  } finally {
    await unlink(join(dir, "refresh.lock")).catch(() => {
    });
  }
}

// cli/runtime.ts
import {
  readFile as readFile2,
  writeFile as writeFile2,
  appendFile,
  mkdir as mkdir2,
  readdir,
  unlink as unlink2,
  rename as rename2
} from "node:fs/promises";
import { join as join2 } from "node:path";
import * as cedar2 from "@cedar-policy/cedar-wasm/nodejs";
async function authorize(request, options = {}) {
  const dir = options.dir ?? dataDir();
  const { bundle, cache, config } = await loadBundle(dir);
  if (options.expectedSequence !== void 0 && bundle.sequence !== options.expectedSequence)
    throw new Error(
      "Policy snapshot changed; this supervisor session must be restarted"
    );
  if (!bundle.environmentIds.includes(request.environmentId))
    throw new Error("This client is not assigned to the requested environment");
  if (options.refresh !== false)
    await requestRefresh(dir, options.entry).catch(() => {
    });
  const principal = bundle.client?.name ?? config.clientName;
  if (!principal)
    throw new Error(
      "Client name is missing from this older enrollment. Run cleo sync to receive your signed client identity, or use a new enrollment file for offline access."
    );
  request = { ...request, principal };
  let result;
  try {
    result = evaluateWithModes(
      cedar2,
      bundle,
      request,
      options.mode === "ENFORCE"
    );
  } catch (e) {
    const mode2 = options.mode === "ENFORCE" ? "ENFORCE" : bundle.environments.find((env) => env.id === request.environmentId)?.mode ?? "AUDIT";
    const enforce = mode2 === "ENFORCE" || effectivePolicies(bundle, request.environmentId).some(
      (p) => p.mode === "ENFORCE"
    );
    result = {
      decision: "DENY",
      determiningPolicies: [],
      errors: [e.message],
      latencyUs: 0,
      parc: {
        principal: { type: "Cleopatr::AgentSession", id: principal },
        action: { type: "Cleopatr::Action", id: request.action },
        resource: {
          type: `Cleopatr::${request.resource?.type ?? "Unknown"}`,
          id: request.resource?.id ?? ""
        },
        context: request.context
      },
      policyCount: 0,
      mode: mode2,
      effectiveResult: enforce ? "ERROR" : "ALLOWED_AUDIT",
      allowed: !enforce,
      policyDecisions: [
        {
          policyId: "",
          policyName: "Authorization error",
          policyVersion: 0,
          decision: "ERROR",
          mode: enforce ? "ENFORCE" : "AUDIT"
        }
      ]
    };
  }
  const decision = {
    ...result,
    bundleId: bundle.bundleId,
    sequence: bundle.sequence,
    stale: Date.now() - cache.checkedAt >= 3e5
  };
  await Promise.all(
    decision.policyDecisions.map(
      (policy) => spool(
        {
          id: "evt_" + crypto.randomUUID(),
          kind: "decision",
          time: (/* @__PURE__ */ new Date()).toISOString(),
          sessionId: request.sessionId,
          environmentId: request.environmentId,
          action: request.action,
          resource: request.resource?.id,
          ...policy,
          effectiveResult: policy.decision === "ALLOW" ? "ALLOWED" : policy.mode === "AUDIT" ? "ALLOWED_AUDIT" : policy.decision === "ERROR" ? "ERROR" : "BLOCKED",
          bundleId: bundle.bundleId,
          sequence: bundle.sequence,
          determiningPolicies: policy.policyId ? [policy.policyId] : [],
          adapter: options.adapter ?? "explicit",
          confidence: request.context?.confidence ?? "configured"
        },
        dir
      ).catch(
        (e) => process.stderr.write(
          `cleo: audit spool error: ${e.message}
`
        )
      )
    )
  );
  return decision;
}
async function spool(event, dir = dataDir()) {
  const spoolDir = join2(dir, "spool");
  await mkdir2(spoolDir, { recursive: true, mode: 448 });
  const files = await readdir(spoolDir);
  if (files.length >= 1e4) {
    const allows = files.filter((f) => f.endsWith(".allow.json")).sort();
    if (allows.length) await unlink2(join2(spoolDir, allows[0])).catch(() => {
    });
    else {
      await appendFile(
        join2(dir, "audit-overflow.log"),
        `${(/* @__PURE__ */ new Date()).toISOString()} spool full; ${event.decision} event not persisted
`,
        { mode: 384 }
      );
      return;
    }
  }
  const name = `${Date.now()}-${crypto.randomUUID()}.${event.decision === "ALLOW" ? "allow" : "deny"}.json`;
  const tmp = join2(spoolDir, name + ".tmp");
  await writeFile2(tmp, JSON.stringify(event), { mode: 384 });
  await rename2(tmp, join2(spoolDir, name));
}
async function flushAudit(dir = dataDir()) {
  const config = await readConfig(dir);
  const path = join2(dir, "spool");
  const files = (await readdir(path).catch(() => [])).filter((f) => f.endsWith(".json")).sort().slice(0, 100);
  if (!files.length) return 0;
  const events = await Promise.all(
    files.map((f) => readFile2(join2(path, f), "utf8").then(JSON.parse))
  );
  const response = await fetch(new URL("/api/v1/audit", config.server), {
    method: "POST",
    headers: {
      authorization: `Bearer ${config.token}`,
      "content-type": "application/json"
    },
    body: JSON.stringify({ events }),
    signal: AbortSignal.timeout(4e3),
    redirect: "error"
  });
  if (!response.ok) throw new Error(`Audit upload failed (${response.status})`);
  for (const file of files) await unlink2(join2(path, file)).catch(() => {
  });
  return files.length;
}

// cli/options.ts
var valueOptions = /* @__PURE__ */ new Set([
  "--config",
  "--file",
  "--request",
  "--environment",
  "--mode",
  "--server",
  "--resource",
  "--backend"
]);
function parseInvocation(input) {
  const args = [...input];
  const first = args[0];
  const command = !first ? "help" : first === "--help" || first === "--version" ? args.shift() : first.startsWith("-") ? "run" : args.shift();
  const options = /* @__PURE__ */ new Map();
  const positionals = [];
  let agent = [];
  for (let i = 0; i < args.length; i++) {
    const token = args[i];
    if (token === "--") {
      agent = args.slice(i + 1);
      break;
    }
    if (!token.startsWith("-")) {
      positionals.push(token);
      continue;
    }
    const equals = token.indexOf("=");
    let key = equals < 0 ? token : token.slice(0, equals);
    if (key === "--env") key = "--environment";
    if (key === "--enforce") {
      if (equals >= 0) throw new Error("--enforce does not take a value");
      if (options.has("--mode"))
        throw new Error("Specify only one mode option");
      options.set("--mode", "enforce");
      continue;
    }
    if (!valueOptions.has(key)) throw new Error(`Unknown option: ${key}`);
    if (options.has(key)) throw new Error(`Duplicate option: ${key}`);
    const value2 = equals < 0 ? args[++i] : token.slice(equals + 1);
    if (!value2 || value2.startsWith("--") && equals < 0)
      throw new Error(`Missing value for ${key}`);
    options.set(key, value2);
  }
  return { command, options, positionals, agent };
}
function selectedMode(value2, inherited) {
  const mode2 = (value2 ?? inherited ?? "audit").toUpperCase();
  if (mode2 !== "AUDIT" && mode2 !== "ENFORCE")
    throw new Error("Mode must be audit or enforce");
  return mode2;
}
function resolveEnvironment(bundle, selector) {
  const byId = bundle.environments.find((e) => e.id === selector);
  if (byId) {
    if (!bundle.environmentIds.includes(byId.id))
      throw new Error(
        `This client is not assigned to environment: ${selector}`
      );
    return byId.id;
  }
  const matches = bundle.environments.filter(
    (e) => bundle.environmentIds.includes(e.id) && e.name.toLowerCase() === selector.toLowerCase()
  );
  if (matches.length > 1)
    throw new Error(
      `Environment name is ambiguous: ${selector}. Use an environment ID.`
    );
  if (!matches.length)
    throw new Error(
      `Environment not found in the assigned policy bundle: ${selector}. Run cleo sync to check for new environments.`
    );
  return matches[0].id;
}

// cli/shell.ts
function shellQuote(value2) {
  return "'" + value2.replaceAll("'", "'\\''") + "'";
}
function rewritePipeline(line) {
  if (!/^\s*cleo(?:\s|\||$)/.test(line) || !line.includes("|")) return line;
  if (line.includes("\n") || line.includes("\r"))
    throw new Error(
      "Cleo pipe syntax requires one line. Put shell logic in a script."
    );
  const sides = [[]];
  let word = "";
  let started = false;
  let quote = "";
  const finish = () => {
    if (started) sides[sides.length - 1].push(word);
    word = "";
    started = false;
  };
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (quote === "'") {
      if (c === "'") quote = "";
      else word += c;
      continue;
    }
    if (c === "\\") {
      const next = line[++i];
      if (next === void 0)
        throw new Error("Incomplete escape in Cleo command");
      if (quote === '"' && !["$", "`", '"', "\\"].includes(next)) word += "\\";
      word += next;
      started = true;
      continue;
    }
    if (c === "$" || c === "`")
      throw new Error(
        "Shell expansion is not supported by Cleo pipe syntax. Use literal arguments or a script."
      );
    if (quote === '"') {
      if (c === '"') quote = "";
      else word += c;
      continue;
    }
    if (c === '"' || c === "'") {
      quote = c;
      started = true;
    } else if (/\s/.test(c)) finish();
    else if (c === "|") {
      finish();
      if (sides.length === 2)
        throw new Error(
          "Only one Cleo pipe is supported; use a script for pipelines or shell logic."
        );
      sides.push([]);
    } else if (";&<>(){}*?[]~#!".includes(c))
      throw new Error(
        "Shell operators, expansions and redirections are not supported by Cleo pipe syntax. Use a script."
      );
    else {
      word += c;
      started = true;
    }
  }
  if (quote) throw new Error("Unclosed quote in Cleo command");
  finish();
  if (sides.length === 1) return line;
  const [left, right] = sides;
  if (left[0] !== "cleo" || !right.length)
    throw new Error(
      "Use cleo [--enforce] [--env=NAME_OR_ID] | command [args...]"
    );
  const parsed = parseInvocation([...left.slice(1), "--", ...right]);
  if (left[1] && !left[1].startsWith("-") || parsed.command !== "run" || parsed.positionals.length || left.includes("--") || [...parsed.options.keys()].some(
    (key) => !["--mode", "--environment", "--backend"].includes(key)
  ))
    throw new Error(
      "Only --enforce, --mode, --env and --backend options may precede the Cleo pipe."
    );
  selectedMode(parsed.options.get("--mode"));
  if (/^[A-Za-z_][A-Za-z0-9_]*=/.test(right[0]))
    throw new Error(
      "Put environment assignments inside an agent script, not after the Cleo pipe."
    );
  return ["cleo", ...left.slice(1), "--", ...right].map(shellQuote).join(" ");
}
function zshIntegration(cli) {
  const invoke = cli.map(shellQuote).join(" ");
  return `# Cleopatr: interactive zsh only. No shell startup files are modified.
if [[ -z "\${ZSH_VERSION-}" || ! -o interactive ]]; then
  print -u2 -- 'cleo: init zsh requires an interactive zsh shell'
  return 1
fi
_cleo_accept_line() {
  emulate -L zsh
  setopt extendedglob
  local cleo_line="\${BUFFER##[[:space:]]#}"
  local cleo_rewritten
  if [[ "$cleo_line" == cleo || "$cleo_line" == cleo[[:space:]\\|]* ]]; then
    if [[ -n "$PREBUFFER" ]]; then
      zle -M 'cleo: multiline input is unsupported; use a script'
      return 1
    fi
    cleo_rewritten=$(${invoke} __rewrite-zsh <<< "$BUFFER")
    if (( $? != 0 )); then
      zle -M 'cleo: command was not executed; correct the syntax or use a script'
      return 1
    fi
    BUFFER="$cleo_rewritten"
    CURSOR=\${#BUFFER}
  fi
  zle cleo-original-accept-line
}
if (( ! \${+widgets[cleo-original-accept-line]} )); then
  zle -A accept-line cleo-original-accept-line
fi
zle -N accept-line _cleo_accept_line
`;
}

// cli/main.ts
var invocation;
var value = (key, fallback) => invocation.options.get(key) ?? fallback;
var json = (v) => process.stdout.write(JSON.stringify(v, null, 2) + "\n");
function mode() {
  return selectedMode(value("--mode"), process.env.CLEO_MODE);
}
async function environment(dir, fallback) {
  const { config, bundle } = await loadBundle(dir);
  await requestRefresh(dir).catch(() => {
  });
  return resolveEnvironment(
    bundle,
    value(
      "--environment",
      process.env.CLEO_ENVIRONMENT ?? config.environment ?? fallback ?? config.environmentIds[0]
    )
  );
}
async function executable(command) {
  const candidates = command.includes("/") ? [resolve2(command)] : (process.env.PATH ?? "").split(delimiter).map((p) => join3(p, command));
  for (const path of candidates) {
    try {
      await access(path, constants.X_OK);
      if ((await stat2(path)).isFile()) return await realpath(path);
    } catch {
    }
  }
  throw new Error(`Executable not found: ${command}`);
}
function wrappedCommand() {
  if (!invocation.agent.length)
    throw new Error(
      "No agent was passed. Use cleo -- python agent.py, or enable cleo init zsh before using cleo | agent. A literal shell pipe does not contain its right-hand process; that process may already be running."
    );
  return invocation.agent;
}
async function main() {
  invocation = parseInvocation(process.argv.slice(2));
  const { command, positionals } = invocation;
  const dir = dataDir();
  if (command === "init") {
    if (positionals.length !== 1 || positionals[0] !== "zsh")
      throw new Error(
        "Use cleo init zsh. Only interactive zsh integration is supported."
      );
    process.stdout.write(
      zshIntegration([
        process.execPath,
        ...process.execArgv,
        resolve2(process.argv[1])
      ])
    );
    return;
  }
  if (command === "__rewrite-zsh") {
    let line = "";
    for await (const chunk of process.stdin) {
      line += chunk;
      if (line.length > 65536) throw new Error("Shell command exceeds 64 KiB");
    }
    process.stdout.write(rewritePipeline(line.replace(/\n$/, "")));
    return;
  }
  if (positionals.length && !(command === "audit" && positionals.length === 1 && positionals[0] === "flush"))
    throw new Error(
      "Unexpected arguments. Put the agent command and its arguments after --."
    );
  if (command === "help" || command === "--help") {
    if (!process.argv.slice(2).length && !process.stdout.isTTY)
      throw new Error(
        'Bare cleo does not control the right-hand process of a literal pipe. Enable the interactive zsh hook with eval "$(cleo init zsh)", or use cleo -- agent. The right-hand process may already be running. Use cleo --help for usage.'
      );
    process.stdout.write(
      `Cleopatr ${VERSION} \u2014 local Cedar authorization

Interactive zsh setup (once per shell):
  eval "$(cleo init zsh)"

With the hook enabled, enter one simple command:
  cleo | python -m my_agent
  cleo --enforce | ./agent-service.sh
  cleo --enforce --env=PCI | npm run dev

Portable launch (scripts and other shells):
  cleo [--enforce] [--env=NAME_OR_ID] -- command [args...]

Commands:
  cleo enroll --config enrollment.json     Pin tenant, key, and client identity
  cleo sync                                Fetch and verify the latest bundle
  cleo import --file bundle.json           Activate a signed offline bundle
  cleo authorize --request action.json      Evaluate an explicit action
  cleo mcp [--enforce] -- command          Mediate MCP stdio JSON-RPC
  cleo init zsh                            Print the opt-in interactive shell hook
  cleo status                              Inspect enrollment and policy cache
  cleo doctor                              Report actual adapter coverage
  cleo audit flush                         Upload redacted local decisions

Options: --env NAME_OR_ID (also --environment), --enforce, --mode audit|enforce
  --backend cooperative|linux (Linux preview requires the separate supervisor)
Environment policy modes apply by default; --enforce strengthens all applicable policies.
Environment names must resolve uniquely within the assigned cached bundle.
The environment field in .cleo/config sets the default environment. CLEO_HOME overrides the config/cache directory.

The hook rewrites the pipe before execution; it is not a Unix data pipe.
Without the hook, the shell starts the right-hand process independently.
Only simple literal commands are supported by the hook; use a script for shell logic.
The default cooperative launcher authorizes initial exec only.
--backend linux selects the experimental kernel boundary and refuses uncontained fallback.
Legacy 'cleo run -- command' remains supported.
`
    );
    return;
  }
  if (command === "--version") {
    process.stdout.write(VERSION + "\n");
    return;
  }
  if (command === "doctor") {
    json({
      version: VERSION,
      platform: platform(),
      kernel: release(),
      capabilities: {
        localCedar: "available",
        signedBundles: "Ed25519",
        explicitAuthorization: "pre-authorize",
        processLauncher: "initial exec only",
        pipeSyntax: "opt-in interactive zsh accept-line rewrite; not a Unix data pipe",
        mcpStdio: "mediated requests only",
        linuxCgroup: "experimental Linux supervisor: per-session cgroup v2",
        kernelFilesystem: "experimental Linux supervisor: Landlock directory/executable grants",
        kernelNetwork: "experimental Linux supervisor: seccomp broker and private network namespace",
        httpProxy: "experimental Linux supervisor: HTTP/1.1 and MCP HTTP; CONNECT rejected",
        postgresProxy: "not implemented",
        mysqlProxy: "not implemented"
      },
      boundary: "Default backend is cooperative and bypassable. --backend linux requires the separately installed experimental supervisor; no uncontained fallback. Production coverage remains incomplete.",
      linuxSupervisor: {
        supportedPlatform: platform() === "linux",
        probe: "/usr/lib/cleopatr/cleo-supervisor doctor",
        requiredLandlockAbi: 5,
        productionReady: false
      }
    });
    return;
  }
  if (command === "enroll") {
    const file = value("--config");
    if (!file) throw new Error("Use --config enrollment.json");
    const config = JSON.parse(await readFile3(resolve2(file), "utf8"));
    validateConfig(config);
    await ensureDir(dir);
    const old = await readCache(dir);
    if (old)
      throw new Error(
        "Already enrolled with a policy cache. Use a separate CLEO_HOME for another enrollment."
      );
    await atomicJson(join3(dir, "config"), config);
    json({
      enrolled: true,
      tenant: config.tenant,
      environments: config.environmentIds,
      next: "Run cleo sync, or import a signed bundle. Keep the enrollment file private."
    });
    return;
  }
  if (command === "sync") {
    await ensureDir(dir);
    json(await sync(dir));
    return;
  }
  if (command === "__refresh") {
    await refreshWorker(dir);
    await flushAudit(dir).catch(() => {
    });
    return;
  }
  if (command === "import") {
    const file = value("--file");
    if (!file) throw new Error("Use --file signed-bundle.json");
    const bundle = await activate(
      JSON.parse(await readFile3(resolve2(file), "utf8")),
      dir,
      0
    );
    json({
      activated: true,
      sequence: bundle.sequence,
      environments: bundle.environmentIds
    });
    return;
  }
  if (command === "status") {
    const config = await readConfig(dir);
    let cache;
    try {
      const loaded = await loadBundle(dir);
      cache = {
        verified: true,
        bundle: loaded.bundle.bundleId,
        sequence: loaded.bundle.sequence,
        environment: config.environment ?? config.environmentIds[0],
        lastChecked: new Date(loaded.cache.checkedAt).toISOString(),
        stale: Date.now() - loaded.cache.checkedAt >= 3e5
      };
    } catch (e) {
      cache = { verified: false, error: e.message };
    }
    json({
      version: VERSION,
      server: config.server,
      tenant: config.tenant,
      environments: config.environmentIds,
      cache,
      refreshIntervalSeconds: 300
    });
    return;
  }
  if (command === "audit" && positionals[0] === "flush") {
    json({ uploaded: await flushAudit(dir) });
    return;
  }
  if (command === "authorize") {
    const file = value("--request");
    if (!file)
      throw new Error("Use --request action.json (or --request - for stdin)");
    const request = JSON.parse(
      await readFile3(file === "-" ? "/dev/stdin" : resolve2(file), "utf8")
    );
    request.environmentId = await environment(dir, request.environmentId);
    request.sessionId ??= process.env.CLEO_SESSION_ID ?? "agt_" + crypto.randomUUID();
    const result = await authorize(request, { dir, mode: mode() });
    json(result);
    process.exitCode = result.allowed ? 0 : result.errors.length ? 3 : 2;
    return;
  }
  if (command === "run") {
    const [cmd, ...argv] = wrappedCommand();
    const backend = value("--backend", "cooperative");
    if (!["linux", "cooperative"].includes(backend))
      throw new Error("Backend must be linux or cooperative");
    if (backend === "linux") {
      if (platform() !== "linux")
        throw new Error(
          "The Linux security supervisor requires Linux. No uncontained fallback was started."
        );
      const args = ["launch"];
      let selector = value("--environment", process.env.CLEO_ENVIRONMENT);
      if (!selector) {
        const text = await readFile3(join3(dir, "config"), "utf8").catch(
          async (error) => {
            if (error.code !== "ENOENT") throw error;
            return readFile3(join3(dir, "config.json"), "utf8").catch(
              (legacy) => {
                if (legacy.code !== "ENOENT") throw legacy;
                return "{}";
              }
            );
          }
        );
        const local = JSON.parse(text);
        if (local.environment !== void 0 && (typeof local.environment !== "string" || !local.environment.trim()))
          throw new Error(
            "Invalid environment selector in local configuration"
          );
        selector = local.environment;
      }
      if (selector) args.push("--env", selector);
      if (mode() === "ENFORCE") args.push("--enforce");
      args.push("--", cmd, ...argv);
      const child2 = spawn2("/usr/lib/cleopatr/cleo-supervisor", args, {
        stdio: "inherit",
        env: { PATH: "/usr/bin:/bin", NODE_ENV: "production" }
      });
      for (const signal of ["SIGINT", "SIGTERM", "SIGHUP"])
        process.on(signal, () => {
          child2.kill(signal);
        });
      await new Promise((resolve3, reject) => {
        child2.once("error", reject);
        child2.once("close", (code, signal) => {
          process.exitCode = code ?? (signal === "SIGINT" ? 130 : 143);
          resolve3();
        });
      });
      return;
    }
    const path = await executable(cmd);
    const environmentId = await environment(dir);
    const sessionId = "agt_" + crypto.randomUUID();
    const request = {
      environmentId,
      sessionId,
      action: "process.execute",
      resource: { type: "Process", id: path },
      workspace: process.cwd(),
      context: {
        executable: path,
        argv,
        cwd: process.cwd(),
        confidence: "configured"
      }
    };
    const result = await authorize(request, { dir, mode: mode() });
    process.stderr.write(
      `cleo: ${result.mode} \xB7 policy snapshot ${result.sequence} \xB7 launcher ${result.effectiveResult}
cleo: descendant filesystem/network/process interception unavailable; use mediated adapters.
`
    );
    if (!result.allowed) {
      process.stderr.write(
        "cleo: denied by " + (result.determiningPolicies.join(", ") || "default deny") + "\n"
      );
      process.exitCode = 2;
      return;
    }
    const child = spawn2(path, argv, {
      stdio: "inherit",
      env: {
        ...process.env,
        CLEO_SESSION_ID: sessionId,
        CLEO_ENVIRONMENT: environmentId,
        CLEO_MODE: mode()
      }
    });
    for (const signal of [
      "SIGINT",
      "SIGTERM",
      "SIGHUP",
      "SIGWINCH"
    ])
      process.on(signal, () => {
        try {
          child.kill(signal);
        } catch {
        }
      });
    child.on("error", (error) => {
      process.stderr.write(`cleo: ${error.message}
`);
      process.exitCode = 127;
    });
    await new Promise(
      (res) => child.on("close", (code, signal) => {
        process.exitCode = code ?? (signal === "SIGINT" ? 130 : signal === "SIGTERM" ? 143 : 1);
        res();
      })
    );
    return;
  }
  if (command === "mcp") {
    await runMcp(dir);
    return;
  }
  throw new Error(`Unknown command: ${command}. Run cleo --help.`);
}
async function runMcp(dir) {
  const [cmd, ...argv] = wrappedCommand();
  const path = await executable(cmd);
  const environmentId = await environment(dir);
  const sessionId = process.env.CLEO_SESSION_ID ?? "agt_" + crypto.randomUUID();
  const initial = await authorize(
    {
      environmentId,
      sessionId,
      action: "process.execute",
      resource: { type: "Process", id: path },
      context: { executable: path, argv, confidence: "configured" }
    },
    { dir, mode: mode() }
  );
  if (!initial.allowed) throw new Error("MCP server launch denied");
  const child = spawn2(path, argv, {
    stdio: ["pipe", "pipe", "inherit"],
    env: {
      ...process.env,
      CLEO_SESSION_ID: sessionId,
      CLEO_ENVIRONMENT: environmentId,
      CLEO_MODE: mode()
    }
  });
  child.stdout.pipe(process.stdout);
  const lines = createInterface({ input: process.stdin, crlfDelay: Infinity });
  let chain = Promise.resolve();
  const passthrough = /* @__PURE__ */ new Set([
    "initialize",
    "ping",
    "tools/list",
    "resources/list",
    "resources/templates/list",
    "prompts/list",
    "notifications/initialized",
    "notifications/cancelled",
    "notifications/progress",
    "logging/setLevel",
    "completion/complete"
  ]);
  lines.on("line", (line) => {
    chain = chain.then(async () => {
      if (Buffer.byteLength(line) > 1024 * 1024)
        throw new Error("MCP message exceeds one MiB");
      const msg = JSON.parse(line);
      if (!msg.method) {
        child.stdin.write(line + "\n");
        return;
      }
      const mapping = {
        "tools/call": "mcp.tool.invoke",
        "resources/read": "mcp.resource.read",
        "prompts/get": "mcp.prompt.get"
      };
      const action = mapping[msg.method];
      if (!action && !passthrough.has(msg.method)) {
        if (msg.id !== void 0)
          process.stdout.write(
            JSON.stringify({
              jsonrpc: "2.0",
              id: msg.id,
              error: {
                code: -32601,
                message: "MCP operation is not supported by this Cleopatr adapter"
              }
            }) + "\n"
          );
        return;
      }
      if (action) {
        const tool = String(msg.params?.name ?? msg.params?.uri ?? "unknown");
        const context = {
          tool,
          server: value("--server", basename(path)),
          confidence: "semantic"
        };
        if (Number.isSafeInteger(msg.params?.arguments?.amount))
          context.amount = msg.params.arguments.amount;
        const result = await authorize(
          {
            environmentId,
            sessionId,
            action,
            resource: { type: "MCPTool", id: value("--resource", tool) },
            context
          },
          { dir, mode: mode() }
        );
        if (!result.allowed) {
          if (msg.id !== void 0)
            process.stdout.write(
              JSON.stringify({
                jsonrpc: "2.0",
                id: msg.id,
                error: {
                  code: -32003,
                  message: "Denied by Cleopatr",
                  data: {
                    policies: result.determiningPolicies,
                    snapshot: result.sequence
                  }
                }
              }) + "\n"
            );
          return;
        }
      }
      if (!child.stdin.write(line + "\n"))
        await new Promise((res) => child.stdin.once("drain", res));
    }).catch((e) => {
      process.stderr.write(`cleo MCP: ${e.message}
`);
      child.kill("SIGTERM");
      lines.close();
      process.exitCode = 3;
    });
  });
  lines.on("close", () => void chain.then(() => child.stdin.end()));
  for (const signal of ["SIGINT", "SIGTERM", "SIGHUP"])
    process.on(signal, () => child.kill(signal));
  child.on("error", (e) => {
    process.stderr.write(`cleo MCP: ${e.message}
`);
    lines.close();
    process.exitCode = 127;
  });
  await new Promise(
    (res) => child.on("close", (code) => {
      lines.close();
      process.exitCode = process.exitCode || code || 0;
      res();
    })
  );
}
main().catch((error) => {
  process.stderr.write(`cleo: ${error.message}
`);
  process.exitCode = 3;
});
